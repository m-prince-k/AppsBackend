import { createContext, Dispatch, SetStateAction, useEffect, useState } from 'react'

import Swal from "sweetalert2";
import qs from 'qs'
import { ID, QueryResponseContextProps, QueryState } from './models'
import Resizer from "react-image-file-resizer";
import CryptoJS from 'crypto-js';


function createResponseContext<T>(initialState: QueryResponseContextProps<T>) {
  return createContext(initialState)
}



export const encryptData = (plainText: any) => {
  let encJson = CryptoJS?.AES?.encrypt(JSON.stringify(plainText), "6il7YCRSqIOB9NooY225lPKQ0KuAF/nkFX6cY3vJkS0=").toString();
  return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(encJson));
}

export const decryptData = (cipherText: any) => {
  let decData = CryptoJS?.enc.Base64?.parse(cipherText)?.toString(CryptoJS.enc.Utf8);
  return CryptoJS.AES.decrypt(decData, "6il7YCRSqIOB9NooY225lPKQ0KuAF/nkFX6cY3vJkS0=").toString(CryptoJS.enc.Utf8);
}

function isNotEmpty(obj: unknown) {
  return obj !== undefined && obj !== null && obj !== ''
}

function capitalizeFirstLetter(val: string) {
  return String(val)?.charAt(0)?.toUpperCase() + String(val)?.slice(1);
}

// Example: page=1&items_per_page=10&sort=id&order=desc&search=a&filter_name=a&filter_online=false
function stringifyRequestQuery(state: QueryState): string {
  const pagination = qs.stringify(state, { filter: ['page', 'items_per_page'], skipNulls: true })
  const sort = qs.stringify(state, { filter: ['sort', 'order'], skipNulls: true })
  const search = isNotEmpty(state.search)
    ? qs.stringify(state, { filter: ['search'], skipNulls: true })
    : ''

  const filter = state.filter
    ? Object.entries(state.filter)
      .filter((obj) => isNotEmpty(obj[1]))
      .map((obj) => {
        return `filter_${obj[0]}=${obj[1]}`
      })
      .join('&')
    : ''

  return [pagination, sort, search, filter]
    .filter((f) => f)
    .join('&')
    .toLowerCase()
}

function parseRequestQuery(query: string): QueryState {
  const cache: unknown = qs.parse(query)
  return cache as QueryState
}

function calculatedGroupingIsDisabled<T>(isLoading: boolean, data: Array<T> | undefined): boolean {
  if (isLoading) {
    return true
  }

  return !data || !data.length
}

function calculateIsAllDataSelected<T>(data: Array<T> | undefined, selected: Array<ID>): boolean {
  if (!data) {
    return false
  }

  return data.length > 0 && data.length === selected.length
}

function groupingOnSelect(
  id: ID,
  selected: Array<ID>,
  setSelected: Dispatch<SetStateAction<Array<ID>>>
) {
  if (!id) {
    return
  }

  if (selected.includes(id)) {
    setSelected(selected.filter((itemId) => itemId !== id))
  } else {
    const updatedSelected = [...selected]
    updatedSelected.push(id)
    setSelected(updatedSelected)
  }
}

function groupingOnSelectAll<T>(
  isAllSelected: boolean,
  setSelected: Dispatch<SetStateAction<Array<ID>>>,
  data?: Array<T & { id?: ID }>
) {
  if (isAllSelected) {
    setSelected([])
    return
  }

  if (!data || !data.length) {
    return
  }

  setSelected(data.filter((item) => item.id).map((item) => item.id))
}

// Hook
function useDebounce(value: string | undefined, delay: number) {
  // State and setters for debounced value
  const [debouncedValue, setDebouncedValue] = useState(value)
  useEffect(
    () => {
      // Update debounced value after delay
      const handler = setTimeout(() => {
        setDebouncedValue(value)
      }, delay)
      // Cancel the timeout if value changes (also on delay change or unmount)
      // This is how we prevent debounced value from updating if value is changed ...
      // .. within the delay period. Timeout gets cleared and restarted.
      return () => {
        clearTimeout(handler)
      }
    },
    [value, delay] // Only re-call effect if value or delay changes
  )
  return debouncedValue
}


const encodeBase64 = (data) => {
  return Buffer.from(data).toString('base64');
}
const decodeBase64 = (data) => {
  return Buffer.from(data, 'base64').toString('ascii');
}


function SwalResponse(type: string, title: string, text: string) {
  if (type == "danger") {
    return Swal.fire({
      title: title,
      text: text,
      icon: "error",
    });
  } else if (type == "success") {
    return Swal.fire({
      title: title,
      text: text,
      icon: "success",
    });
  } else if (type == "warning") {
    return Swal.fire({
      title: title,
      text: text,
      icon: "warning",
    });
  }
}

async function resizeFileSizes(files: any, height: number, width: number) {
  try {
    await Resizer.imageFileResizer(files, height, width, "JPEG,PNG", 100, 0, (uri) => { console.log(uri); return uri; }, "base64", height, width);
  } catch (err) {
    console.log(err);
  }
}


async function uniqueValue(array: []) {
  let outputImages = array?.reduce((acc: any, obj: any) => {
    if (!acc?.some((o: any) => o === obj)) {
      acc?.push(obj);
    }
    return acc;
  }, []);

  return outputImages;
}

async function addId(arr: any) {
  return await arr?.map(function (obj: any, index: number) {
    return Object.assign({}, obj, { id: index });
  });
};


function formatFileSize(bytes: any, decimalPoint?: number) {
  if (bytes == 0) return '0 Bytes';
  var k = 1000,
    dm = decimalPoint || 2,
    sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
    i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm));
}


export {
  formatFileSize,
  addId,
  uniqueValue,
  encodeBase64,
  decodeBase64,
  capitalizeFirstLetter,
  resizeFileSizes,
  SwalResponse,
  createResponseContext,
  stringifyRequestQuery,
  parseRequestQuery,
  calculatedGroupingIsDisabled,
  calculateIsAllDataSelected,
  groupingOnSelect,
  groupingOnSelectAll,
  useDebounce,
  isNotEmpty,
}
