import { FC } from "react";
import clsx from "clsx";
import { Link, useLocation } from "react-router-dom";
import { useLayout } from "../../../core/LayoutProvider";
import { usePageData } from "../../../core/PageData";
import { decryptData, encryptData } from "../../../../helpers";

interface firmwareApps {
  firmware_app_id: number;
  firmware_app_name: string;
}

const DefaultTitle = (props: any) => {
  const { search, pathname } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  let filterName = searchParams.get("name") && searchParams.get("name");
  let filterCatId =
    searchParams.get("catId") && decryptData(searchParams.get("catId"));

  const app_id = filterId;
  const app_name = filterName;
  const catId = filterCatId;

  // const {firmware_app_id, firmware_app_name}=state as firmwareApps || {};

  const { pageTitle, pageDescription, pageBreadcrumbs } = usePageData();

  const { config } = useLayout();
  return (
    <div className="page-title d-flex justify-content-center flex-column me-5">
      {/* begin::Title */}
      {pageTitle && (
        <h1 className="d-flex flex-column text-gray-900 fw-bolder fs-3 mb-0">
          {props?.frame_id
            ? "Update Frame"
            : props?.app_name
            ? props?.app_name
            : pageTitle}

          {pageDescription &&
            config.pageTitle &&
            config?.pageTitle?.description && (
              <>
                <span className="h-20px border-gray-200 border-start ms-3 mx-2"></span>
                <small className="text-muted fs-7 fw-bold my-1 ms-1">
                  {pageDescription}
                </small>
              </>
            )}
        </h1>
      )}
      {/* end::Title */}

      {pageBreadcrumbs && pageBreadcrumbs.length > 0 && (
        <ul className="breadcrumb breadcrumb-separatorless fw-bold fs-7 pt-1">
          {Array.from(pageBreadcrumbs).map((item, index) => (
            <li
              className={clsx("breadcrumb-item", {
                "text-gray-900": !item.isSeparator && item.isActive,
                "text-muted": !item.isSeparator && !item.isActive,
              })}
              key={`${item.path}${index}`}
            >
              {!item.isSeparator ? (
                <Link
                  className="text-muted text-hover-primary"
                  to={
                    app_id && app_name
                      ? `${pathname}?id=${encryptData(app_id)}&name=${app_name}`
                      : catId
                      ? "/apps/categories"
                      : item.path
                  }
                >
                  {props.frame_id
                    ? "Update Frame"
                    : props?.app_name
                    ? props?.app_name
                    : item.title}
                </Link>
              ) : (
                <span className="bullet bg-gray-500 w-5px h-2px"></span>
              )}
            </li>
          ))}
          <li className="breadcrumb-item text-gray-900">
            {props.frame_id
              ? "Update Frame"
              : props?.app_name
              ? props?.app_name
              : pageTitle}
          </li>
        </ul>
      )}
    </div>
  );
};

export { DefaultTitle };
