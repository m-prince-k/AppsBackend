/* eslint-disable @typescript-eslint/no-explicit-any */

import { useEffect, useState } from "react";
import noUiSlider, { target } from "nouislider";
import { useLayout } from "../../core";
import { KTIcon } from "../../../helpers";
import { DefaultTitle } from "./page-title/DefaultTitle";
import { ThemeModeSwitcher } from "../../../partials";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "../../../../store/store";
import { Profile, useAuth } from "../../../../app/modules/auth";
import { getAuthPermissionDetail } from "../../../../store/Auth/authSlice";
import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import DynamicAppTitle from "../AppTitle/DynamicAppTitle";
import { jwtDecode } from "jwt-decode";

interface AppsDialect {
  app_id: number;
  app_name: string;
  category_id: number;
  frame_id: number;
  firmware_app_id: number;
  firmware_app_name: string;
}

const HeaderToolbar = () => {
  const { classes } = useLayout();
  const navigate = useNavigate();
  const { currentUser, auth, logout } = useAuth();
  const dispatch = useDispatch<AppDispatch>();
  // const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
  //   useSelector((state: { auth: Profile }) => state?.auth);
  const [status, setStatus] = useState<string>("1");
  const { search, state, pathname } = useLocation();
  const [fetchAuthDetails, setFetchAuthDetails] = useState<any>(null);
  const searchParams = new URLSearchParams(search);

  const app_id = searchParams.get("id");
  const app_name = searchParams.get("name");

  const { frame_id, category_id, firmware_app_id, firmware_app_name } =
    (state as AppsDialect) || {};

  let AppTitle = {
    app_id: app_id,
    firmware_app_id: firmware_app_id,
    firmware_app_name: firmware_app_name,
    app_name: app_name,
  };

  useEffect(() => {
    let timerRef = null;
    const decoded = jwtDecode(auth?.token);
    const currentTime = new Date().getTime();
    const expiryTime = new Date(decoded.exp * 1000).getTime();
    const timeout = expiryTime - currentTime;
    var today = new Date();
    today.setHours(today.getHours() + 4);

    const onExpire = () => {
      navigate("/auth");
      dispatch(logout);
    };

    if (timeout > 0) {
      timerRef = setTimeout(onExpire, timeout);
    } else {
      onExpire();
    }
    return () => {
      clearTimeout(timerRef);
    };
  }, [dispatch, navigate, auth?.token]);

  useEffect(() => {
    const fetchAuthPermissionDetail = async () => {
      try {
        const { payload } = await dispatch(getAuthPermissionDetail());
        if (payload?.status === 200) {
          setFetchAuthDetails(payload?.data);
        } else if (payload?.status === 401) {
          navigate("/auth");
          dispatch(logout);
        }
      } catch (error) {
        console.error("Error fetching auth details:", error);
      }
    };

    fetchAuthPermissionDetail();
  }, [dispatch, navigate]);

  useEffect(() => {
    const slider: target = document.querySelector(
      "#kt_toolbar_slider"
    ) as target;
    const rangeSliderValueElement: Element | null = document.querySelector(
      "#kt_toolbar_slider_value"
    );

    if (!slider) {
      return;
    }

    slider.innerHTML = "";

    noUiSlider.create(slider, {
      start: [5],
      connect: [true, false],
      step: 1,
      range: {
        min: [1],
        max: [10],
      },
    });

    slider.noUiSlider?.on("update", function (values: any, handle: any) {
      if (!rangeSliderValueElement) {
        return;
      }

      rangeSliderValueElement.innerHTML = parseInt(values[handle]).toFixed(1);
    });
  }, []);

  return (
    <div className="toolbar d-flex align-items-stretch">
      {/* begin::Toolbar container */}
      <div
        className={`${classes.headerContainer.join(
          " "
        )} py-6 py-lg-0 d-flex flex-column flex-lg-row align-items-lg-stretch justify-content-lg-between`}
      >
        {pathname == `/apps/HP/?id=${app_id}&name${app_name}` ||
        pathname == `/firmware/HP/?id=${app_id}&name=${app_name}` ? (
          <DynamicAppTitle AppTitle={AppTitle} />
        ) : (
          <DefaultTitle
            app_id={app_id}
            app_name={app_name}
            frame_id={frame_id}
          />
        )}

        <div className="d-flex align-items-stretch overflow-auto pt-3 pt-lg-0">
          {/* begin::Action wrapper */}
          <div className="d-flex align-items-center">
            {/* begin::Actions */}
            <div className="d-flex">
              {/* begin::Action */}

              {/* begin::Theme mode */}
              <div className="d-flex align-items-center">
                <ThemeModeSwitcher toggleBtnClass="btn btn-sm btn-icon btn-icon-muted btn-active-icon-primary" />
              </div>
              {/* end::Theme mode */}
            </div>
            {/* end::Actions */}
          </div>
          {/* end::Action wrapper */}
        </div>
        {/* end::Toolbar container */}
      </div>
    </div>
  );
};

export { HeaderToolbar };
