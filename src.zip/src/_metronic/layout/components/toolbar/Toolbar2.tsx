import React, {FC} from 'react'

const Toolbar2: FC = () => {
  return <>Toolbar 2</>
}

export {Toolbar2}
