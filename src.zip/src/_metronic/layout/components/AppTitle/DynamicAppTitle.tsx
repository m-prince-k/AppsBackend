import { Link, useLocation } from "react-router-dom";
import { capitalizeFirstLetter } from "../../../helpers";
import usePageTitle from "../../../../app/modules/auth/components/PageTitle/usePageTitle";

const DynamicAppTitle = (props: any) => {


    const { app_id, firmware_app_id, firmware_app_name, app_name } = props?.AppTitle || {};


    // const { app_name = "HP", sticker_id, frame_id } = state as appName || {};

    usePageTitle(app_name ? app_name : firmware_app_name);

    return (
        <>
            <div className="page-title d-flex justify-content-center flex-column me-5">
                <h1 className="d-flex flex-column text-gray-900 fw-bolder fs-3 mb-0">{app_name ? capitalizeFirstLetter(app_name) : firmware_app_name || app_name}</h1>
                <ul className="breadcrumb breadcrumb-separatorless fw-bold fs-7 pt-1">
                    <li className="breadcrumb-item text-muted">
                        <Link className="text-muted text-hover-primary" onContextMenu={(e) => e.preventDefault()} to={""}>{app_name ? capitalizeFirstLetter(app_name) : firmware_app_name ? firmware_app_name :  app_name}</Link></li>
                    <li className="breadcrumb-item"><span className="bullet bg-gray-500 w-5px h-2px"></span></li>
                    <li className="breadcrumb-item text-gray-900">{app_name ? capitalizeFirstLetter(app_name) : firmware_app_name ? firmware_app_name : app_name}</li></ul></div>
        </>
    )
}

export default DynamicAppTitle;