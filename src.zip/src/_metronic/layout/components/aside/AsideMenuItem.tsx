// import { FC, useState } from 'react'
// import clsx from 'clsx'
// import { Link } from 'react-router-dom'
// import { useLocation } from 'react-router'
// import { checkIsActive, KTIcon, WithChildren } from '../../../helpers'

// type Props = {
//   to: any
//   title: string
//   icon?: string
//   fontIcon?: string
//   hasBullet?: boolean,
//   AppId?: number,
//   AppName?: string,
// }



// const AsideMenuItem: FC<Props & WithChildren> = ({
//   children,
//   to,
//   title,
//   icon,
//   fontIcon,
//   hasBullet = false,
//   AppId,
//   AppName,

// }) => {
//   const { pathname } = useLocation();

//   const isActive = checkIsActive(pathname, to)

//   return (
//     <div className='menu-item'>
//       <Link className={`menu-link without-sub`}  to={AppName ? '/apps/HP/HP' : to} 
//       state={{ app_id: AppId, app_name: AppName }}>
//         {hasBullet && (
//           <span className='menu-bullet'>
//             <span className='bullet bullet-dot'></span>
//           </span>
//         )}
//         {icon && (
//           <span className='menu-icon'>
//             <KTIcon iconName={icon} className='fs-2' />
//           </span>
//         )}
//         {fontIcon && <i className={clsx('bi fs-3', fontIcon)}></i>}
//         <span className='menu-title'>{title}</span>
//       </Link>
//       {children}
//     </div>
//   )
// }

// export { AsideMenuItem }

import { FC } from 'react';
import clsx from 'clsx';
import { Link } from 'react-router-dom';
import { useLocation } from 'react-router';
import { checkIsActive, encryptData, KTIcon, WithChildren } from '../../../helpers';

type Props = {
  to: string;
  title: string;
  icon?: string;
  fontIcon?: string;
  hasBullet?: boolean;
  AppId?: number;
  AppName?: string;
  className?: string;  // Add className to the type definition
  onClick?: () => void; // Add onClick handler
};

const AsideMenuItem: FC<Props & WithChildren> = ({
  children,
  to,
  title,
  icon,
  fontIcon,
  hasBullet = false,
  AppId,
  AppName,
  className,  // Destructure className from props
  onClick,    // Destructure onClick from props
}) => {
  const { pathname } = useLocation();
  const isActive = checkIsActive(pathname, to);

  return (
    <div className='menu-item'>
      <Link
        className={clsx('menu-link without-sub', className, { active: isActive })}
        to={AppName ? `/apps/?app_id=${encryptData(AppId)}&app_name=${encryptData(AppName)}` : to}
        state={{ app_id: AppId, app_name: AppName }}
        onClick={onClick}  // Call onClick if provided
      >
        {hasBullet && (
          <span className='menu-bullet'>
            <span className='bullet bullet-dot'></span>
          </span>
        )}
        {icon && (
          <span className='menu-icon'>
            <KTIcon iconName={icon} className='fs-2' />
          </span>
        )}
        {fontIcon && <i className={clsx('bi fs-3', fontIcon)}></i>}
        <span className='menu-title'>{title}</span>
      </Link>
      {children}
    </div>
  );
};

export { AsideMenuItem };
