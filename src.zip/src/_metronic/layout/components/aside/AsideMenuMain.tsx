import { useIntl } from "react-intl";
import { capitalizeFirstLetter, encryptData, KTIcon } from "../../../helpers";
import { AsideMenuItemWithSub } from "./AsideMenuItemWithSub";
import { AsideMenuItem } from "./AsideMenuItem";
import { Profile, useAuth } from "../../../../app/modules/auth";
import { AppDispatch } from "../../../../store/store";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import {
  getAuthPermissionDetail,
  logout,
} from "../../../../store/Auth/authSlice";
import { IRootState } from "../../../../store/combineReducer/rootReducer";
import { getAllBrandApps } from "../../../../store/Apps/appSlice";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { firmwareApp } from "../../../../app/modules/apps/app/core/_models";
import { jwtDecode } from "jwt-decode";

export function AsideMenuMain() {
  const intl = useIntl();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { currentUser, auth, logout } = useAuth();
  const [Apps, setApps] = useState<Array<object>>([]);
  const [AppsTotal, setTotalApps] = useState<number>(0);

  const [activeId, setActiveId] = useState<number>(0);
  const [firmwareActiveId, setFirmwareActiveId] = useState<number>(0);
  const [activeBool, setActiveBool] = useState(false);
  const [activeTabId, setActiveTabId] = useState<number | string>(0);
  const [searchSatatus, setSearchStatus] = useState(false);

  // Active state for Apps/Firmware sections based on app_id
  const [activeAppId, setActiveAppId] = useState<number | string>(0);
  const dispatch = useDispatch<AppDispatch>();
  const [fetchAuthDetails, setFetchAuthDetails] = useState<any>(null);
  // const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
  //   useSelector((state: { auth: Profile }) => state?.auth);

  // check jwt time
  useEffect(() => {
    let timerRef = null;
    const decoded = jwtDecode(auth?.token);
    const currentTime = new Date().getTime();
    const expiryTime = new Date(decoded.exp * 1000).getTime();
    const timeout = expiryTime - currentTime;
    var today = new Date();
    today.setHours(today.getHours() + 4);

    const onExpire = () => {
      navigate("/auth");
      dispatch(logout);
    };

    if (timeout > 0) {
      // token not expired, set future timeout to log out and redirect
      timerRef = setTimeout(onExpire, timeout);
    } else {
      // token expired, log out and redirect
      onExpire();
    }

    // Clear any running timers on component unmount or token state change
    return () => {
      clearTimeout(timerRef);
    };
  }, [dispatch, navigate, auth?.token]);

  useEffect(() => {
    dispatch(fetchApps);
  }, []);

  useEffect(() => {
    const fetchAuthPermissionDetail = async () => {
      try {
        const { payload } = await dispatch(getAuthPermissionDetail());
        if (payload?.status === 200) {
          setFetchAuthDetails(payload?.data);
        } else if (payload?.status === 401) {
          navigate("/auth");
          dispatch(logout);
        }
      } catch (error) {
        console.error("Error fetching auth details:", error);
      }
    };

    fetchAuthPermissionDetail();
  }, [dispatch, navigate]);

  async function fetchApps() {
    const { payload } = await dispatch(getAllBrandApps(""));
    if (payload?.status === 200) {
      setApps(payload?.data);
      setTotalApps(payload?.count);
    }
  }

  let uniqueApps = Apps?.reduce((acc: any, obj: any) => {
    if (!acc?.some((o: any) => o?.name === obj?.name)) {
      acc?.push(obj);
    }
    return acc;
  }, []);

  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const auth_apps_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager" ||
    auth?.access_type?.access_type_name === "General Users";
  const auth_firmware_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "Firmware Engineer";
  const get_permissions = fetchAuthDetails?.data;

  return (
    <>
      <AsideMenuItem
        to="/dashboard"
        icon="element-11"
        title={intl.formatMessage({ id: "MENU.DASHBOARD" })}
        className={activeTabId === "dashboard" ? "active" : ""}
        onClick={() => {
          setActiveTabId("dashboard"); // Mark Dashboard as active
          setActiveAppId(0);
          setActiveBool(false);
          setFirmwareActiveId(0); // Reset active app
          setActiveId(0); // Reset active app
        }}
      />
      {auth_permission && (
        <div className="menu-item">
          <div className="menu-content pt-8 pb-2">
            <span className="menu-section text-muted text-uppercase fs-8 ls-1">
              Authorization
            </span>
          </div>
        </div>
      )}
      {auth_permission && (
        <AsideMenuItem
          to="/apps/manage-roles/manage-roles"
          icon="shield-tick"
          title="Manage Roles"
          onClick={() => {
            setActiveTabId("manage-roles");
            setActiveAppId(0);
            setActiveBool(false);
            setFirmwareActiveId(0); // Reset active app
            setActiveId(0); // Reset active app
          }}
          className={activeTabId === "manage-roles" ? "active" : ""}
        />
      )}
      {/* {auth_permission && (
        <AsideMenuItem
          to="#"
          icon="shield-tick"
          title="Manage Permissions"
        />
      )} */}
      {auth_permission && (
        <>
          <div className="menu-item">
            <div className="menu-content pt-8 pb-2">
              <span className="menu-section text-muted text-uppercase fs-8 ls-1">
                User Management
              </span>
            </div>
          </div>
          <AsideMenuItem
            to="/apps/manage-users/users"
            icon="shield-tick"
            title="Manage Users"
            onClick={() => {
              setActiveTabId("manage-users");
              setActiveAppId(0);
              setActiveBool(false);
              setFirmwareActiveId(0);
              setActiveId(0);
            }}
            className={activeTabId === "manage-users" ? "active" : ""}
          />
        </>
      )}
      {auth_permission && (
        <div className="menu-item">
          <div className="menu-content pt-8 pb-2">
            <span className="menu-section text-muted text-uppercase fs-8 ls-1">
              Categories
            </span>
          </div>
        </div>
      )}

      {auth_permission && (
        <AsideMenuItem
          to="/apps/categories"
          icon="shield-tick"
          title="Categories"
          onClick={() => {
            setActiveTabId("categories");
            setActiveAppId(0);
            setActiveBool(false);
            setFirmwareActiveId(0); // Reset active app
            setActiveId(0); // Reset active app
          }}
          className={activeTabId === "categories" ? "active" : ""}
        />
      )}
      {auth_apps_permission && (
        <div className="menu-item">
          <div className="menu-content pt-8 pb-2">
            <span className="menu-section text-muted text-uppercase fs-8 ls-1">
              Apps{" "}
              <label className="badge badge-primary">
                {Number(uniqueApps?.length) | 0}
              </label>
            </span>{" "}
            &nbsp;
            <Link to="/app/createApp" className="badge badge-primary">
              Create
            </Link>
          </div>
        </div>
      )}

      {auth_apps_permission && uniqueApps?.length > 0
        ? uniqueApps &&
          uniqueApps?.map((val: { app_id: number; name: string }) => (
            <>
              <div className="menu-item">
                <Link
                  onContextMenu={(e) => e.preventDefault()}
                  onClick={(e) => {
                    setActiveBool(false);
                    setActiveId(Number(val?.app_id));
                    setActiveTabId("");
                    setActiveAppId(0);
                    setSearchStatus(true);
                  }}
                  className={`menu-link without-sub ${
                    activeId === val?.app_id && !activeBool ? "active" : ""
                  }`}
                  to={{
                    pathname: val?.name ? `apps/HP` : "#",
                    search: `?id=${encryptData(val?.app_id)}&name=${val?.name}`,
                  }}
                >
                  <span className="menu-icon">
                    <i className="ki-duotone ki-shield-tick fs-2">
                      <span className="path1"></span>
                      <span className="path2"></span>
                    </i>
                  </span>
                  <span className="menu-title">
                    {capitalizeFirstLetter(val?.name)}
                  </span>
                </Link>
              </div>
            </>
          ))
        : ""}

      {/* <AsideMenuItem to='/apps/HP/demoFrames' icon='shield-tick' title='Frames' /> */}
      {auth_firmware_permission && (
        <div className="menu-item">
          <div className="menu-content pt-8 pb-2">
            <span className="menu-section text-muted text-uppercase fs-8 ls-1">
              Firmware
            </span>
          </div>
        </div>
      )}

      {/* auth_firmware_permission */}

      {auth_firmware_permission && uniqueApps?.length > 0
        ? uniqueApps &&
          uniqueApps?.map((val: { app_id: number; name: string }) => (
            <>
              <div className="menu-item">
                <Link
                  onContextMenu={(e) => e.preventDefault()}
                  onClick={(e) => {
                    setActiveBool(true);
                    setFirmwareActiveId(Number(val?.app_id));
                    setActiveTabId("");
                    setActiveAppId(0);
                  }}
                  className={`menu-link without-sub ${
                    firmwareActiveId === val?.app_id && activeBool
                      ? "active"
                      : ""
                  }`}
                  to={{
                    pathname: val?.name ? `firmware/HP` : "#",
                    search: `?id=${encryptData(val?.app_id)}&name=${val?.name}`,
                  }}
                  state={{
                    firmware_app_id: val?.app_id,
                    firmware_app_name: val?.name,
                  }}
                >
                  <span className="menu-icon">
                    <i className="ki-duotone ki-shield-tick fs-2">
                      <span className="path1"></span>
                      <span className="path2"></span>
                    </i>
                  </span>
                  <span className="menu-title">
                    {capitalizeFirstLetter(val?.name)}
                  </span>
                </Link>
              </div>
            </>
          ))
        : ""}

      <div className="menu-item">
        <div className="menu-content pt-8 pb-2">
          <span className="menu-section text-muted text-uppercase fs-8 ls-1">
            Reports
          </span>
        </div>
      </div>

      <AsideMenuItem
        to="/apps/manage-reports/reports"
        icon="shield-tick"
        title="Manage Reports"
        onClick={() => {
          setActiveTabId("manage-reports");
          setActiveAppId(0);
          setActiveBool(false);
          setFirmwareActiveId(0);
          setActiveId(0);
        }}
        className={activeTabId === "manage-reports" ? "active" : ""}
      />
    </>
  );
}
