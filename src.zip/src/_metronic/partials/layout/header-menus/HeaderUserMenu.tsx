import { FC, useEffect } from "react";
import { Link } from "react-router-dom";
import { Profile, useAuth } from "../../../../app/modules/auth";
import { Languages } from "./Languages";
import { capitalizeFirstLetter, toAbsoluteUrl } from "../../../helpers";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "../../../../store/store";
import { getProfileDetail } from "../../../../store/Auth/authSlice";

const HeaderUserMenu: FC = () => {
  const { currentUser, logout, auth } = useAuth();
  const dispatch = useDispatch<AppDispatch>();
  const { isLoading, isSuccess, fetchDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  useEffect(() => {
    dispatch(getProfileDetail());
  }, []);

  return (
    <div
      className="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px"
      data-kt-menu="true"
      data-popper-placement="bottom-start"
    >
      <div className="menu-item px-3">
        <div className="menu-content d-flex align-items-center px-3">
          <div className="symbol symbol-50px me-5">
            {fetchDetails?.data?.image_url ? (
              <img src={fetchDetails?.data?.image_url} alt="" />
            ) : (
              <img src={toAbsoluteUrl("media/avatars/300-1.jpg")} alt="" />
            )}
            {/* <img alt="Logo" src={toAbsoluteUrl("media/avatars/300-1.jpg")} /> */}
          </div>

          <div className="d-flex flex-column">
            <div className="fw-bolder d-flex align-items-center fs-5">
              {capitalizeFirstLetter(fetchDetails?.data?.first_name || "N/A")}{" "}
              {capitalizeFirstLetter(fetchDetails?.data?.last_name || "N/A")}
              {/* <span className='badge badge-light-success fw-bolder fs-8 px-2 py-1 ms-2'>Pro</span> */}
            </div>
            <a href="#" className="fw-bold text-muted text-hover-primary fs-7">
              {fetchDetails?.data?.email || "N/A"}
            </a>
          </div>
        </div>
      </div>

      <div className="separator my-2"></div>

      <div className="menu-item px-5">
        <Link to={"profile/overview"} className="menu-link px-5">
          My Profile
        </Link>
      </div>

      <div className="separator my-2"></div>

      {/* <Languages /> */}

      {/* <div className='menu-item px-5 my-1'>
        <Link to='/crafted/account/settings' className='menu-link px-5'>
          Account Settings
        </Link>
      </div> */}

      <div className="menu-item px-5 my-1">
        <Link to="profile/changePassword" className="menu-link px-5">
          Change Password
        </Link>
      </div>
      {/* <div className="menu-item px-5 my-1">
        <Link to="/crafted/account/settings" className="menu-link px-5">
          Setting
        </Link>
      </div> */}

      {/* ///crafted/account/settings */}

      <div className="menu-item px-5">
        <Link to={""} onClick={logout} className="menu-link px-5">
          Sign Out
        </Link>
      </div>
    </div>
  );
};

export { HeaderUserMenu };
