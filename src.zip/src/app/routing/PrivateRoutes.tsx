import { FC, lazy, Suspense } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { MasterLayout } from '../../_metronic/layout/MasterLayout'
import TopBarProgress from 'react-topbar-progress-indicator'
import { DashboardWrapper } from '../pages/dashboard/DashboardWrapper'
import { MenuTestPage } from '../pages/MenuTestPage'
import { getCSSVariableValue } from '../../_metronic/assets/ts/_utils'
import { WithChildren } from '../../_metronic/helpers'
import BuilderPageWrapper from '../pages/layout-builder/BuilderPageWrapper'
import ManageRoles from '../pages/manage-roles'
import ManagePermission from '../pages/manage-roles/manage-permissions'
import { FirmwareHP } from '../pages/Firmware/HP'
import { MasterCategories } from '../modules/apps/HP/components/Category/MasterCategories'
import ManageUsers from '../pages/users'
import ManageReports from '../pages/manage-reports'
import { WrapTabList } from '../modules/apps/HP/components/WrapTabList'

interface appsInterface {
  app_name: string,
  app_id: number
}

const PrivateRoutes = () => {
  const { state } = useLocation();
  const { app_id, app_name } = state as appsInterface || {};


  const AppsPage = lazy(() => import('../modules/apps/app/AppPage'));
  const ProfilePage = lazy(() => import('../modules/profile/ProfilePage'));
  const WizardsPage = lazy(() => import('../modules/wizards/WizardsPage'));
  const AccountPage = lazy(() => import('../modules/accounts/AccountPage'));
  const WidgetsPage = lazy(() => import('../modules/widgets/WidgetsPage'));
  const ChatPage = lazy(() => import('../modules/apps/chat/ChatPage'));
  const UsersPage = lazy(() => import('../modules/apps/user-management/UsersPage'));
  const HPPage = lazy(() => import('../modules/apps/HP/HPPage'));
  const CreateStickerCategory = lazy(() => import('../modules/apps/create-sticker-category/indexPage'));

  return (
    <Routes>
      <Route element={<MasterLayout />}>

        <Route path='auth/*' element={<Navigate to='/dashboard' />} />

        {/* Pages */}
        <Route path='dashboard' element={<DashboardWrapper />} />


        <Route
          path='builder'
          element={
            <SuspensedView>
              <BuilderPageWrapper />
            </SuspensedView>
          }
        />
        <Route path='menu-test' element={<MenuTestPage />} />
        {/* Lazy Modules */}

        <Route path={`apps/*`}
          element={
            <SuspensedView>
              <HPPage />
            </SuspensedView>
          }
        />

        <Route
          path='firmware/*'
          element={
            <SuspensedView>
              <FirmwareHP />
            </SuspensedView>
          }
        />

        <Route
          path='app/*'
          element={
            <SuspensedView>
              <AppsPage />
            </SuspensedView>
          }
        />

        <Route
          path='profile/*'
          element={
            <SuspensedView>
              <ProfilePage />
            </SuspensedView>
          }
        />

        <Route
          path='crafted/pages/wizards/*'
          element={
            <SuspensedView>
              <WizardsPage />
            </SuspensedView>
          }
        />
        <Route
          path='crafted/widgets/*'
          element={
            <SuspensedView>
              <WidgetsPage />
            </SuspensedView>
          }
        />
        <Route
          path='crafted/account/*'
          element={
            <SuspensedView>
              <AccountPage />
            </SuspensedView>
          }
        />
        <Route
          path='apps/chat/*'
          element={
            <SuspensedView>
              <ChatPage />
            </SuspensedView>
          }
        />
        <Route
          path='apps/user-management/*'
          element={
            <SuspensedView>
              <UsersPage />
            </SuspensedView>
          }
        />



        <Route
          path='apps/create-sticker-category/*'
          element={
            <SuspensedView>
              <CreateStickerCategory />
            </SuspensedView>
          }
        />

        <Route
          path='apps/manage-roles/*'
          element={
            <SuspensedView>
              <ManageRoles />
            </SuspensedView>
          }
        />

        <Route
          path='apps/manage-users/*'
          element={
            <SuspensedView>
              <ManageUsers />
            </SuspensedView>
          }
        />

        {/* reports are binding here         */}

        <Route
          path='apps/manage-reports/*'
          element={
            <SuspensedView>
              <ManageReports />
            </SuspensedView>
          }
        />


        <Route
          path='apps/categories/*'
          element={
            <SuspensedView>
              <MasterCategories />
            </SuspensedView>
          }
        />
        <Route
          path='apps/manage-permission/*'
          element={
            <SuspensedView>
              <ManagePermission />
            </SuspensedView>
          }
        />

        {/* <Route
          path='auth/change-password'
          element={
            <SuspensedView>
              <ChangePassword />
            </SuspensedView>
          }
        /> */}

        {/* Page Not Found */}
        <Route path='*' element={<Navigate to='/dashboard' />} />
      </Route>
    </Routes>
  )
}
const SuspensedView: FC<WithChildren> = ({ children }) => {
  const baseColor = getCSSVariableValue('--bs-primary')
  TopBarProgress.config({
    barColors: {
      '0': baseColor,
    },
    barThickness: 1,
    shadowBlur: 5,
  })
  return <Suspense fallback={<TopBarProgress />}>{children}</Suspense>
}


export { PrivateRoutes }
