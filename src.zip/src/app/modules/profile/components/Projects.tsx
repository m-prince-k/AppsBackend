import React, { useEffect, useState } from "react";
import { Card2 } from "../../../../_metronic/partials/content/cards/Card2";
import { IconUserModel } from "../ProfileModels";
import { Content } from "../../../../_metronic/layout/components/Content";
import { Profile } from "../../auth/core/_models";
import { useDispatch, useSelector } from "react-redux";
import { useFormik } from "formik";
import * as Yup from "yup";
import { AppDispatch } from "../../../../store/store";

import { getProfileDetail, updateProfile, } from "../../../../store/Auth/authSlice";
import { useNavigate } from "react-router-dom";
import { EventEmitter } from '../../EventEmitter/EventEmitter';


const validationSchema = Yup.object({
  first_name: Yup.string()
    .required("First name is required")
    .min(2, "First name should be at least 2 characters")
    .max(50, "First name cannot exceed 50 characters"),
  last_name: Yup.string()
    .required("Last name is required")
    .min(2, "Last name should be at least 2 characters")
    .max(50, "Last name cannot exceed 50 characters"),
});

export function Projects() {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { isLoading, isSuccess, fetchDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  const formik = useFormik({
    initialValues: {
      first_name: fetchDetails?.data?.first_name || "",
      last_name: fetchDetails?.data?.last_name || "",
    },
    validationSchema,
    onSubmit: async (values, { setStatus, setSubmitting }) => {
      try {
        setLoading(true);
        const data = await dispatch(updateProfile(values));
        await dispatch(getProfileDetail());
        navigate("/profile/overview");
        setLoading(false);
        console.log("Form Submitted", values);
      } catch {
        setSubmitting(false);
      }
    },
  });

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };


  return (
    <>
      <>
        <div className="card mb-5 mb-xl-10">
          <div
            className="card-header border-0 "
            role="button"
            data-bs-toggle="collapse"
            data-bs-target="#kt_account_profile_details"
            aria-expanded="true"
            aria-controls="kt_account_profile_details"
          >
            <div className="card-title m-0">
              <h3 className="fw-bold m-0">Profile Details</h3>
            </div>
          </div>

          <div
            id="kt_account_settings_profile_details"
            className="collapse show"
          >
            <form
              className="form fv-plugins-bootstrap5 fv-plugins-framework"
              onSubmit={formik.handleSubmit}
            >
              <div className="card-body border-top p-9">
                <div className="row mb-6">
                  <label className="col-lg-4 col-form-label required fw-semibold fs-6">
                    Full Name
                  </label>

                  <div className="col-lg-8">
                    <div className="row">
                      <div className="col-lg-6 fv-row fv-plugins-icon-container">
                        <input
                          type="text"
                          name="first_name"
                          className={`form-control form-control-lg mb-3 mb-lg-0 ${formik.errors.first_name &&
                            formik.touched.first_name
                            ? "is-invalid"
                            : ""
                            }`}
                          onKeyDown={handleKeyTextType}
                          maxLength={50}
                          placeholder="First name"
                          {...formik.getFieldProps("first_name")}
                        />
                        {formik.errors.first_name &&
                          formik.touched.first_name && (
                            <div className="invalid-feedback">
                              {typeof formik.errors.first_name === "string"
                                ? formik.errors.first_name
                                : ""}
                            </div>
                          )}
                        <div className="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback"></div>
                      </div>

                      <div className="col-lg-6 fv-row fv-plugins-icon-container">
                        <input
                          type="text"
                          name="last_name"
                          className={`form-control form-control-lg mb-3 mb-lg-0 ${formik.errors.last_name && formik.touched.last_name
                            ? "is-invalid"
                            : ""
                            }`}
                          placeholder="Last name"
                          onKeyDown={handleKeyTextType}
                          maxLength={50}
                          {...formik.getFieldProps("last_name")}
                        />
                        {formik.errors.last_name &&
                          formik.touched.last_name && (
                            <div className="invalid-feedback">
                              {typeof formik.errors.last_name === "string"
                                ? formik.errors.last_name
                                : ""}
                            </div>
                          )}
                        <div className="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback"></div>
                      </div>
                    </div>
                  </div>
                </div>
                  
                <div className="row mb-6">
                  <label className="col-lg-4 col-form-label fw-semibold fs-6">
                    Email
                  </label>

                  <div className="col-lg-8 fv-row">
                    <input
                      type="text"
                      name="website"
                      className="form-control form-control-lg"
                      placeholder="email"
                      value={fetchDetails?.data?.email || ""}
                      disabled
                    />
                  </div>
                </div>
              </div>
              <div className="card-footer d-flex justify-content-end py-6 px-9">
                {/* <button type="reset" className="btn btn-light me-2">
                Discard
              </button> */}
                <button
                  type="submit"
                  className="btn btn-warning"
                  id="kt_account_profile_details_submit"
                  disabled={formik.isSubmitting || !formik.isValid}
                >
                  {loading ? (
                    <span
                      className="indicator-progress"
                      style={{ display: "block" }}
                    >
                      Please wait...{" "}
                      <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                  ) : (
                    <span className="indicator-label">Update</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </>
    </>
  );
}
