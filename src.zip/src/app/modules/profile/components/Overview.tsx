// import { getAllUsersById } from "../../../../../src/app/pages/users/users-list/core/_requests";
// import { Capitalize } from "../../../../../src/_metronic/helpers";
// import { Content } from "../../../../_metronic/layout/components/content";
import { useDispatch, useSelector } from "react-redux";
import { Content } from "../../../../_metronic/layout/components/Content";
import { Profile, useAuth } from "../../auth";
import { useEffect, useState } from "react";
import { AppDispatch } from "../../../../store/store";
import { getProfileDetail } from "../../../../store/Auth/authSlice";
import { capitalizeFirstLetter } from "../../../../_metronic/helpers";
import { UsersListLoading } from "../../apps/user-management/users-list/components/loading/UsersListLoading";

export function Overview() {
  const dispatch = useDispatch<AppDispatch>();
  const { isLoading, isSuccess, fetchDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  // useEffect(() => {
  //   dispatch(getProfileDetail());
  // }, []);

  return (
    <>
      {isLoading ? (
        <div className="d-flex justify-content-center align-items-center">
          {/* <UsersListLoading /> */}
        </div>
      ) : (
        <>
          <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
            <div className="card-header ">
              <div className="card-title m-0">
                <h3 className="fw-bold m-0">Profile Details</h3>
              </div>
            </div>

            <div className="card-body p-9">
              <div className="row mb-7">
                <label className="col-lg-4 fw-bold text-muted">Full Name</label>

                <div className="col-lg-8">
                  <span className="fw-bold fs-6 text-gray-800">
                    {capitalizeFirstLetter(
                      fetchDetails?.data?.full_name || "N/A"
                    )}
                  </span>
                </div>
              </div>

              <div className="row mb-7">
                <label className="col-lg-4 fw-bold text-muted">Email</label>

                <div className="col-lg-8">
                  <span className="fw-bold fs-6 text-gray-800">
                    {fetchDetails?.data?.email || "N/A"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
