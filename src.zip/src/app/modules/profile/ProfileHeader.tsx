import React, { useEffect, useState } from "react";
import {
  capitalizeFirstLetter,
  KTIcon,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../_metronic/helpers";
import { Link, useLocation } from "react-router-dom";
import { Dropdown1 } from "../../../_metronic/partials";
import { AppDispatch } from "../../../store/store";
import { useDispatch, useSelector } from "react-redux";
import {
  getProfileDetail,
  updateProfilePic,
} from "../../../store/Auth/authSlice";
import { Profile } from "../auth/core/_models";
import { SUCCESS } from "../../../util/messages";
import { UsersListLoading } from "../apps/user-management/users-list/components/loading/UsersListLoading";

const ProfileHeader: React.FC = () => {
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const { isLoading, isSuccess, fetchDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  // useEffect(() => {
  //   dispatch(getProfileDetail());
  // }, []);

  const handleEditProfileChange = async (e: any) => {
    setLoading(true);
    const allowedFileTypes = ["image/jpeg", "image/jpg", "image/png"];
    const file = e.target.files?.[0];
    if (file) {
      if (!allowedFileTypes.includes(file.type)) {
        await SwalResponse(
          "warning",
          "Invalid file type",
          "Only .jpeg, .jpg, and .png images are allowed."
        );
        e.target.value = "";
        setLoading(false);
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string); // Set the preview image
      };
      reader.readAsDataURL(file);
      let formData = new FormData();
      formData.append("files", file);

      // Dispatch the action to upload the image
      try {
        const { payload } = await dispatch(updateProfilePic(formData));

        if (payload.status === 403) {
          await SwalResponse("danger", payload.message, payload.error_details);
        } else if (payload.status === 500) {
          await SwalResponse("danger", payload.message, payload.error_details);
        } else if (payload.status === 200) {
          await dispatch(getProfileDetail());
          await SwalResponse(
            "success",
            payload.message,
            SUCCESS.UPDATEPROFILEPIC
          );
        }
        setLoading(false);
      } catch (error) {
        console.error("Error uploading profile picture", error);
      }
    }
  };

  return (
    <>
      {location.pathname != "/profile/changePassword" && (
        <div className="card mb-5 mb-xl-10">
          <div className="card-body pt-9 pb-0">
            {isLoading ? (
              <div className="d-flex justify-content-center align-items-center">
                <UsersListLoading />
              </div>
            ) : (
              <>
                <div className="d-flex flex-wrap flex-sm-nowrap mb-3">
                  <div className="me-7 mb-4">
                    <div className="symbol symbol-100px symbol-lg-160px symbol-fixed position-relative">
                      {preview ? (
                        <img src={preview} alt="Profile Preview" />
                      ) : fetchDetails?.data?.image_url ? (
                        <img
                          src={fetchDetails?.data?.image_url}
                          alt="Profile"
                        />
                      ) : (
                        <img
                          src={toAbsoluteUrl("media/avatars/300-1.jpg")}
                          alt="Default Avatar"
                        />
                      )}
                      <div className="position-absolute translate-middle bottom-0 start-100 mb-6 bg-success rounded-circle border border-4 border-white h-20px w-20px"></div>
                    </div>
                  </div>
                  {loading && <UsersListLoading />}
                  <div className="flex-grow-1">
                    <div className="d-flex justify-content-between align-items-start flex-wrap mb-2">
                      <div className="d-flex flex-column">
                        <div className="d-flex align-items-center mb-2">
                          <label className="text-gray-800  fs-2 fw-bolder me-1">
                            {capitalizeFirstLetter(
                              fetchDetails?.data?.full_name
                            ) || "N/A"}
                          </label>
                          <a href="#">
                            <KTIcon
                              iconName="verify"
                              className="fs-1 text-primary"
                            />
                          </a>
                        </div>

                        <div className="d-flex flex-wrap fw-bold fs-6 mb-4 pe-2">
                          <span className="d-flex align-items-center text-gray-500 me-5 mb-2">
                            <KTIcon
                              iconName="profile-circle"
                              className="fs-4 me-1"
                            />
                            {fetchDetails?.data?.access_type
                              ?.access_type_name || "N/A"}
                          </span>
                          {/* <a
                    href='#'
                    className='d-flex align-items-center text-gray-500 text-hover-primary me-5 mb-2'
                  >
                    <KTIcon iconName='geolocation' className='fs-4 me-1' />
                    SF, Bay Area
                  </a> */}
                          <span className="d-flex align-items-center text-gray-500 mb-2">
                            <KTIcon iconName="sms" className="fs-4 me-1" />
                            {fetchDetails?.data?.email}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="upload-profile-pic mb-4">
                  <span className="btn btn-light-info btn-sm">Change Your Picture</span>
                <input
                  type="file"
                  id="files"
                  className="form-control"
                  title="Upload Profile Pic"
                  accept="image/*"
                  onChange={handleEditProfileChange}
                />
                </div>
                <div className="d-flex overflow-auto h-55px">
                  <ul className="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder flex-nowrap">
                    <li className="nav-item">
                      <Link
                        className={
                          `nav-link text-active-primary me-6 ` +
                          (location.pathname === "/profile/overview" &&
                            "active")
                        }
                        to="/profile/overview"
                        state={fetchDetails?.data}
                      >
                        Overview
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link
                        className={
                          `nav-link text-active-primary me-6 ` +
                          (location.pathname === "/profile/profile-details" &&
                            "active")
                        }
                        to="/profile/profile-details"
                      >
                        Profile
                      </Link>
                    </li>
                  </ul>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
};
export { ProfileHeader };
