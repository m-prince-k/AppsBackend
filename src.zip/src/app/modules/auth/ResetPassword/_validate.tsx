// src/validate.ts
import * as Yup from "yup";

export const initialValues = {
  password: "",
  confirmpassword: "",
};

export const validationSchema = Yup.object({
  password: Yup.string()
    .required("New password is required.")
    .min(8, "Password must be at least 8 characters long.")
    .matches(
      /[A-Za-z0-9]/,
      "Password must contain at least one letter or number."
    )
    .matches(/[^A-Za-z0-9]/, "Password must contain at least one symbol.")
    .matches(/[A-Z]/, "Password must contain at least one uppercase letter."),
  confirmpassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Passwords must match.")
    .required("Confirm password is required."),
});
