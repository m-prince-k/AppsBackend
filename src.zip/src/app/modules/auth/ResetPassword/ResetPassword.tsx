import { useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { initialValues, validationSchema } from "./_validate";
import { useFormik } from "formik";
import { resetPassWord } from "../../../../store/Auth/authSlice";
import { AppDispatch } from "../../../../store/store";
import { useDispatch } from "react-redux";
import usePageTitle from "../components/PageTitle/usePageTitle";
import moment from "moment";

const ResetPassword = () => {
  const navigate = useNavigate();
  const [isVisible1, setVisible1] = useState(false);
  const [isVisible2, setVisible2] = useState(false);
  const [isVisible3, setVisible3] = useState(false);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const { search, pathname } = useLocation();
  pathname == "/auth/reset-password" ? usePageTitle("Reset Password") : "";
  const queryParams = new URLSearchParams(search);
  const token = queryParams.get("token");
  const type = queryParams.get("type");
  const time=queryParams.get("time");


  const oldTime=moment(parseInt(time)).add(10,'minutes').format('mm:ss');
  const currentTime=moment().format("mm:ss");


  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      try {
        setLoading(true);
        const { confirmpassword, ...data } = values;
        const payload = {
          token: token,
          type: type,
          ...data,
        };
        console.log(payload);

        const data1 = await dispatch(resetPassWord(payload));
        navigate("/auth/forgot-password");
        console.log("Form submitted:", values);
        // You can add API request logic here
        formik.resetForm();
      } catch (error) {
        console.error(error);
      }
    },
  });

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };
 
  return (
    <>
    { 
      oldTime > currentTime  ? (
        <>
            <div className="row align-items-center justify-content-center h-100">
        <h1 className="fw-bold mb-10 text-center">Reset Password</h1>
        <div className="col-md-12">
          <form
            id="kt_signin_change_password"
            className="form"
            onSubmit={formik.handleSubmit}
            noValidate
          >
            <div className="row mb-1">
              <div className="col-lg-12 mb-5">
                <div className="fv-row mb-0">
                  <label
                    htmlFor="password"
                    className="form-label fs-6 fw-bolder mb-3"
                  >
                    New Password
                  </label>
                  <div className="d-flex position-relative">
                    <input
                      type={!isVisible2 ? "password" : "text"}
                      className={`form-control form-control-lg ${
                        formik.touched.password && formik.errors.password
                          ? "is-invalid"
                          : ""
                      }`}
                      id="password"
                      name="password"
                      placeholder="Enter the new password"
                      value={formik.values.password}
                      onKeyDown={handleKeyTextType}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {isVisible2 ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible2(!isVisible2)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible2(!isVisible2)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                  </div>
                  {formik.touched.password && formik.errors.password && (
                    <div className="invalid-feedback d-block">
                      {formik.errors.password}
                    </div>
                  )}
                </div>
              </div>

              <div className="col-lg-12 mb-5">
                <div className="fv-row mb-0">
                  <label
                    htmlFor="confirmpassword"
                    className="form-label fs-6 fw-bolder mb-3"
                  >
                    Confirm Password
                  </label>
                  <div className="d-flex position-relative">
                    <input
                      type={!isVisible3 ? "password" : "text"}
                      className={`form-control form-control-lg ${
                        formik.touched.confirmpassword &&
                        formik.errors.confirmpassword
                          ? "is-invalid"
                          : ""
                      }`}
                      id="confirmpassword"
                      name="confirmpassword"
                      onKeyDown={handleKeyTextType}
                      placeholder="Enter the confirm password"
                      value={formik.values.confirmpassword}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {isVisible3 ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible3(!isVisible3)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible3(!isVisible3)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                  </div>
                  {formik.touched.confirmpassword &&
                    formik.errors.confirmpassword && (
                      <div className="invalid-feedback d-block">
                        {formik.errors.confirmpassword}
                      </div>
                    )}
                </div>
              </div>
            </div>

            <div className="form-text mb-5 text-end">
              Password must be at least 8 characters and contain symbols
            </div>

            <div className="d-flex justify-content-end">
              <Link
                to={"/"}
                id="kt_password_cancel"
                type="button"
                className="btn btn-color-gray-500 btn-light-secondary  px-6 me-2 w-50"
              >
                Cancel
              </Link>
              <button
                id="kt_password_submit"
                type="submit"
                className="btn btn-primary px-6 w-50"
              >
                Reset Password
              </button>
            </div>
          </form>
        </div>
      </div>
        </>
      ) : 
      (
        <>
          <h1>Your Link is Expired, Please try again</h1>
        <Link to={"/auth/forgot-password"} className="btn btn-primary text-center">Forgot Password</Link>
        </>
      )
    }
   
    </>
  );
};
export { ResetPassword };
