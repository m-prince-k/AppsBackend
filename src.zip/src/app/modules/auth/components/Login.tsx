import { useEffect, useState } from "react";
import * as Yup from "yup";
import clsx from "clsx";
import { Link, Navigate } from "react-router-dom";
import { useFormik } from "formik";
import { getUserByToken, login } from "../core/_requests";
import { SwalResponse, toAbsoluteUrl } from "../../../../_metronic/helpers";
import { useAuth } from "../core/Auth";

import {
  demoGettingResponse,
  loginWithMicrosoft,
  makeLogin,
} from "../../../../store/Auth/authSlice";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "../../../../store/store";

import { useAuth0 } from "@auth0/auth0-react";
import usePageTitle from "./PageTitle/usePageTitle";
import { loginSchema } from "./_validate";
import { TITLE } from "../../../../util/messages";
import moment from "moment";

const initialValues = {
  email: "",
  password: "",
};

/*
  Formik+YUP+Typescript:
  https://jaredpalmer.com/formik/docs/tutorial#getfieldprops
  https://medium.com/@maurice.de.beijer/yup-validation-and-typescript-and-formik-6c342578a20e
*/

export function Login() {
  usePageTitle("Login");
  const [loading, setLoading] = useState(false);
  const { saveAuth, setCurrentUser } = useAuth();
  const [isVisible, setVisible] = useState(false);
  const [count, setCount] = useState(1);
  const dispatch = useDispatch<AppDispatch>();
  const { demoDetails } = useSelector((state: any) => state.auth);
  const [showPassword,setShowPassword]=useState(true);
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");

  useEffect(() => {
    dispatch(demoGettingResponse());
  }, []);

  const formik = useFormik({
    initialValues,
    validationSchema: loginSchema,
    onSubmit: async (values, { setStatus, setSubmitting }) => {
      setLoading(true);
      try {
        
          const auth = await login(values.email, values.password);

          const { status, message, error_details } = auth?.data;
  
          if (status === 200) {
            const auth_details = auth?.data;
            saveAuth(auth_details?.data);
            const { data: user } = await getUserByToken(auth_details?.data);
            if(+user?.status==200) {
              setCurrentUser(user);
            }
            //}
          } else if (
            status === 401 ||
            status === 500 ||
            status === 404 ||
            status === 429
          ) {
            await SwalResponse("danger", message, error_details);
          } else {
            await SwalResponse("danger", message, error_details);
          }
          setSubmitting(false);
          setLoading(false);
        // return auth;
      } catch (error) {
        // Handle error during login process
        const {response}=error;
        if(response?.data) {
          SwalResponse("warning","Warning",response?.data?.error_details)
        }
        saveAuth(undefined); // Clear any saved authentication data on error
        setStatus("The login details are incorrect");
        setSubmitting(false); // Mark the form as not submitting
        setLoading(false); // Hide loading spinner
      }
    },
  });

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  const handleSignInMicrosoft = async (e:any) => {
    try {
        // here is the case for socialite login along with microsoft
        e.preventDefault();
        if(email) {
          const {payload}=await dispatch(loginWithMicrosoft({email:email}));
          if(payload?.status==200) {
            console.log(payload?.data);
            window.open(payload?.data,'_self');
          }
        } else {
          await SwalResponse("warning","Warning","Email should not be empty")
        }
    } catch (error) {
      throw error;
    }
  }


 

  return (
    <>
      <form
        className="form w-100"
        onSubmit={formik.handleSubmit}
        noValidate
        id="kt_login_signin_form"
      >
        {/* begin::Heading */}
        <div className="text-center mb-11">
          <h1 className="text-gray-900 fw-bolder mb-3">Sign In</h1>
          <div className="text-gray-500 fw-semibold fs-6">
            Your Appsbackend Portal
          </div>
        </div>
        {/* begin::Heading */}

        {/* begin::Form group */}
        {
          showPassword ? 
          <>
            <div className="fv-row mb-8">
          <label className="form-label fs-6 fw-bolder text-gray-900">
            Email
          </label>
          <input
            placeholder="Enter the email"
            {...formik.getFieldProps("email")}
            className={clsx(
              "form-control bg-transparent",
              { "is-invalid": formik.touched.email && formik.errors.email },
              {
                "is-valid": formik.touched.email && !formik.errors.email,
              }
            )}
            onKeyDown={(e) => {
              if (e.key === " ") {
                e.preventDefault();
              }
            }}
            type="email"
            name="email"
            autoComplete="off"
          />
          {formik.touched.email && formik.errors.email && (
            <div className="fv-plugins-message-container">
              <div className="fv-help-block">
                <span role="alert">{formik.errors.email}</span>
              </div>
            </div>
          )}
        </div>
          </>
          :
          <div className="fv-row mb-8">
          <label className="form-label fs-6 fw-bolder text-gray-900">
            Email
          </label>
          <input
            placeholder="Enter the email"
            onChange={(e) => setEmail(e.target.value)}
            className="form-control"
            onKeyDown={(e) => {
              if (e.key === " ") {
                e.preventDefault();
              }
            }}
            type="email"
            name="email"
            autoComplete="off"
          />
        
        </div>


        }
      
        {/* end::Form group */}

        {/* begin::Form group */}
        {
            showPassword && 
            <div className="fv-row mb-3">
            <label className="form-label fw-bolder text-gray-900 fs-6 mb-0">
              Password
            </label>
            <div className="d-flex position-relative">
              <input
                type={!isVisible ? "password" : "text"}
                placeholder="Enter the password"
                autoComplete="off"
                {...formik.getFieldProps("password")}
                onKeyDown={handleKeyTextType}
                className={clsx(
                  "form-control bg-transparent",
                  {
                    "is-invalid":
                      formik.touched.password && formik.errors.password,
                  },
                  {
                    "is-valid":
                      formik.touched.password && !formik.errors.password,
                  }
                )}
              />
              {isVisible ? (
                <i
                  className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                  onClick={() => setVisible(!isVisible)}
                >
                  <span className="path1"></span>
                  <span className="path2"></span>
                  <span className="path3"></span>
                </i>
              ) : (
                <i
                  className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                  onClick={() => setVisible(!isVisible)}
                >
                  <span className="path1"></span>
                  <span className="path2"></span>
                  <span className="path3"></span>
                  <span className="path4"></span>
                </i>
              )}
              
            </div>
            
            {formik.touched.password && formik.errors.password && (
              <div className="fv-plugins-message-container">
                <div className="fv-help-block">
                  <span role="alert">{formik.errors.password}</span>
                </div>
              </div>
            )}
          </div>
        }
     

     {/* here checkbox are embed for sign in with microsoft */}
     
    <input type="checkbox" onChange={(e) => {
      if(e.target.checked) {
        setShowPassword(false);
      } else {
        setShowPassword(true);
      }
    }} /> Sign in With Microsoft

        {/* end::Form group */}
        {/* begin::Wrapper */}
        <div className="d-flex flex-stack flex-wrap gap-3 fs-base fw-semibold mb-8">
          <div />

          {/* begin::Link */}
          {/* <Link to="/auth/forgot-password" className="link-primary">
            Forgot Password ?
            
          </Link> */}
          {/* end::Link */}
        </div>
        {/* end::Wrapper */}

        {/* begin::Action */}
        {
          !showPassword ?
          <button className="btn btn-primary" onClick={handleSignInMicrosoft}>Sign in with Microsoft</button>
          : 
          <>
            <div className="d-grid mb-10">
          <button
            type="submit"
            id="kt_sign_in_submit"
            className="btn btn-primary"
            disabled={formik.isSubmitting || !formik.isValid}
          >
            {!loading && <span className="indicator-label">Continue</span>}
            {loading && (
              <span className="indicator-progress" style={{ display: "block" }}>
                Please wait...
                <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
              </span>
            )}
          </button>
        </div>
          </>
        }
      

        {/* <div className="text-gray-500 text-center fw-semibold fs-6">
          Not a Member yet?{" "}
          <Link to="/auth/registration" className="link-primary">
            Sign up
          </Link>
          <button
            style={{ display: "none" }}
            onClick={() => loginWithRedirect()}
          >
            Log In
          </button>
        </div> */}
      </form>
    </>
  );
}
