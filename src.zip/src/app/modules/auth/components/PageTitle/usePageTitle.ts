import { useEffect } from "react";
import { capitalizeFirstLetter } from "../../../../../_metronic/helpers";

const usePageTitle = (title:string) => {
  useEffect(() => {
    document.title = "AppsBackend | " + capitalizeFirstLetter(title);
  }, [title]);
};

export default usePageTitle;