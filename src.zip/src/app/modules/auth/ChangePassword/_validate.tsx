// src/validate.ts
import * as Yup from "yup";

export const initialValues = {
  old_password: "",
  new_password: "",
  confirmpassword: "",
};

export const validationSchema = Yup.object({
  old_password: Yup.string()
    .required("Current password is required")
    .min(8, "Current password must be at least 8 characters"),

  new_password: Yup.string()
    .required("New password is required")
    .min(8, "New password must be at least 8 characters")
    .matches(
      /[A-Za-z0-9]/,
      "Password must contain at least one letter or number."
    )
    .matches(/[^A-Za-z0-9]/, "Password must contain at least one symbol.")
    .matches(/[A-Z]/, "Password must contain at least one uppercase letter."),

  confirmpassword: Yup.string()
    .oneOf([Yup.ref("new_password"), null], "Passwords must match")
    .required("Confirm new password is required"),
});
