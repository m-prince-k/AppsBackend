import { useFormik } from "formik";
import { PageLink, PageTitle } from "../../../../_metronic/layout/core";
import { initialValues, validationSchema } from "./_validate";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../../../store/store";
import { changePassWord } from "../../../../store/Auth/authSlice";
import { useAuth } from "../core/Auth";
import { useNavigate } from "react-router-dom";

const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "Change Password",
    path: "auth/change-password",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

const ChangePassword = () => {
  const navigate = useNavigate();
  const {logout} = useAuth()
  const [isVisible1, setVisible1] = useState(false);
  const [isVisible2, setVisible2] = useState(false);
  const [isVisible3, setVisible3] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);

  const formik = useFormik({
    initialValues: initialValues,
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      try {
        setLoading(true);
        const { confirmpassword, ...data } = values;
        const payload = {
          type: "change_password",
          ...data,
        };
        const data1 = await dispatch(changePassWord(payload));
    
        logout();
        navigate("/");
        // const auth_details = data?.payload?.data;
        formik.resetForm();
        setLoading(false);
      } catch (error) {
        console.error(error);
      }
    },
  });

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  return (
    <>
      <div className="row align-items-center justify-content-center h-100">
        <div className="col-md-6 col-lg-4 card p-10">
          <h2 className="text-center fs-1 fw-bold mb-10">Change Password</h2>
          <form
            id="kt_signin_change_password"
            className="form"
            onSubmit={formik.handleSubmit}
            noValidate
          >
            <div className="row mb-1">
              <div className="col-lg-12 mb-5">
                <div className="fv-row mb-0">
                  <label
                    htmlFor="old_password"
                    className="form-label fs-6 fw-bolder mb-3"
                  >
                    Old Password
                  </label>
                  <div className="d-flex position-relative flex-wrap">
                    <input
                      type={!isVisible1 ? "password" : "text"}
                      className={`form-control form-control-lg ${
                        formik.touched.old_password &&
                        formik.errors.old_password
                          ? "is-invalid"
                          : ""
                      }`}
                      id="old_password"
                      name="old_password"
                      placeholder="Enter the old password"
                      onKeyDown={handleKeyTextType}
                      value={formik.values.old_password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {isVisible1 ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible1(!isVisible1)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible1(!isVisible1)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                    {formik.touched.old_password &&
                      formik.errors.old_password && (
                        <div className="invalid-feedback">
                          {formik.errors.old_password}
                        </div>
                      )}
                  </div>
                </div>
              </div>

              <div className="col-lg-12 mb-5">
                <div className="fv-row mb-0">
                  <label
                    htmlFor="new_password"
                    className="form-label fs-6 fw-bolder mb-3"
                  >
                    New Password
                  </label>
                  <div className="d-flex position-relative flex-wrap">
                    <input
                      type={!isVisible2 ? "password" : "text"}
                      className={`form-control form-control-lg ${
                        formik.touched.new_password &&
                        formik.errors.new_password
                          ? "is-invalid"
                          : ""
                      }`}
                      id="new_password"
                      name="new_password"
                      onKeyDown={handleKeyTextType}
                      value={formik.values.new_password}
                      placeholder="Enter the new password"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {isVisible2 ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible2(!isVisible2)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible2(!isVisible2)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                    {formik.touched.new_password &&
                      formik.errors.new_password && (
                        <div className="invalid-feedback">
                          {formik.errors.new_password}
                        </div>
                      )}
                  </div>
                </div>
              </div>

              <div className="col-lg-12 mb-5">
                <div className="fv-row mb-0">
                  <label
                    htmlFor="confirmpassword"
                    className="form-label fs-6 fw-bolder mb-3"
                  >
                    Confirm New Password
                  </label>
                  <div className="d-flex position-relative flex-wrap">
                    <input
                      type={!isVisible3 ? "password" : "text"}
                      className={`form-control form-control-lg ${
                        formik.touched.confirmpassword &&
                        formik.errors.confirmpassword
                          ? "is-invalid"
                          : ""
                      }`}
                      id="confirmpassword"
                      name="confirmpassword"
                      onKeyDown={handleKeyTextType}
                      placeholder="Enter the confirm password"
                      value={formik.values.confirmpassword}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {isVisible3 ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible3(!isVisible3)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible3(!isVisible3)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                    {formik.touched.confirmpassword &&
                      formik.errors.confirmpassword && (
                        <div className="invalid-feedback">
                          {formik.errors.confirmpassword}
                        </div>
                      )}
                  </div>
                </div>
              </div>
            </div>

            <div className="form-text mb-5 text-end">
              Password must be at least 8 characters and contain symbols
            </div>

            <div className="d-flex justify-content-end">
              <button
                id="kt_password_cancel"
                type="button"
                className="btn btn-color-gray-500 btn-light-secondary px-6 me-2 w-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                id="kt_password_submit"
                type="submit"
                className="btn btn-primary px-6 w-50"
                disabled={formik.isSubmitting || !formik.isValid}
              >
                {loading ? "Please Wait" : "Update Password"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default ChangePassword;
