// import { ID, Response } from "../../../../../../_metronic/helpers"
export type Rack = {
  rack_name?:string,
  id?:number,
  obsolete_ind?:boolean;
  rack_number?:string,
}

export const HemispheresRegions = ["North","South"]

export const Locales = ["de-DE","en-AE","en-AR","en-AT","en-AU","en-BE",
    "en-BR","en-CA","en-CH","en-CL","en-CN","en-CO","en-CZ","en-DE","en-ES",
    "en-GB","en-GR","en-HK","en-IL","en-IN","en-IT","en-ME",
]

export const groups=[
    "BTS English::en-ae,en-AT,en-BE,en-ch,en-cz,en-De,en-es, en-FR, en-GB,en-gr,en-ll,en-IT,en-ME,en-ng,en-NL,en-Pl,en-sa,en-TR,en-TH",
    "BTS::ae,AT,BE,CH,cz,DE,ES, FR,GB,gr,IL,IT,ME, ng, NL,PL,sa, TR,TH",
    "North Hem English::en-AT,en-ca,en-CN,en-DE,en-ES,en-FR,en-GB,en-hk,en-IN,en-IT,en-MY,en-ng,en-NL,en-PH,en-SG, en-US,en-HK,en-TW,en-GR,en-cz,en-pl,en-sa, en-me, en-ae, en-il, en-tr,en-ng,en-ch,en-be",
    "South Hem English::en-au,en-nz,en-za",
]

export const regions =["AE","AR","AT"];

export const language=["AE","AR","AT"];

export const min_ios_app_version=["2.11.0","2.12.0","2.14.0","2.22.0"];

export const max_ios_app_version=["1.0.0","2.10.0","2.11.0"];

export const min_android_app_version=["3.11.0","5.12.0"];

export const max_android_app_version=["4.0.0","3.10.0","6.11.0"];

export const gps_coordinates=["Elle Hollywood","Fusion Music Festival","OHP Reinvent in Houston, TX"];

export const device_type=["Bahama","Grand Bahama","ibiza"];



