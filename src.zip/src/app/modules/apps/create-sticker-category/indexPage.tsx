import { Route, Routes, Outlet, Navigate } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../../_metronic/layout/core'
import CreateCategory from '../HP/components/Category/CreateCategory'
import { useState } from 'react';


const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "Create Sticker Category",
    path: "/apps/create-sticker-category/categories",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

interface FormData {
  title: string;
  analytics: string;
  position: string;
  isActive: boolean;
  hemispheres: {
    north: boolean;
    south: boolean;
  };
}

// Define the type for errors
interface Errors {
  title: string;
  position: string;
  hemispheres: string;
}

const CreateStickerCategory = () => {
  const [formData, setFormData] = useState<FormData>({
    title: "",
    analytics: "",
    position: "",
    isActive: true,
    hemispheres: { north: false, south: false },
  });

  // State for error messages
  const [errors, setErrors] = useState({
    title: "",
    position: "",
    hemispheres: "",
  });

  // Handle form field changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    if (name === "hemispheres") {
      setFormData({
        ...formData,
        hemispheres: { ...formData.hemispheres, [value]: checked },
      });
    } else {
      setFormData({
        ...formData,
        [name]: type === "checkbox" ? checked : value,
      });
    }
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
  };

  // Validation function
  const validateForm = () => {
    let isValid = true;
    const newErrors: Errors = { title: "", position: "", hemispheres: "" };

    // Title validation
    if (!formData.title.trim()) {
      newErrors.title = "Title is required";
      isValid = false;
    }

    // Position validation
    if (!formData.position.trim()) {
      newErrors.position = "Position is required";
      isValid = false;
    }

    // Hemispheres validation
    if (!formData.hemispheres.north && !formData.hemispheres.south) {
      newErrors.hemispheres = "Please select at least one hemisphere";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      setFormData({
        title: "",
        analytics: "",
        position: "",
        isActive: true,
        hemispheres: { north: false, south: false },
      });
    }
  };
  console.log(errors);

  return (
    <Routes>
      <Route element={<Outlet />}>
        <Route
          path="categories"
          element={
            <>
              <PageTitle breadcrumbs={usersBreadcrumbs}>Create Sticker Category</PageTitle>
              <CreateCategory/>
            </>
          }
        />
      </Route>
      <Route
        index
        element={<Navigate to="/apps/create-sticker-category/categories" />}
      />
    </Routes>
  );
};

export default CreateStickerCategory;
