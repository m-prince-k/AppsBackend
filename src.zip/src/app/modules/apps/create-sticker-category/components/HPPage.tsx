import { Route, Routes, Outlet, Navigate } from "react-router-dom";
import { PageLink, PageTitle } from "../../../../../_metronic/layout/core";
import { WrapTabList } from "../../HP/components/WrapTabList";
import { useAuth } from "../../../auth";

const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "HP",
    path: "/apps/HP/HP",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

const HPPage = () => {
  const { currentUser, auth } = useAuth();
  const auth_apps_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager" ||
    auth?.access_type?.access_type_name === "General Users";

  // If the user doesn't have the necessary permissions, redirect them to a 404 page
  if (!auth_apps_permission) {
    return <Navigate to="/error/404" />;
  }
  return (
    <Routes>
      <Route element={<Outlet />}>
        <Route
          path="HP"
          element={
            <>
              <PageTitle breadcrumbs={usersBreadcrumbs}>HP</PageTitle>
              <div className="card">
                <div className="card-body">
                  <WrapTabList />
                </div>
              </div>
            </>
          }
        />
      </Route>
      {auth_apps_permission && (
        <Route index element={<Navigate to="/apps/HP/HP" />} />
      )}
    </Routes>
  );
};

export default HPPage;
