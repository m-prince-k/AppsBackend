import { Route, Routes, Outlet, Navigate, useLocation, useNavigate } from "react-router-dom";
import { PageLink, PageTitle } from "../../../../_metronic/layout/core";
import { WrapTabList } from "./components/WrapTabList";
import AddSticker from "./components/Sticker/AddSticker";
import ViewStickers from "./components/Sticker/ViewStickers";
import EditCategories from "./components/Category/EditCategories";
import StickerCategories from "./components/Category/StickerCategories";
import SingleSticker from "./components/Category/SingleSticker";
import { FrameGenerate } from "../../../pages/Frames/FrameGenerate";
import FramesListing from "../../../pages/Frames/FramesListing";
import { ArchivedCategories } from "./components/Category/ArchivedCategories";
import AddFrame from "./components/Frame/AddFrame";
import { useAuth } from "../../auth";
import ViewFrames from "./components/Frame/ViewFrames";
import { useEffect } from "react";
const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "HP",
    path: "/apps/HP/HP",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

interface appsData {
  app_id: number,
  app_name: string
}

const HPPage = () => {

  const { currentUser, auth } = useAuth();
  const {pathname,search}=useLocation();
  const navigate=useNavigate();
  
  const auth_apps_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager" ||
    auth?.access_type?.access_type_name === "General Users";

    const searchParams = new URLSearchParams(search);

    const paramsId = searchParams.get("id") || searchParams.get("name") || searchParams.get("catId") || searchParams.get("firmware_id");

    useEffect(() => {
      if ((pathname === "/firmware/HP" || pathname === "/apps/HP" && !paramsId)) {
        navigate("/error/404");
      }
    }, [location, paramsId, navigate]);

  // If the user doesn't have the necessary permissions, redirect them to a 404 page
  if (!auth_apps_permission) {
    return <Navigate to="/error/404" />;
  }
  return (

    <Routes>
      <Route element={<Outlet />}>
        <Route
          path="HP"
          element={
            <>
              <PageTitle breadcrumbs={usersBreadcrumbs}>HP</PageTitle>
              <div className="card">
                <div className="card-body">
                  <WrapTabList />
                </div>
              </div>
            </>
          }
        />


        <Route
          path="archivedCategory"
          element={
            <>
              <PageTitle>Archived Categories</PageTitle>
              <ArchivedCategories />
            </>
          }
        />

        <Route
          path="frameListing"
          element={
            <>
              <PageTitle>FrameListing</PageTitle>
              <FramesListing />
            </>
          }
        />

        <Route
          path="addStickers"
          element={
            <>
              <PageTitle>Stickers</PageTitle>
              <AddSticker />
            </>
          }
        />

        <Route
          path="addFrame"
          element={
            <>
              <PageTitle>Frame</PageTitle>
              <AddFrame />
            </>
          }
        />

        <Route
          path="demoFrames"
          element={
            <>
              <PageTitle>Frames</PageTitle>
              <FrameGenerate />
            </>
          }
        />

        <Route
          path="viewSticker"
          element={
            <>
              <PageTitle>View Sticker</PageTitle>
              <ViewStickers />
            </>
          }
        />

        <Route
          path="viewFrame"
          element={
            <>
              <PageTitle>View Frame</PageTitle>

              <ViewFrames />
            </>
          }
        />

        <Route
          path="editCategory"
          element={
            <>
              <PageTitle>View Category </PageTitle>
              <EditCategories />
            </>
          }
        />
        <Route
          path="stickerCategories"
          element={
            <>
              <PageTitle>Sticker Categories </PageTitle>

              <StickerCategories />
            </>
          }
        />

        <Route
          path="singleSticker"
          element={
            <>
              <PageTitle>Sticker </PageTitle>

              <SingleSticker />
            </>
          }
        />


      </Route>
      {auth_apps_permission && (
        <Route index element={<Navigate to="/apps/HP/HP" />} />
      )}
    </Routes>
  );
};

export default HPPage;
