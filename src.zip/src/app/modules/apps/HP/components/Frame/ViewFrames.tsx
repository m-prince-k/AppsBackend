import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AppDispatch } from "../../../../../../store/store";
import { useEffect, useState } from "react";
import {
  activeStickerDeActiveFrame,
  viewSticker,
} from "../../../../../../store/HP/Sticker/stickerSlice";
import {
  capitalizeFirstLetter,
  decryptData,
  encryptData,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../_metronic/helpers";
import ReactPaginate from "react-paginate";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import { Profile, useAuth } from "../../../../auth";
import { Tooltip } from "react-tooltip";
import {
  specificFrameStatusUpdate,
  viewFrame,
} from "../../../../../../store/HP/Frame/frameSlice";
import { PageLink, PageTitle } from "../../../../../../_metronic/layout/core";

interface frameDetail {
  sticker_id: number;
  app_id: number;
  category_id: any;
  app_name: string;
}

const usersBreadcrumbs: Array<PageLink> = [
  // {
  //   title: "View Frames",
  //   path: "#",
  //   isSeparator: false,
  //   isActive: false,
  // },
  // {
  //   title: "",
  //   path: "",
  //   isSeparator: true,
  //   isActive: false,
  // },
];

const ViewFrame = () => {
  const navigate = useNavigate();
  const { currentUser, auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;

  const { search, state } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  let filterCatId =
    searchParams.get("catId") && decryptData(searchParams.get("catId"));

  const app_id = filterId;
  const app_name = searchParams.get("name");
  const category_id = filterCatId;

  // const { category_id } = (state as frameDetail) || {};

  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const itemsPerPage = ITEM_PER_PAGE;
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentItems, setCurrentItems] = useState([]);
  const [totalRec, setTotalRec] = useState(0);
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
    isActive5: true,
    isActive6: true,
    isActive7: true,
  });
  const [frame, setFrame] = useState<any[]>([]);

  useEffect(() => {
    fetchViewSticker();
  }, [currentPage, itemsPerPage, sortKey?.key, sortKey?.order]);

  async function fetchViewSticker() {
    let queryParams = "";
    setLoading(true);
    try {
      if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          app_id
        )}&category_id=${category_id}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        //here concat the key for paginatgion is here
        queryParams = `?app_id=${Number(
          app_id
        )}&category_id=${category_id}&page=${Number(
          currentPage
        )}&items_per_page=${Number(itemsPerPage)}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(viewFrame(queryParams));
      setLoading(false);
      if (payload?.status === 200) {
        setFrame(payload?.data);
        setTotalRec(payload?.count);
      } else if (payload?.status === 403) {
        throw payload?.error_details;
      }
    } catch (error) {
      throw error;
    }
  }

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "metadata") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "metadata") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    } else if (order == "ASC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: false }));
    } else if (order == "DESC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: true }));
    }
  };

  //PAGINATION START HERE FOR ASSET SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    if (Array.isArray(frame)) {
      setCurrentItems(frame.slice(itemOffset, endOffset));
    }
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, frame]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % frame?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };
  //END OF PAGINATION

  const categoryID = frame && frame?.length > 0 ? frame[0]?.category_id : null;
  const appID = frame && frame?.length > 0 ? frame[0]?.app_id : null;

  const handleSpecificFrameActiveDeactivate = async (
    e: any,
    cagtegoryId: number,
    frame_id: number,
    status: boolean
  ) => {
    try {
      e.preventDefault();

      let statusSet = false;
      if (status === true) {
        statusSet = false;
      } else {
        statusSet = true;
      }

      if (cagtegoryId) {
        let _payload: object = {
          category_id: cagtegoryId,
          frame_id: frame_id,
          status: statusSet,
        };
        const query = `?app_id=${Number(
          app_id
        )}&category_id=${categoryID}&page=${currentPage}&${itemsPerPage}`;
        const { payload } = await dispatch(specificFrameStatusUpdate(_payload));
        if (payload.status === 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        } else if (payload.status === 200) {
          const { payload: _payload } = await dispatch(viewFrame(query));
          setLoading(false);
          if (_payload?.status === 200) {
            await SwalResponse("success", "Status Updated", payload?.message);
            setFrame(_payload?.data);
            setTotalRec(_payload?.count);
          }
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        await SwalResponse("danger", "error", "error");
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <>
      <PageTitle breadcrumbs={usersBreadcrumbs}>View Frames</PageTitle>
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header card-header align-items-center">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">View Frame Information</h3>
          </div>

          <button onClick={() => navigate(-1)} className="btn btn-bg">
            <i className="bi bi-arrow-left text-primary"></i> Back
          </button>
        </div>
        <div className="card-body p-9">
          <div className="table-responsive">
            <table className="table align-middle gs-0 gy-4 stickersCategoriesAlls">
              <thead>
                <tr className="fw-bold text-muted bg-light">
                  <th>
                    Sticker Images
                    {/* {active?.isActive1 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("image_url", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("image_url", "DESC")}
                      ></i>
                    )} */}
                  </th>
                  <th>
                    Category Name
                    {/* {active?.isActive3 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("metadata", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("metadata", "DESC")}
                      ></i>
                    )} */}
                  </th>
                  {/* <th>
                    Position
                    {active?.isActive4 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("position", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("position", "DESC")}
                      ></i>
                    )}
                  </th> */}
                  <th>Status</th>
                  <th className="w-100px text-end rounded-end pe-4 ">Action</th>
                </tr>
              </thead>
              {loading ? (
                <UsersListLoading />
              ) : (
                <>
                  {frame?.length > 0 ? (
                    frame &&
                    frame?.map((val: any, index: number) => (
                      <>
                        <tbody>
                          <tr>
                            <td>
                              {val?.image_url ? (
                                <img
                                  src={val?.image_url}
                                  alt=""
                                  className="w-50px"
                                />
                              ) : (
                                <img
                                  src={toAbsoluteUrl("media/sticker/04.png")}
                                  alt=""
                                  className="w-50px"
                                />
                              )}
                            </td>
                            <td className="ps-4 fw-semibold fs-7">
                              {val?.category?.title
                                ? capitalizeFirstLetter(val?.category?.title)
                                : "N/A"}
                            </td>

                            <td>
                              {val?.status == false ? (
                                <span className="badge badge-danger">
                                  Deactive
                                </span>
                              ) : (
                                val?.status === true && (
                                  <span className="badge badge-light-success">
                                    Active
                                  </span>
                                )
                              )}
                            </td>
                            <td className="pe-4 text-end">
                              {(auth_permission ||
                                get_permissions?.frame_write) && (
                                <>
                                  <Link
                                    to={{
                                      pathname: `/apps/addFrame`,
                                      search: `?id=${searchParams.get(
                                        "id"
                                      )}&name=${app_name}&catId=${encryptData(
                                        val?.category_id
                                      )}&frameId=${encryptData(val?.frame_id)}`,
                                    }}
                                    //to="/apps/HP/addFrame"
                                    // onContextMenu={(e) => e.preventDefault()}
                                    // state={{
                                    //   category_id: Number(val?.category_id),
                                    //   frame_id: Number(val?.frame_id),
                                    //   title: val.title,
                                    //   app_id: app_id,
                                    //   app_name: String(app_name),
                                    // }}
                                    className="btn edit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                  >
                                    <i className="ki-duotone ki-pencil fs-3">
                                      <span className="path1"></span>
                                      <span className="path2"></span>
                                    </i>
                                  </Link>
                                  <Tooltip
                                    anchorSelect=".edit"
                                    content="Edit"
                                  />
                                </>
                              )}

                              {(auth_permission ||
                                get_permissions?.frame_active_deactive) && (
                                <>
                                  <>
                                    <Link
                                      to="#"
                                      onContextMenu={(e) => e.preventDefault()}
                                      onClick={(e) =>
                                        handleSpecificFrameActiveDeactivate(
                                          e,
                                          val?.category_id,
                                          val?.frame_id,
                                          val?.status
                                        )
                                      }
                                      className={`${
                                        val?.status == true
                                          ? "deactivate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                          : "activate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                      }`}
                                    >
                                      <i
                                        className={`ki-duotone ki-switch fs-3 ${
                                          val?.status == false
                                            ? "text-danger"
                                            : "text-success"
                                        }`}
                                      >
                                        <span className="path1"></span>
                                        <span className="path2"></span>
                                      </i>
                                    </Link>

                                    <Tooltip
                                      anchorSelect={` ${
                                        val.status == true
                                          ? ".deactivate"
                                          : ".activate"
                                      } `}
                                      content={` ${
                                        val?.status == true
                                          ? "Activate"
                                          : "DeActivate"
                                      } `}
                                    />
                                  </>
                                </>
                              )}
                            </td>
                          </tr>
                        </tbody>
                      </>
                    ))
                  ) : (
                    <>
                      <tr>
                        <td colSpan={7}>
                          <div className="d-flex text-center w-100 align-content-center justify-content-center">
                            No matching records found
                          </div>
                        </td>
                      </tr>
                    </>
                  )}
                </>
              )}
            </table>
          </div>
          <div className="d-flex flex-stack flex-wrap pt-10">
            <div className="fs-6 text-gray-700">
              Showing {Number(currentPage) || 0} to {frame?.length || 0} of{" "}
              {totalRec || 0} entries
            </div>
            <ul className="pagination">
              {frame?.length > 0 && (
                <ReactPaginate
                  nextLabel="Next>"
                  onPageChange={(event) => handlePageClick(event)}
                  pageRangeDisplayed={3}
                  marginPagesDisplayed={2}
                  pageCount={pageCount}
                  previousLabel="< Previous"
                  pageClassName="page-item"
                  pageLinkClassName="page-link"
                  previousClassName="page-item"
                  previousLinkClassName="page-link"
                  nextClassName="page-item"
                  nextLinkClassName="page-link"
                  breakLabel="..."
                  breakClassName="page-item"
                  breakLinkClassName="page-link"
                  containerClassName="pagination"
                  activeClassName="active"
                  renderOnZeroPageCount={null}
                />
              )}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewFrame;
