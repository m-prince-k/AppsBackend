import * as Yup from "yup";

export const validationSchema = Yup.object({
  category: Yup.string().required("Please select the category"),
  availableApps: Yup.array().min(1, "Please select at least one app"),
});
