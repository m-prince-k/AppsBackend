import { FC, useEffect, useState } from "react";
import {
  Route,
  Routes,
  Outlet,
  Navigate,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { PageLink, PageTitle } from "../../../../../../_metronic/layout/core";
import { Link } from "react-router-dom";
import Select from "react-select";
import FileUpload from "./../FileUpload";
import MultiSelectDropdown from "./../MultiSelect";
import { UploadDragDrop } from "./../UploadDragDrop";
import { useFormik } from "formik";
import { validationSchema } from "./_validate";
import clsx from "clsx";
import { AppDispatch } from "../../../../../../store/store";
import { useDispatch } from "react-redux";
import {
  fetchAppsById,
  getAllBrandApps,
} from "../../../../../../store/Apps/appSlice";
import { getAllCategory } from "../../../../../../store/HP/Category/categorySlice";
import { decryptData, SwalResponse } from "../../../../../../_metronic/helpers";
import {
  editFrame,
  fetchFrameById,
  frameCreate,
} from "../../../../../../store/HP/Frame/frameSlice";
import { SUCCESS, VALIDATION } from "../../../../../../util/messages";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";

const usersBreadcrumbs: Array<PageLink> = [
  // {
  //   title: "Add Frame",
  //   path: "#",
  //   isSeparator: false,
  //   isActive: false,
  // },
  // {
  //   title: "",
  //   path: "",
  //   isSeparator: true,
  //   isActive: false,
  // },
];

interface appParams {
  frame_id: number;
  category_id: number;
}

const AddFrame = () => {
  const { search, state } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  let filterCatId =
    searchParams.get("catId") && decryptData(searchParams.get("catId"));
  let frameId =
    searchParams.get("catId") && decryptData(searchParams.get("frameId"));

  const app_id = filterId;
  const app_name = searchParams.get("name");
  const category_id = filterCatId;
  const frame_id = frameId;

  const navigate = useNavigate();
  //  const { frame_id, category_id } = (state as appParams) || {};

  const [selectedOptions, setSelectedOptions] = useState([]);
  const [appsOption, setAppsOption] = useState([]);
  const [files, setFiles] = useState([]);
  const [categoryOption, setCategoryOption] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitloading, setSubmitLoading] = useState(false);
  const [categoryLoading, setCategoryLoading] = useState(false);
  const [appLoading, setAppLoading] = useState(false);
  const dispatch = useDispatch<AppDispatch>();

  const [getCatId, setCatId] = useState(0);

  useEffect(() => {
    fetchCategory();
    if (Number(frame_id)) {
      fetchByIdFrame();
    }
  }, []);

  useEffect(() => {
    fetchApps();
  }, [getCatId]);

  async function fetchApps() {
    try {
      setAppLoading(true);
      let queryParams = `?category_id=${getCatId}`;
      const { payload } = await dispatch(fetchAppsById(queryParams));
      if (payload?.status === 200) {
        let filterApps =
          payload?.data &&
          payload?.data?.reduce((acc: any, obj: any) => {
            if (!acc?.some((o: any) => o?.name === obj?.name)) {
              acc?.push(obj);
            }
            return acc;
          }, []);

        const updatedOption = filterApps?.map((app: any) => ({
          value: app?.app_id,
          label: app?.name,
        }));

        setAppsOption([{ value: 0, label: "Select All" }, ...updatedOption]);

        setAppLoading(false);
      }
    } catch (err) {
      throw err;
    }
  }

  async function fetchCategory() {
    try {
      setCategoryLoading(true);
      const query = `?app_id=${Number(app_id)}`;
      const { payload } = await dispatch(getAllCategory(query));
      if (payload?.status === 200) {
        const updatedOption = payload?.data?.map((app: any) => ({
          value: app?.category_id,
          label: app?.title,
        }));
        setCategoryOption(updatedOption);
        setCategoryLoading(false);
      }
    } catch (err) {
      throw err;
    }
  }

  const fetchByIdFrame = async () => {
    if (frame_id) {
      setLoading(true);
      const query = `?app_id=${Number(
        app_id
      )}&category_id=${category_id}&frame_id=${frame_id}`;
      const { payload } = await dispatch(fetchFrameById(query));

      if (payload?.status === 200) {
        const frameData = payload?.data;
        formik.setValues({
          category: frameData?.category_id,
          availableApps: [frameData?.app_id],
          image_url: [frameData?.image_url],
        });

        setPreviews([frameData?.image_url]);
        setFiles([]);
        setLoading(false);
      }
    }
  };

  // const handleChange = (field: string, selected: any) => {
  //   if (field === "category") {
  //     setCatId(selected?.value);

  //     formik.setFieldValue(field, selected ? selected.value : "");
  //   } else if (field === "availableApps") {

  //     if (selected[0]?.label == "Select All") {
  //       let myArray = appsOption?.filter(function (obj) { return obj?.label !== "Select All" });
  //       setSelectedOptions(myArray);

  //       if(appsOption?.length < 0) {
  //         setAppsOption(appsOption?.filter(function (obj) { return obj?.label !== "Select All" }))
  //       }
  //     } else {
  //       setSelectedOptions(selected);
  //       formik.setFieldValue(
  //         field,
  //         selected?.map((option: any) => option?.value)
  //       );
  //     }
  //   }
  // };
  console.log(app_id);

  const handleChange = (field: string, selected: any) => {
    if (field === "category") {
      setCatId(selected?.value);
      formik.setFieldValue(field, selected ? selected.value : "");
    } else if (field === "availableApps") {
      if (selected.some((option) => option.label === "Select All")) {
        // If "Select All" is selected, mark all as selected
        setSelectedOptions(
          appsOption.filter((option) => option.label !== "Select All")
        );
        formik.setFieldValue(
          field,
          appsOption
            .filter((option) => option.label !== "Select All")
            .map((option) => option.value)
        );
      } else {
        // Update selected options based on user's selection
        setSelectedOptions(selected);
        formik.setFieldValue(
          field,
          selected.map((option: any) => option.value)
        );
      }
    }
  };

  const handleAppMarked = (e: any) => {
    if (e.target.checked == true) {
      setSelectedOptions(appsOption);
    } else {
      setSelectedOptions([]);
    }
  };

  const formik = useFormik({
    initialValues: {
      category: "",
      availableApps: [],
      image_url: [],
    },
    validationSchema: validationSchema,
    onSubmit: async (values, { setStatus, setSubmitting }) => {
      setSubmitLoading(true);
      try {
        if (Number(frame_id)) {
          if (files?.length === 0 && previews?.length === 0) {
            await SwalResponse(
              "warning",
              "WARNING",
              VALIDATION.NO_FILES_SELECT
            );
            setSubmitLoading(false);
            return; // Stop the submission
          }
          if (files?.length > 1) {
            await SwalResponse(
              "warning",
              "WARNING",
              VALIDATION.NO_FILES_SELECT_FOR_UPDATE
            );
            setSubmitLoading(false);
            return; // Prevent proceeding if more than one image is selected
          }
          const formData = new FormData();
          formData.append("category_id", values?.category);
          formData.append("app_id", JSON.stringify(Number(app_id)));
          formData.append("frame_id", JSON.stringify(Number(frame_id)));

          // If there are existing previews (for editing), include them as well
          if (previews?.length > 0) {
            if (files?.length === 0) {
              previews.forEach((preview, index) => {
                formData.append(`data[${index}][image_url]`, preview);
              });
            } else {
              formData.append(`data[0][image_url]`, files[0]);
              previews.slice(1).forEach((preview, index) => {
                formData.append(`data[${index + 1}][image_url]`, preview);
              });
            }
          } else {
            // If no existing previews, just append the new files (if any)
            files.forEach((file, index) => {
              formData.append(`data[${index}][image_url]`, file);
            });
          }

          const { payload } = await dispatch(editFrame(formData));
          if (payload?.status === 403) {
            await SwalResponse(
              "danger",
              payload?.message,
              payload?.error_details
            );
            // Reset form and state variables after handling error
            setSubmitLoading(false);
          } else if (payload?.status === 200) {
            await SwalResponse(
              "success",
              payload?.message,
              SUCCESS.UPDATE_FRAME
            );
            // Reset form and state variables after success
            navigate(`/apps/HP?id=${searchParams.get("id")}&name=${app_name}`, {
              state: { activeTab: "frames" },
            });
            // navigate("/apps/HP/HP", {
            //   state: {
            //     app_id: app_id,
            //     activeTab: "#kt_tab_pane_6",
            //     app_name: app_name,
            //   },
            // });
            setSubmitLoading(false);
          } else if (payload?.status === 401) {
            await SwalResponse(
              "success",
              payload?.message,
              payload?.error_details
            );
          } else if (payload?.status === 500) {
            await SwalResponse(
              "danger",
              payload?.message,
              payload?.error_details
            );
            formik?.values?.category;
            formik?.values?.image_url;
            setSubmitLoading(false);
          }
          setSubmitLoading(false);
        } else {
          if (files?.length === 0) {
            await SwalResponse(
              "warning",
              "WARNING",
              VALIDATION.NO_FILES_SELECTED
            );
            setSubmitLoading(false);
            return;
          } else {
            const formData = new FormData();
            formData.append("category_id", values?.category);
            formData.append("app_id", JSON.stringify(values?.availableApps));

            files &&
              files?.forEach((file, index) => {
                formData.append(`data[${index}][image_url]`, file);
              });

            // Dispatch the sticker create action
            const { payload } = await dispatch(frameCreate(formData));
            if (payload?.status === 403) {
              await SwalResponse(
                "danger",
                payload?.message,
                payload?.error_details
              );
              // Reset form and state variables after handling error
              formik.resetForm();
              setFiles([]);
              setPreviews([]);
              setSelectedOptions([]);
              setSubmitLoading(false);
            } else if (payload?.status === 200) {
              await SwalResponse(
                "success",
                payload?.message,
                SUCCESS?.ADD_FRAME
              );
              // Reset form and state variables after success
              formik.resetForm();
              setFiles([]);
              setPreviews([]);
              setSelectedOptions([]);
              navigate(
                `/apps/HP?id=${searchParams.get("id")}&name=${app_name}`,
                { state: { activeTab: "frames" } }
              );
              // navigate("/apps/HP/HP", {
              //   state: {
              //     app_id: app_id,
              //     activeTab: "#kt_tab_pane_6",
              //     app_name: app_name,
              //   },
              // });
              setSubmitLoading(false);
            } else if (payload?.status === 401) {
              await SwalResponse(
                "success",
                payload?.message,
                payload?.error_details
              );
            } else if (payload?.status === 500) {
              await SwalResponse(
                "danger",
                payload?.message,
                payload?.error_details
              );
              // Reset form and state variables after server error
              formik.resetForm();
              setFiles([]);
              setPreviews([]);
              setSelectedOptions([]);
              setSubmitLoading(false);
            }
            setSubmitLoading(false);
          }
        }
      } catch (error) {
        console.error(error);
      }
    },
  });

  return (
    <>
      <PageTitle breadcrumbs={usersBreadcrumbs}>Add Frame</PageTitle>
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">
              {frame_id ? "Edit" : "Add"} Frame Information
            </h3>
          </div>
          {/* <button
            onClick={() =>
              // navigate(
              //   `/apps/HP?id=${searchParams.get("id")}&name=${app_name}`,
              //   { state: { activeTab: "stickers" } }
              // )
              navigate(-1)
            }
            className="btn btn-bg"
          >
            <i className="bi bi-arrow-left text-primary"></i> Back
          </button> */}
        </div>
        {loading && frame_id && <UsersListLoading />}
        <form onSubmit={formik.handleSubmit}>
          <div className="card-body p-9">
            <div className="row">
              <div className="col-md-6">
                <div className="mb-10">
                  <label className="form-label required">Select Category</label>
                  <Select
                    name="category"
                    className={clsx(
                      "react-select-styled",
                      {
                        "is-invalid":
                          formik.touched.category && formik.errors.category,
                      },
                      {
                        "is-valid":
                          formik.touched.category && !formik.errors.category,
                      }
                    )}
                    classNamePrefix="react-select"
                    options={categoryOption}
                    placeholder="Select an option"
                    value={
                      formik.values?.category
                        ? categoryOption.find(
                            (option) => option.value === formik.values.category
                          )
                        : null // This will ensure that it shows as empty when no value is selected
                    }
                    onChange={(selected) => handleChange("category", selected)}
                    isLoading={categoryLoading}
                  />
                  {formik.touched.category && formik.errors.category && (
                    <div className="invalid-feedback">
                      {formik.errors.category}
                    </div>
                  )}
                  {/* <Select
                  className="react-select-styled"
                  classNamePrefix="react-select"
                  options={options}
                  placeholder="Select an option"
                /> */}
                </div>

                {!frame_id && (
                  <div className="mb-10 mutiselect-box">
                    <label className="form-label required">
                      Available in Apps{" "}
                    </label>
                    {/* <MultiSelectDropdown /> */}
                    <Select
                      isMulti
                      options={appsOption}
                      value={selectedOptions}
                      onChange={(selected) =>
                        handleChange("availableApps", selected)
                      }
                      placeholder={
                        !formik.values.category
                          ? "Please select a category first"
                          : "Select options..."
                      }
                      isLoading={appLoading}
                      isDisabled={!formik.values.category}
                    />
                    {formik.touched.availableApps &&
                      formik.errors.availableApps && (
                        <div className="invalid-feedback d-block">
                          {Array.isArray(formik.errors.availableApps)
                            ? formik.errors.availableApps.join(", ")
                            : formik.errors.availableApps}
                        </div>
                      )}
                  </div>
                )}
              </div>
              <div className="col-md-6">
                <UploadDragDrop
                  onFilesUpload={setFiles}
                  setPreviews={setPreviews}
                  previews={previews}
                />
              </div>
            </div>

            <div className="d-flex mt-10 gap-3 justify-content-end">
              <Link
                to={`/apps/HP?id=${searchParams.get("id")}&name=${app_name}`}
                state={{ activeTab: "frames" }}
                // onClick={() =>
                //   navigate(
                //     `/apps/HP?id=${searchParams.get("id")}&name=${app_name}`,
                //     { state: { activeTab: "frames" } }
                //   )
                // }
                className={`btn btn-bg-light btn-active-color-dark ${
                  submitloading ? "disabled" : ""
                }`}
                aria-disabled={submitloading}
              >
                Back
              </Link>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={submitloading}
              >
                {submitloading ? (
                  <span
                    className="indicator-progress"
                    style={{ display: "block" }}
                  >
                    Please wait...{" "}
                    <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                  </span>
                ) : (
                  <span className="indicator-label">
                    {frame_id ? "Update" : "Create"} Frame
                  </span>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default AddFrame;
