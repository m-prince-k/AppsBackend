import { FC, useEffect, useState } from "react";
import { Tooltip } from "react-tooltip";
import { Link, useLocation } from "react-router-dom";
import {
  capitalizeFirstLetter,
  decryptData,
  encryptData,
  initialQueryState,
  SwalResponse,
  useDebounce,
} from "../../../../../../_metronic/helpers";
import { Profile, useAuth } from "../../../../auth";
import { useDispatch, useSelector } from "react-redux";
import { initialDnDState } from "./_model";
import { AppDispatch } from "../../../../../../store/store";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import {
  listingFrame,
  ReArrageFrames,
} from "../../../../../../store/HP/Frame/frameSlice";
import ReactPaginate from "react-paginate";
import {
  listingSticker,
  stickerReOrders,
} from "../../../../../../store/HP/Sticker/stickerSlice";
import { SUCCESS } from "../../../../../../util/messages";
import ReOrderFrame from "./ReOrderFrames";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
import { handleKeyTextType } from "../Category/_model";

const Frames = (props: any) => {
  const {
    frames: frame,
    frameTotal,
    type,
    setCurrentPage,
    currentPage,
    itemsPerPage,
    searchTerm,
    setSearch,
  } = props || {};

  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));

  const app_id = filterId;

  console.log(
    filterId,
    "frame id is here*****************************************___________________--09876567"
  );

  const app_name = searchParams.get("name");

  const [modalOpen, setModalOpen] = useState(false);

  const [selectedCategoryId, setSelectedCategoryId] = useState<number>(0);
  const { currentUser, auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";

  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  const [pageCount, setPageCount] = useState(0);
  const [currentItems, setCurrentItems] = useState([]);
  const [itemOffset, setItemOffset] = useState(0);
  const [frames, setFrames] = useState<any>([]);
  const get_permissions = fetchAuthDetails?.data;
  // const [searchTerm, setSearch] = useState("");
  // const [currentPage, setCurrentPage] = useState(1);
  const [totalRec, setTotalRec] = useState(0);
  // const itemsPerPage = ITEM_PER_PAGE;
  const dispatch = useDispatch<AppDispatch>();
  const debouncedSearchTerm = useDebounce(searchTerm, 150);
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (debouncedSearchTerm !== undefined && searchTerm !== undefined) {
      setSearch(debouncedSearchTerm);
    }
  }, [debouncedSearchTerm]);

  useEffect(() => {
    if (type == "frames") {
      fetchFrames();
    }
  }, [
    searchTerm,
    currentPage,
    itemsPerPage,
    sortKey?.key,
    sortKey?.order,
    app_id,
    type,
  ]);

  async function fetchFrames() {
    try {
      setLoading(true);
      let queryParams = "";
      if (searchTerm) {
        queryParams = `?app_id=${Number(app_id)}&searchTerm=${searchTerm}`;
      } else if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          app_id
        )}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        queryParams = `?app_id=${Number(app_id)}&page=${Number(
          currentPage
        )}&items_per_page=${Number(itemsPerPage)}`;
      } else if (app_id) {
        queryParams = `?app_id=${Number(app_id)}}`;
      } else {
        queryParams = ``;
      }

      const { payload } = await dispatch(listingFrame(queryParams));
      if (payload?.status === 200) {
        setFrames(payload?.data ? payload?.data : frame);
        setTotalRec(payload?.count ? Number(payload?.count) : frameTotal);
      }
      setLoading(false);
    } catch (error) {
      throw error;
    }
  }

  let outputImages = frames?.reduce((acc: any, obj: any) => {
    if (!acc?.some((o: any) => o == obj)) {
      acc?.push(obj);
    }
    return acc;
  }, []);

  //pagination start here
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(frames?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, frames]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % frames?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));

      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "apps") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: false }));
    } else if (order == "DESC" && key == "apps") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: true }));
    } else if (order == "ASC" && key == "frames") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "frames") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    }
  };

  return (
    <>
      <div className="justify-content-end mb-10 d-flex ">
        <div className="d-flex align-items-center position-relative me-auto">
          <i className="ki-duotone ki-magnifier fs-1 position-absolute ms-6">
            <span className="path1"></span>
            <span className="path2"></span>
          </i>
          <input
            type="text"
            data-kt-user-table-filter="search"
            className="form-control w-350px ps-14"
            placeholder="Search Frames"
            value={searchTerm?.trim()}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={handleKeyTextType}
          />
        </div>
        {(auth_permission || get_permissions?.frame_create) && (
          <Link
            to={{
              pathname: `/apps/addFrame`,
              search: `?id=${searchParams.get("id")}&name=${app_name}`,
            }}
            //to="/apps/HP/addFrame"
            // state={{
            //   app_id: app_id,
            //   app_name: String(app_name),
            // }}
            className="btn  btn-light-primary d-flex align-items-center"
          >
            <span className="svg-icon svg-icon-1 bi bi-plus fs-1"></span>Add
            Frames
          </Link>
        )}
      </div>

      <div className="table-responsive">
        <table className="table align-middle gs-0 gy-4">
          <thead>
            <tr className="fw-bold text-muted bg-light">
              <th className="ps-4 w-50px rounded-start">
                <div className="d-flex align-items-center">S.No.</div>
              </th>
              <th>
                <div className="d-flex align-items-center">
                  Category Title
                  {active?.isActive1 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("title", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short  cursor-pointer"
                      onClick={() => onSortChange("title", "DESC")}
                    ></i>
                  )}
                </div>
              </th>

              {/* <th className="w-150px">
                <div className="d-flex align-items-center">
                  Apps
                  {active?.isActive2 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("apps", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short cursor-pointer"
                      onClick={() => onSortChange("apps", "DESC")}
                    ></i>
                  )}
                </div>
              </th> */}

              <th className="w-150px">
                {" "}
                <div className="d-flex align-items-center">
                  No. of Frames
                  {/* {active?.isActive3 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("frames", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short cursor-pointer"
                      onClick={() => onSortChange("frames", "DESC")}
                    ></i>
                  )} */}
                </div>
              </th>
              {(auth_permission ||
                get_permissions?.frame_re_order ||
                get_permissions?.frame_read ||
                get_permissions?.frame_active_deactive) && (
                <th className="w-200px text-end rounded-end pe-4">Actions</th>
              )}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <UsersListLoading />
            ) : (
              <>
                {frames?.length > 0 ? (
                  frames?.map((val: any, index: number) => (
                    <>
                      <tr>
                        <td className="ps-4 fw-semibold  fs-6">{index + 1}</td>
                        <td className=" fw-semibold  fs-6">
                          {capitalizeFirstLetter(val?.title) || "N/A"}
                        </td>

                        {/* <td className=" fw-semibold  fs-6">
                      <div className="d-flex gap-1 flex-wrap">
                        {val?.apps &&
                          val?.apps?.map((vall: any, index: number) => (
                            <>
                              <span className="badge badge-secondary">
                                {vall?.name || "Not Found"}
                              </span>{" "}
                            </>
                          ))}
                      </div>
                    </td> */}

                        <td className=" fw-semibold  fs-6">
                          <div className="d-flex gap-1 flex-wrap">
                            <Link
                              to={{
                                pathname: `/apps/ViewFrame`,
                                search: `?id=${searchParams.get(
                                  "id"
                                )}&name=${app_name}&catId=${encryptData(
                                  val?.category_id
                                )}`,
                              }}
                            >
                              <span className="badge badge-light-success">
                                {val?.frame_count}
                              </span>
                            </Link>
                            {/* {val?.frame_count} */}
                          </div>
                        </td>

                        <td className="pe-4 text-end">
                          {(auth_permission ||
                            get_permissions?.frame_re_order) && (
                            <>
                              <Link
                                to={{
                                  pathname: "/apps/HP",
                                  search: `?id=${searchParams.get(
                                    "id"
                                  )}&name=${app_name}`,
                                }}
                                // onContextMenu={(e) => e.preventDefault()}
                                onClick={() => {
                                  setSelectedCategoryId(
                                    Number(val?.category_id)
                                  );
                                  setModalOpen(true);
                                }}
                                state={{
                                  category_id: Number(val?.category_id),
                                  app_id: Number(app_id),
                                  app_name: String(app_name),
                                }}
                                className="btn rearrange btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-setting-4 fs-3"></i>
                              </Link>
                              <Tooltip
                                anchorSelect=".rearrange"
                                content="Reorder"
                              />
                            </>
                          )}

                          {(auth_permission || get_permissions?.frame_read) && (
                            <>
                              <Link
                                to={{
                                  pathname: `/apps/ViewFrame`,
                                  search: `?id=${searchParams.get(
                                    "id"
                                  )}&name=${app_name}&catId=${encryptData(
                                    val?.category_id
                                  )}`,
                                }}
                                // to="/apps/HP/ViewFrame"

                                // onContextMenu={(e) => e.preventDefault()}
                                // state={{
                                //   category_id: Number(val?.category_id),
                                // }}
                                className="btn view btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-eye fs-3">
                                  {" "}
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                  <span className="path3"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".view" content="View" />
                            </>
                          )}

                          {/* {(auth_permission || get_permissions?.category_write) && (
                        <>
                          <Link
                            to="/apps/HP/addStickers"
                            onContextMenu={(e) => e.preventDefault()}
                            state={{
                              category_id: Number(val?.category_id),
                              sticker_id: Number(val.sticker_id),
                              title: val.title,
                              app_id: app_id,
                            }}
                            className="btn edit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                          >
                            <i className="ki-duotone ki-pencil fs-3">
                              <span className="path1"></span>
                              <span className="path2"></span>
                            </i>
                          </Link>
                          <Tooltip anchorSelect=".edit" content="Edit" />
                        </>
                      )} */}

                          {/* {(auth_permission ||
                      get_permissions?.sticker_active_deactive) && (
                        <>
                          <>
                            <Link to="#" onClick={(e) => handleFrameMark(e, val?.category_id, val?.status)} className={`${val?.status == true ? "deactivate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" : "activate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"}`}>
                              <i className={`ki-duotone ki-switch fs-3 ${val?.status == false ? 'text-danger' : 'text-success'}`}>
                                <span className="path1"></span>
                                <span className="path2"></span>
                              </i>
                            </Link>

                            <Tooltip anchorSelect={` ${val.status == true ? ".deactivate" : ".activate"} `} content={` ${val?.status == true ? "Activate" : "DeActivate"} `} />
                          </>



                        </>
                      )} */}
                        </td>
                      </tr>
                    </>
                  ))
                ) : (
                  <>
                    <tr></tr>
                    <tr>
                      <td colSpan={7}>
                        <div className="d-flex text-center w-100 align-content-center justify-content-center">
                          No matching records found
                        </div>
                      </td>
                    </tr>
                  </>
                )}
              </>
            )}
          </tbody>
        </table>
      </div>
      <div className="d-flex flex-stack flex-wrap pt-10">
        <div className="fs-6 text-gray-700">
          Showing {Number(currentPage) || 0} to {frames?.length || 0} of{" "}
          {totalRec || 0} entries
        </div>
        {frames?.length > 0 && (
          <ReactPaginate
            nextLabel="Next>"
            onPageChange={(event) => handlePageClick(event)}
            pageRangeDisplayed={3}
            marginPagesDisplayed={2}
            pageCount={pageCount}
            forcePage={currentPage - 1}
            previousLabel="< Previous"
            pageClassName="page-item"
            pageLinkClassName="page-link"
            previousClassName="page-item"
            previousLinkClassName="page-link"
            nextClassName="page-item"
            nextLinkClassName="page-link"
            breakLabel="..."
            breakClassName="page-item"
            breakLinkClassName="page-link"
            containerClassName="pagination"
            activeClassName="active"
            renderOnZeroPageCount={null}
          />
        )}
      </div>
      {modalOpen && (
        <ReOrderFrame
          app_id={Number(app_id)} // Use your appropriate app_id
          category_id={selectedCategoryId} // Pass the selected category_id
          modalOpen={modalOpen}
          setModalOpen={setModalOpen}
        />
      )}
    </>
  );
};

export { Frames };
