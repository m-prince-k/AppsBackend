import { useState } from "react";
import { formatFileSize, SwalResponse } from "../../../../../_metronic/helpers";
import { MAX_FILES } from "../../../../../util/constant";

export const UploadDragDrop = ({ onFilesUpload, previews, setPreviews }) => {
  const [highlight, setHighlight] = useState(false);
  const [files, setFiles] = useState([]);

  const handleEnter = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setHighlight(true);
  };

  const handleOver = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setHighlight(true);
  };

  const handleLeave = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setHighlight(false);
  };

  const handleUpload = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setHighlight(false);

    const allowedFileTypes = ["image/png"];
    const fileInput = e.target;
    const selectedFiles = e?.target?.files || e.dataTransfer?.files;

    // Check if the total files count exceeds the maximum allowed
    if (selectedFiles.length + files.length > MAX_FILES) {
      SwalResponse(
        "warning",
        "Limit exceeded",
        `You can only upload up to ${MAX_FILES} images.`
      );
      fileInput.value = "";
      return;
    }

    if (selectedFiles) {
      const fileArray: File[] = Array.from(selectedFiles);

      // Filter out invalid files (those that are not PNG or larger than 1MB)
      const validFiles = fileArray.filter(
        (file) =>
          allowedFileTypes.includes(file?.type) &&
          (file.size / 1024 / 1024).toFixed(2) < "1.00"
      );

      // If there are invalid files, show a warning but proceed with valid files
      const invalidFiles = fileArray.filter(
        (file) => !allowedFileTypes.includes(file?.type)
      );
      const invalidSizes = fileArray.filter(
        (file) => (file.size / 1024 / 1024).toFixed(2) >= "1.00"
      );

      if (invalidFiles?.length > 0) {
        SwalResponse(
          "warning",
          "Invalid file type",
          "All Images should be in PNG format."
        );
      }

      if (invalidSizes?.length > 0) {
        SwalResponse(
          "warning",
          "Invalid file size",
          "All Images should not be greater than 1MB."
        );
      }

      // Only proceed with valid files
      if (validFiles.length > 0) {
        // Append valid files to the existing ones
        const updatedFiles = [...files, ...validFiles];
        setFiles(updatedFiles);
        onFilesUpload(updatedFiles);

        // Preview images logic
        const previewsArray: string[] = [];
        validFiles.forEach((file) => {
          const reader = new FileReader();
          reader.onload = () => {
            if (typeof reader.result === "string") {
              previewsArray?.push(reader.result);
              if (previewsArray?.length === validFiles?.length) {
                setPreviews((prevPreviews) => [
                  ...prevPreviews,
                  ...previewsArray,
                ]); // Append to existing previews
              }
            }
          };
          reader.readAsDataURL(file);
        });
      }
    }

    fileInput.value = ""; // Reset file input after processing
  };

  const handleRemovePreview = (index: number, e: any) => {
    e.stopPropagation();
    console.log("Removing image at index:", index);

    // Create new arrays excluding the image at 'index'
    const updatedFiles = [...files];
    const updatedPreviews = [...previews];

    // Remove the file and preview at the given index
    updatedFiles.splice(index, 1);
    updatedPreviews.splice(index, 1);

    // Set the updated state values
    setFiles(updatedFiles);
    setPreviews(updatedPreviews);

    // Notify the parent component with the updated files list
    onFilesUpload(updatedFiles);
  };

  return (
    <>
      {/* Display previews for all uploaded files */}
      {previews?.length > 0 && (
        <div className="preview-container">
          {previews?.map((preview: any, index: any) => (
            <>
              <img
                className="upload-button"
                src={preview}
                key={index}
                height={115}
                width={115}
                alt={`preview-${index}`}
              />
              <span className="remove-preview">
                <svg
                  onClick={(e) => {
                    handleRemovePreview(index, e);
                  }}
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="feather feather-x"
                >
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </span>
            </>
          ))}
        </div>
      )}

      <div
        onDragEnter={handleEnter}
        onDragLeave={handleLeave}
        onDragOver={handleOver}
        onDrop={handleUpload}
        className="text-center"
      >
        <div className="upload-draggable">
          {!previews?.length && (
            <div>
              <svg
                className="upload__img-close"
                stroke="currentColor"
                fill="currentColor"
                strokeWidth="0"
                version="1"
                viewBox="0 0 48 48"
                enableBackground="new 0 0 48 48"
                height="1em"
                width="1em"
                xmlns="http://www.w3.org/2000/svg"
              >
                <polygon
                  fill="#90CAF9"
                  points="40,45 8,45 8,3 30,3 40,13"
                ></polygon>
                <polygon fill="#E1F5FE" points="38.5,14 29,14 29,4.5"></polygon>
                <polygon fill="#1565C0" points="21,23 14,33 28,33"></polygon>
                <polygon fill="#1976D2" points="28,26.4 23,33 33,33"></polygon>
                <circle fill="#1976D2" cx="31.5" cy="24.5" r="1.5"></circle>
              </svg>
              <br />
              Drop your image here, or
              <br />
              <span className="text-muted">
                Please upload the file only .png
              </span>
              <br />
            </div>
          )}

          <div className="upload-button">
            <span className="text-blue-500 cursor-pointer">Browse</span>
            <input
              type="file"
              className="upload-file cursor-pointer"
              accept=".png,.PNG"
              multiple
              onChange={handleUpload}
            />
          </div>
        </div>
      </div>
    </>
  );
};
