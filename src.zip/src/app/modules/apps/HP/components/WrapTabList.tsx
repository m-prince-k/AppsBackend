import { FC, useEffect, useState } from "react";
import { Categories } from "./Category/Categories";
import { Frames } from "./Frame/Frames";
import { Stickers } from "./Sticker/Stickers";
import usePageTitle from "../../../auth/components/PageTitle/usePageTitle";
import { Link, useLocation, useParams } from "react-router-dom";
import { decryptData, SwalResponse } from "../../../../../_metronic/helpers";
import { AppDispatch } from "../../../../../store/store";
import { useDispatch } from "react-redux";
import { listingCategory } from "../../../../../store/HP/Category/categorySlice";
import { listingSticker } from "../../../../../store/HP/Sticker/stickerSlice";
import { listingFrame } from "../../../../../store/HP/Frame/frameSlice";
import { ITEM_PER_PAGE } from "../../../../../util/constant";

interface LocationState  {
  activeTab: string;
}

interface paramsMatched {
  id: number;
  name: string;
}

const WrapTabList = () => {
  const { search } = useLocation();
  const { state } = useLocation(); 
  const locationState = state as LocationState;
  const searchParams = new URLSearchParams(search);
  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  const app_id = filterId;
  const app_name = searchParams.get("name");
  const [activeTab1, setActiveTab1] = useState("category");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = ITEM_PER_PAGE;
  const [searchTerm, setSearch] = useState("");

  // Reset to "category" tab whenever app_id changes
  useEffect(() => {
    if (locationState?.activeTab) {
      setActiveTab1(locationState.activeTab);
    } else if (Number(app_id)) {
      setActiveTab1("category");
      setCurrentPage(1);
      setSearch(""); // Reset the current page when app_id changes
    }
  }, [locationState?.activeTab, app_id]);

  const handleTabClick = (type: string) => {
    setActiveTab1(type);
    setCurrentPage(1);
  };

  return (
    <>
      <ul className="nav nav-tabs nav-line-tabs mb-10 fs-6 nav-pills">
        <li className="nav-item">
          <Link
            className={`nav-link ${activeTab1 === "category" ? "active" : ""}`}
            state={{ app_id: Number(app_id), app_name: app_name }}
            data-bs-toggle="tab"
            to="#kt_tab_pane_4"
            onClick={(e) => {
              e.preventDefault();
              handleTabClick("category"); // Set active tab to category
            }}
          >
            Categories
          </Link>
        </li>
        <li className="nav-item">
          <Link
            className={`nav-link ${activeTab1 === "stickers" ? "active" : ""}`}
            state={{ app_id: Number(app_id), app_name: app_name }}
            to="#kt_tab_pane_5"
            data-bs-toggle="tab"
            onClick={(e) => {
              e.preventDefault();
              handleTabClick("stickers"); // Set active tab to stickers
            }}
          >
            Stickers
          </Link>
        </li>
        <li className="nav-item">
          <Link
            className={`nav-link ${activeTab1 === "frames" ? "active" : ""}`}
            state={{ app_id: Number(app_id), app_name: app_name }}
            data-bs-toggle="tab"
            to="#kt_tab_pane_6"
            onClick={(e) => {
              e.preventDefault();
              handleTabClick("frames"); // Set active tab to frames
            }}
          >
            Frames
          </Link>
        </li>
      </ul>
      <div className="tab-content" id="myTabContent">
        <div
          className={`tab-pane fade ${
            activeTab1 === "category" ? "show active" : ""
          }`}
          id="kt_tab_pane_4"
          role="tabpanel"
        >
          <Categories
            type={activeTab1}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            itemsPerPage={itemsPerPage}
            searchTerm={searchTerm}
            setSearch={setSearch}
          />
        </div>
        <div
          className={`tab-pane fade ${
            activeTab1 === "stickers" ? "show active" : ""
          }`}
          id="kt_tab_pane_5"
          role="tabpanel"
        >
          <Stickers
            type={activeTab1}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            itemsPerPage={itemsPerPage}
            searchTerm={searchTerm}
            setSearch={setSearch}
          />
        </div>
        <div
          className={`tab-pane fade ${
            activeTab1 === "frames" ? "show active" : ""
          }`}
          id="kt_tab_pane_6"
          role="tabpanel"
        >
          <Frames
            type={activeTab1}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            itemsPerPage={itemsPerPage}
            searchTerm={searchTerm}
            setSearch={setSearch}
          />
        </div>
      </div>
    </>
  );
};

export { WrapTabList };
