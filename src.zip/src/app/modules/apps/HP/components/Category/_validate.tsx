import { CategoryFormData, Errors } from "./_model"; // Import types

export const validateForm = (formData: CategoryFormData): Errors => {
  let isValid = true;

  const newErrors: Errors = {
    title: "",
    apps: "",
  };

  // Validate title
  if (!formData?.title?.trim()) {
    newErrors.title = "Title is required"; // If the title is empty
  } else if (formData?.title.trim().length < 3) {
    newErrors.title = "Title should be at least 3 characters long"; // If the title is less than 3 characters
  } else if (!/^[A-Za-z0-9 ]*$/.test(formData?.title.trim())) {
    newErrors.title =
      "Please enter an app name (only letters, numbers, and spaces allowed)"; // If the title contains invalid characters
  }

  // Validate apps selection
  if (!formData?.apps || formData?.apps.length === 0) {
    newErrors.apps = "Please select at least one app";
  }

  // Check if any field has an error
  isValid = Object.values(newErrors).every((error) => !error);

  return newErrors;
};
