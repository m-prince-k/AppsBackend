// Type for FormData
export interface CategoryFormData {
  category_id?: number;
  asset_id?: number;
  apps?: string[];
  title?: string;
  analytics?: string;
  status?: boolean;
  // hemispheres?: string[];
  // locales?: string[];
  // groups?: string[];
  // regions?: string[];
  // languages?: string[];
  // min_ios_app_versions?: string[];
  // max_ios_app_versions?: string[];
  // min_and_app_versions?: string[];
  // max_and_app_versions?: string[];
  // coordinates?: string[];
  // device_types?: string[];
}

// Type for Errors
export interface Errors {
  apps?: string;
  title?: string;
  hemispheres?: string;
  locales?: string;
  groups?: string;
  regions?: string;
  languages?: string;
  min_ios_app_versions?: string;
  max_ios_app_versions?: string;
  min_and_app_versions?: string;
  max_and_app_versions?: string;
  coordinates?: string;
  device_types?: string;
}

export const items = [
  { title: "All Holidays", image: "media/sticker/04.png" },
  { title: "Mother Day Catogory", image: "media/sticker/02.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/03.png" },
  {
    title: "Sprocket Select Exclusive Stickers",
    image: "media/sticker/04.png",
  },
  { title: "New Year Stickers 2024", image: "media/sticker/01.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/02.png" },
  {
    title: "Sprocket Select Exclusive Stickers",
    image: "media/sticker/03.png",
  },
  { title: "Valentine's New Day Start", image: "media/sticker/04.png" },
  { title: "All Days", image: "media/sticker/02.png" },
  { title: "New Year Stickers 2024", image: "media/sticker/03.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/04.png" },
  { title: "Welcome to Holidays", image: "media/sticker/01.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/04.png" },
  { title: "All Holidays", image: "media/sticker/02.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/03.png" },
  { title: "Mother Day Catogory", image: "media/sticker/04.png" },
  { title: "Mother Day Catogory", image: "media/sticker/01.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/03.png" },
  { title: "Mother Day Catogory", image: "media/sticker/02.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/04.png" },
  { title: "Valentine's Day Stickers 2024", image: "media/sticker/04.png" },
  {
    title: "Sprocket Select Exclusive Stickers",
    image: "media/sticker/01.png",
  },
];

export const categoryListing = [
  {
    position: 1,
    title: "Mothers Day Category",
    no_of_stickers: 10,
    no_of_frames: 15,
    status: true,
  },
  {
    position: 2,
    title: "New Years Stickers 2024",
    no_of_stickers: 10,
    no_of_frames: 15,
    status: false,
  },
  {
    position: 3,
    title: "Winter Stickers 2024",
    no_of_stickers: 10,
    no_of_frames: 15,
    status: false,
  },
];

export const initialDnDState = {
  draggedFrom: null,
  draggedTo: null,
  isDragging: false,
  originalOrder: [],
  updatedOrder: [],
};

export const initialDnDState1 = {
  draggedFrom1: null,
  draggedTo1: null,
  isDragging1: false,
  originalOrder1: [],
  updatedOrder1: [],
  draggedCategoryId1: null,
};

export interface CategoryElement {
  isError: string;
  isSuccess: boolean;
  fetchCategoryElements: any;
  viewCategoryByIDDetail: any;
  viewCategory: any;
  message: string;
  statusCode: number;
  isLoading: boolean;
}

export const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
  const target = event?.target as HTMLInputElement;
  if (event.key === " " && target.selectionStart === 0) {
    event.preventDefault();
  }
};