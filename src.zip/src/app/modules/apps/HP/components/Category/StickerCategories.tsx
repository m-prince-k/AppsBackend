import {
  Route,
  Routes,
  Outlet,
  Navigate,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { PageLink, PageTitle } from "../../../../../../_metronic/layout/core";
import {
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../_metronic/helpers";
import { Tooltip } from "react-tooltip";
import { Link } from "react-router-dom";
import FileUpload from "./../FileUpload";
import { Button, Dropdown, DropdownButton } from "react-bootstrap";
import usePageTitle from "../../../../auth/components/PageTitle/usePageTitle";
import { UploadDragDrop } from "./../UploadDragDrop";
import { Profile, useAuth } from "../../../../auth";
import { useDispatch, useSelector } from "react-redux";
import { CategoryFormData } from "./_model";
import { useEffect, useState } from "react";
import { AppDispatch } from "../../../../../../store/store";
import {
  activeAssetCategoryDeActive,
  activeAssetCategoryDelete,
  categoryAssetsCreate,
  listingAssetsCategory,
} from "../../../../../../store/HP/Category/categorySlice";
import { SUCCESS } from "../../../../../../util/messages";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import ReactPaginate from "react-paginate";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";

const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "Sticker Categories",
    path: "/apps/HP/HP/sticker-categories",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

interface appParams {
  app_id: number;
  category_id: number;
  app_name: string;
  title: string;
}

const StickerCategories = () => {
  usePageTitle("View Categories");
  const dispatch = useDispatch<AppDispatch>();
  const { currentUser, auth } = useAuth();
  const navigate = useNavigate();
  const { state } = useLocation();
  const { category_id, title, app_id, app_name } = (state as appParams) || {};

  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
    isActive5: true,
    isActive6: true,
    isActive7: true,
  });
  const [isUploading, setIsUploading] = useState(false);
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [loading, setLoading] = useState(false);

  const itemsPerPage = ITEM_PER_PAGE;
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentItems, setCurrentItems] = useState([]);
  const [assetsCategory, setAssetsCategory] = useState([]);
  const [totalRec, setTotalRec] = useState(0);
  const [isCollapseOpen, setIsCollapseOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [isAllSelected, setIsAllSelected] = useState(false);

  const categoryTitle =
    assetsCategory && assetsCategory.length > 0
      ? assetsCategory[0]?.category_id?.title
      : null;

  useEffect(() => {
    fetchAssetsCategory();
  }, [currentPage, itemsPerPage, sortKey?.key, sortKey?.order]);

  async function fetchAssetsCategory() {
    let queryParams = "";
    setLoading(true);
    try {
      if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          app_id
        )}&category_id=${category_id}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        //here concat the key for paginatgion is here
        queryParams = `?app_id=${Number(
          app_id
        )}&category_id=${category_id}&page=${Number(
          currentPage
        )}&items_per_page=${Number(itemsPerPage)}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(listingAssetsCategory(queryParams));
      setLoading(false);
      if (payload.status === 200) {
        setAssetsCategory(payload?.data);
        setTotalRec(payload?.count);
      } else if (payload.status === 403) {
        throw payload?.error_details;
      }
    } catch (error) {
      throw error;
    }
  }

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "image_url") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "image_url") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "image_url") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: false }));
    } else if (order == "DESC" && key == "image_url") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: true }));
    } else if (order == "ASC" && key == "metadata") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "metadata") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    } else if (order == "ASC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: false }));
    } else if (order == "DESC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: true }));
    }
    // else if (order == "ASC" && key == "regions") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "DESC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive5: false }));
    // } else if (order == "DESC" && key == "regions") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "ASC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive5: true }));
    // } else if (order == "ASC" && key == "language") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "DESC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive6: false }));
    // } else if (order == "DESC" && key == "language") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "ASC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive6: true }));
    // } else if (order == "ASC" && key == "device_type") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "DESC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive7: false }));
    // } else if (order == "DESC" && key == "device_type") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "ASC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive7: true }));
    // }
  };

  //PAGINATION START HERE FOR ASSET SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(assetsCategory?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, assetsCategory]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % assetsCategory?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };
  //END OF PAGINATION

  const handleFilesUpload = async (e: any) => {
    if (files?.length === 0) {
      await SwalResponse(
        "warning",
        "WARNING",
        "No files selected, Please select at least one file to upload"
      );
      console.error("No files selected");
      return;
    }
    const formData = new FormData();
    files.forEach((file, index) => {
      formData.append(
        `data[${index}][app_id]`,
        app_id ? app_id?.toString() : "2"
      );
      formData.append(`data[${index}][asset_img]`, file); // Append the file
      formData.append(
        `data[${index}][category_id]`,
        category_id?.toString() || ""
      ); // Append the category_id
    });

    try {
      setIsUploading(true);
      const { payload } = await dispatch(categoryAssetsCreate(formData));
      if (payload?.status === 403) {
        await SwalResponse("danger", payload?.message, payload?.error_details);
        setFiles([]);
        setPreviews([]);
        navigate("/apps/HP/stickerCategories", {
          state: {
            category_id: category_id,
            title: title,
          },
        });
      } else if (payload?.status === 200) {
        await fetchAssetsCategory();
        await SwalResponse(
          "success",
          payload?.message,
          SUCCESS.ADDASSETSCATEGORY
        );
        setFiles([]);
        setPreviews([]);
        setIsCollapseOpen(false);
      } else if (payload?.status === 500) {
        await SwalResponse("danger", payload?.message, payload?.error_details);
        setFiles([]);
        setPreviews([]);
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      }

      setIsUploading(false);
      setFiles([]);
    } catch (error) {
      console.error("An error occurred while uploading:", error);
    }
  };

  const categoryID =
    assetsCategory && assetsCategory.length > 0
      ? assetsCategory[0]?.category_id?.category_id
      : null;

  //ACTIVE DE-ACTIVE CATEGORY BASED ON ASSET ID
  const handleActiveDeactive = async (assetId: number[], status: boolean) => {
    try {
      let statusSet = false;
      if (status === true) {
        statusSet = false;
      } else {
        statusSet = true;
      }

      const query = `?app_id=${Number(
        app_id
      )}&category_id=${categoryID}&page=1&items_per_page=10`;
      if (assetId) {
        let _payload: object = {
          app_id: app_id,
          asset_id: [assetId],
          status: statusSet,
        };

        const { payload } = await dispatch(
          activeAssetCategoryDeActive(_payload)
        );
        if (payload.status === 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        } else if (payload.status === 200) {
          const response = await dispatch(listingAssetsCategory(query));
          if (response.payload.status === 200) {
            setAssetsCategory(response.payload?.data);
            setTotalRec(response.payload?.count);
          }
          await SwalResponse("success", "Status Updated", payload?.message);
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        await SwalResponse("danger", "error", "error");
      }
    } catch (error) {
      throw error;
    }
  };

  const handleSelectAllChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedItems(assetsCategory.map((item: any) => item.asset_id)); // Select all
      setIsAllSelected(true);
    } else {
      setSelectedItems([]); // Deselect all
      setIsAllSelected(false);
    }
  };

  // Handle individual checkbox selection
  const handleCheckboxChange = (assetId: number) => {
    const updatedSelection = [...selectedItems];
    if (updatedSelection.includes(assetId)) {
      updatedSelection.splice(updatedSelection.indexOf(assetId), 1); // Deselect
    } else {
      updatedSelection.push(assetId); // Select
    }
    setSelectedItems(updatedSelection);
    setIsAllSelected(updatedSelection.length === assetsCategory.length); // Check if all items are selected
  };

  // Handle BULK ACTIVE DE-ACTIVE CATEGORY BASED ON ASSET ID
  const handleBulkAction = async (action: string) => {
    try {
      if (!selectedItems.length) {
        await SwalResponse(
          "warning",
          "No items selected",
          "Please select at least one item."
        );
        return;
      }
      setLoading(true);
      let payload: object;

      if (action === "Deactivate") {
        const statuses = assetsCategory
          .filter((item) => selectedItems.includes(item.asset_id))
          .map((item) => item.status);
        const statusSet = statuses.every((status) => status === statuses[0])
          ? !statuses[0]
          : false;
        payload = {
          app_id: app_id,
          asset_id: selectedItems,
          status: statusSet,
        };
      } else if (action === "Delete") {
        payload = { app_id: app_id, asset_id: selectedItems };
      }

      const { payload: response } = await dispatch(
        action === "Deactivate"
          ? activeAssetCategoryDeActive(payload)
          : activeAssetCategoryDelete(payload)
      );

      if (response.status === 403) {
        await SwalResponse("danger", "warning", response?.error_details);
      } else if (response.status === 200) {
        fetchAssetsCategory();
        await SwalResponse("success", "Status Updated", response?.message);
      }
      setLoading(false);
      setIsAllSelected(false);
      setSelectedItems([]);
    } catch (err) {
      console.error("Error in handleBulkAction:", err);
      await SwalResponse(
        "danger",
        "Error",
        "There was an issue with the bulk action."
      );
    }
  };

  return (
    <>
      <PageTitle breadcrumbs={usersBreadcrumbs}>Sticker Categories</PageTitle>

      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header align-items-center">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">
              {title ? title : categoryTitle ? categoryTitle : "N/A"}
            </h3>
          </div>
          {(auth_permission || get_permissions?.category_create) && (
            <button
              className="btn btn-light-primary ms-auto"
              type="button"
              onClick={() => setIsCollapseOpen(!isCollapseOpen)}
            >
              <i className="bi bi-plus-lg"></i> Add New Assets
            </button>
          )}
        </div>
        <div className="card-body p-9">
          <div
            id="kt_accordion_1_body_1"
            className={`accordion-collapse collapse ${
              isCollapseOpen ? "show" : ""
            }`}
            aria-labelledby="kt_accordion_1_header_1"
            data-bs-parent="#kt_accordion_1"
          >
            <div className="row mb-10">
              <div className="col-md-12 mb-5">
                {/* <FileUpload /> */}
                <UploadDragDrop
                  onFilesUpload={setFiles}
                  setPreviews={setPreviews}
                  previews={previews}
                />
              </div>
              <div className="col-md-12 text-end  d-flex gap-5 justify-content-end">
                <button
                  className="btn btn-light-danger"
                  onClick={() => {
                    setFiles([]);
                    setPreviews([]);
                    setIsCollapseOpen(false);
                  }}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-light-primary"
                  onClick={handleFilesUpload}
                  disabled={isUploading}
                >
                  {isUploading ? (
                    <span
                      className="indicator-progress"
                      style={{ display: "block" }}
                    >
                      Uploading...{" "}
                      <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                  ) : (
                    <>
                      <i className="bi bi-cloud-upload"></i> Upload Active
                      Assets
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
          {/* drop down appears from where he can select the bulk status change action - it can be Deactivate, Delete etc. */}
          <div className="mb-5 text-end">
            {selectedItems?.length > 0 && (
              // <Button>Edit assets Images</Button>
              <DropdownButton
                id="custom-dropdown"
                title="Change Status"
                variant="light-danger"
                className="custom-dropdown-button"
              >
                <Dropdown.Item
                  onClick={() => handleBulkAction("Deactivate")}
                  disabled={loading}
                >
                  {loading ? "Deactivating..." : "Deactivate"}
                </Dropdown.Item>
                <Dropdown.Item
                  onClick={() => handleBulkAction("Delete")}
                  disabled={loading}
                >
                  {loading ? "Deleting..." : "Delete"}
                </Dropdown.Item>
              </DropdownButton>
            )}
          </div>
          <div className="table-responsive">
            <table className="table align-middle gs-0 gy-4 stickersCategoriesAlls">
              <thead>
                <tr className="fw-bold text-muted bg-light ">
                  <th className="ps-4 w-50px rounded-start">
                    <div className="form-check form-check-custom  form-check-sm">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="selectAll"
                        checked={isAllSelected}
                        onChange={handleSelectAllChange}
                      />
                    </div>
                  </th>
                  <th>
                    Asset
                    {active?.isActive1 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("image_url", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("image_url", "DESC")}
                      ></i>
                    )}
                  </th>
                  <th className="w-150px">File Name</th>
                  <th>
                    Metadata
                    {active?.isActive3 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("metadata", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("metadata", "DESC")}
                      ></i>
                    )}
                  </th>
                  <th>
                    Position
                    {active?.isActive4 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("position", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("position", "DESC")}
                      ></i>
                    )}
                  </th>
                  <th>Status</th>
                  <th className="w-100px text-end rounded-end pe-4 ">Action</th>
                </tr>
              </thead>
              {loading ? (
                <UsersListLoading />
              ) : (
                <>
                  {assetsCategory?.length > 0 ? (
                    assetsCategory?.map((val: any, index: number) => (
                      <>
                        <tbody>
                          <tr>
                            <td className="ps-4 fw-semibold  fs-7">
                              <div className="form-check form-check-custom  form-check-sm">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  checked={selectedItems.includes(val.asset_id)}
                                  onChange={() =>
                                    handleCheckboxChange(val.asset_id)
                                  }
                                />
                              </div>
                            </td>
                            <td>
                              {val?.image_url ? (
                                <img
                                  src={val?.image_url}
                                  alt=""
                                  className="w-50px"
                                />
                              ) : (
                                <img
                                  src={toAbsoluteUrl("media/sticker/04.png")}
                                  alt=""
                                  className="w-50px"
                                />
                              )}
                            </td>
                            <td className="ps-4 fw-semibold  fs-7">
                              {val?.image_url?.split("/").pop() || "N/A"}
                            </td>
                            <td className="ps-4 fw-semibold  fs-7">
                              {val?.metadata || "N/A"}
                            </td>
                            <td className="ps-4 fw-semibold  fs-7">
                              {val?.position}
                            </td>
                            <td>
                              {val?.status == false ? (
                                <span className="badge badge-danger">
                                  Deactive
                                </span>
                              ) : (
                                val?.status === true && (
                                  <span className="badge badge-light-success">
                                    Active
                                  </span>
                                )
                              )}
                            </td>
                            <td className="pe-4 text-end">
                              {(auth_permission ||
                                get_permissions?.category_read) && (
                                <>
                                  <Link
                                    to="/apps/HP/singleSticker"
                                    onContextMenu={(e) => e.preventDefault()}
                                    state={{
                                      category_id: category_id,
                                      asset_id: Number(val?.asset_id),
                                      title: val?.category_id?.title,
                                      app_id: Number(app_id),
                                      app_name: String(app_name),
                                    }}
                                    className="btn view btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                  >
                                    <i className="ki-duotone ki-eye fs-3">
                                      {" "}
                                      <span className="path1"></span>
                                      <span className="path2"></span>
                                      <span className="path3"></span>
                                    </i>
                                  </Link>
                                  <Tooltip
                                    anchorSelect=".view"
                                    content="View"
                                  />
                                </>
                              )}
                              {(auth_permission ||
                                get_permissions?.category_active_deactive) && (
                                <>
                                  <Link
                                    to="#"
                                    onContextMenu={(e) => e.preventDefault()}
                                    onClick={() =>
                                      handleActiveDeactive(
                                        val?.asset_id,
                                        val?.status
                                      )
                                    }
                                    className="deactivate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                  >
                                    <i
                                      className={`ki-duotone ki-switch fs-3 ${
                                        val.status === true
                                          ? "text-success"
                                          : val.status === false &&
                                            "text-danger"
                                      }`}
                                    >
                                      <span className="path1"></span>
                                      <span className="path2"></span>
                                    </i>
                                  </Link>
                                  <Tooltip
                                    anchorSelect=".deactivate"
                                    content={`${
                                      val.status == false
                                        ? "Deactive"
                                        : val.status === true && "Active"
                                    }`}
                                  />
                                </>
                              )}
                            </td>
                          </tr>
                        </tbody>
                      </>
                    ))
                  ) : (
                    <>
                      <tr>
                        <td colSpan={7}>
                          <div className="d-flex text-center w-100 align-content-center justify-content-center">
                            No matching records found
                          </div>
                        </td>
                      </tr>
                    </>
                  )}
                </>
              )}
            </table>
          </div>
          <div className="d-flex flex-stack flex-wrap pt-10">
            <div className="fs-6 text-gray-700">
              Showing {Number(currentPage) || 0} to{" "}
              {assetsCategory?.length || 0} of {totalRec || 0} entries
            </div>
            <ul className="pagination">
              {assetsCategory?.length > 0 && (
                <ReactPaginate
                  nextLabel="Next>"
                  onPageChange={(event) => handlePageClick(event)}
                  pageRangeDisplayed={3}
                  marginPagesDisplayed={2}
                  pageCount={pageCount}
                  previousLabel="< Previous"
                  pageClassName="page-item"
                  pageLinkClassName="page-link"
                  previousClassName="page-item"
                  previousLinkClassName="page-link"
                  nextClassName="page-item"
                  nextLinkClassName="page-link"
                  breakLabel="..."
                  breakClassName="page-item"
                  breakLinkClassName="page-link"
                  containerClassName="pagination"
                  activeClassName="active"
                  renderOnZeroPageCount={null}
                />
              )}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};
export default StickerCategories;
