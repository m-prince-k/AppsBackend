import { useEffect, useState } from "react";
import usePageTitle from "../../../../auth/components/PageTitle/usePageTitle";
import { validateForm } from "./_validate";
import { CategoryElement, CategoryFormData, Errors } from "./_model";
import { AppDispatch } from "../../../../../../store/store";
import { useDispatch, useSelector } from "react-redux";
import {
  categoryCreate,
  categoryUpdate,
  fetchElementsByCategory,
  viewCategoryByID,
  viewMasterCategoryByID,
} from "../../../../../../store/HP/Category/categorySlice";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  decryptData,
  SwalResponse,
  uniqueValue,
} from "../../../../../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../../../../../util/messages";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";

interface appParams {
  app_id: number;
  category_id: number;
  app_name: string;
  title: string;
}

const CreateCategory = () => {
  usePageTitle("Create Category");
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const { search, state } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId =
    searchParams.get("catId") && decryptData(searchParams.get("catId"));
  const category_id = filterId;

  const { title, app_id, app_name } = (state as appParams) || {};

  useEffect(() => {
    dispatch(fetchElementsByCategory());
  }, []);

  const { isLoading, isSuccess, fetchCategoryElements, message, statusCode } =
    useSelector((state: { categories: CategoryElement }) => state?.categories);

  const Apps = fetchCategoryElements?.data?.app_list;

  const uniqueApps = Apps?.reduce((acc: any, obj: any) => {
    if (!acc?.some((o: any) => o?.name === obj?.name)) {
      acc?.push(obj);
    }
    return acc;
  }, []);

  const [formData, setFormData] = useState<CategoryFormData>({
    apps: [],
    title: "",
    status: false,
  });

  const [errors, setErrors] = useState<Errors>({
    apps: "",
    title: "",
  });

  useEffect(() => {
    fetchCategory();
  }, [category_id]);

  const fetchCategory = async () => {
    try {
      setLoading(true);
      if (category_id) {
        const query = `?category_id=${category_id}`;
        const { payload } = await dispatch(viewMasterCategoryByID(query));

        if (payload?.status === 200) {
          setFormData({
            apps: payload?.data?.appsData?.map((app: any) => app.app_id) || [],
            title: payload?.data?.title || "",
            status: payload?.data?.status,
          });
        } else if (payload?.status === 403) {
          await SwalResponse(
            "danger",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        } else {
          await SwalResponse(
            "danger",
            payload?.message,
            payload?.error_details
          );
        }
        setLoading(false);
      }
    } catch (err) {
      throw err;
    }
  };

  const handleChange = (e: any) => {
    const { name, checked, value } = e.target;
    if (name === "appsSelectAll") {
      const updatedKey = checked ? Apps?.map((val: any) => val?.app_id) : [];
      setFormData({
        ...formData,
        apps: updatedKey,
      });
      if (checked) {
        setErrors((prevErrors) => ({ ...prevErrors, apps: "" }));
      }
    } else if (name === "apps") {
      let updatedKey: string | any[];
      if (checked) {
        updatedKey = [...formData?.apps, parseInt(value)];
      } else {
        updatedKey = formData?.apps?.filter(
          (val: any) => val !== parseInt(value)
        );
      }
      setFormData({
        ...formData,
        apps: updatedKey,
      });
      if (updatedKey?.length > 0) {
        setErrors((prevErrors) => ({ ...prevErrors, apps: "" }));
      }
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });

      setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
    }
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    const formErrors = validateForm(formData);
    setErrors(formErrors);
    const isValid = Object.values(formErrors).every((error) => !error);

    if (isValid) {
      setSubmitLoading(true);
      const CreatePayload: any = {
        app_id: formData?.apps,
        title: formData?.title?.trim(),
        status: true,
      };
      const editedpayload = {
        ...CreatePayload,
        category_id: category_id,
      };
      const updatedPayload = category_id ? editedpayload : CreatePayload;

      if (category_id) {
        const { payload } = await dispatch(categoryUpdate(editedpayload));
        if (payload?.status === 403) {
          await SwalResponse(
            "danger",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status === 200) {
          await SwalResponse(
            "success",
            payload?.message,
            SUCCESS.UPDATECATEGORY
          );
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status === 503) {
          await SwalResponse(
            "danger",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        const { payload } = await dispatch(categoryCreate(CreatePayload));
        if (payload?.status === 403) {
          await SwalResponse(
            "danger",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status === 200) {
          await SwalResponse("success", payload?.message, SUCCESS.ADDCATEGORY);
          // navigate("/apps/categories");
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status === 503) {
          await SwalResponse(
            "danger",
            payload?.message,
            payload?.error_details
          );
        }
      }

      setSubmitLoading(false);
      navigate("/apps/categories", {
        state: {
          app_id: Number(app_id),
          app_name: String(app_name),
        },
      });
      setFormData({
        apps: [],
        title: "",
        status: false,
      });
    }
  };

  // const handleKeyNumberType = (event: any) => {
  //   const allowedKeys = [
  //     "Backspace",
  //     "Delete",
  //     "ArrowLeft",
  //     "ArrowRight",
  //     "Tab",
  //   ];
  //   const isAllowedKey =
  //     allowedKeys.includes(event.code) ||
  //     (!isNaN(Number(event.key)) && event.code !== "Space") ||
  //     (event.ctrlKey && event.key === "a");

  //   if (!isAllowedKey) {
  //     event.preventDefault();
  //   }
  // };

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  return (
    <>
      <div className="card">
        <div className="card-header align-items-center">
          <div className="card-title">
            <h3>{category_id ? "Update Category" : "Create Category"}</h3>
          </div>
          <Link
            to="#"
            onContextMenu={(e) => e.preventDefault()}
            onClick={() => navigate(-1)}
            className="d-flex align-items-center gap-2 text-primary"
          >
            <i className="bi bi-arrow-left text-primary"></i> Back
          </Link>
        </div>
        <div className="card-body">
          {loading && category_id && <UsersListLoading />}
          <form onSubmit={handleSubmit}>
            <div className="row align-items-start mb-10">
              <div className="col-md-3">
                <div className="mb-7">
                  <label className="form-label">Title</label>
                  <input
                    type="text"
                    className={`form-control ${
                      errors?.title ? "is-invalid" : ""
                    }`}
                    placeholder="Enter the title"
                    name="title"
                    value={formData?.title}
                    onChange={handleChange}
                    maxLength={40}
                    onKeyDown={handleKeyTextType}
                  />
                  {errors?.title && (
                    <div className="invalid-feedback">{errors?.title}</div>
                  )}
                </div>
              </div>
            </div>
            <div className="d-flex gap-5 mb-5">
              <div className="card-title mb-0">
                <h5 className="mb-0">Apps</h5>
              </div>
              <span className="separator"></span>
              <div className="form-check form-check-custom form-check-sm">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="appsSelectAll"
                  checked={formData?.apps?.length === Apps?.length}
                  onChange={handleChange}
                  name="appsSelectAll"
                />
                <label className="form-check-label">Select All</label>
              </div>
            </div>
            <div className="separator separator-dashed mb-7"></div>
            <div className="row locales-list mb-10">
              {uniqueApps &&
                uniqueApps?.map((val: any, index: number) => (
                  <div className="col-auto" key={index}>
                    <div className="form-check form-check-custom form-check-sm">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value={val?.app_id}
                        id={`app-${index}`}
                        checked={formData?.apps?.includes(val?.app_id)}
                        onChange={handleChange}
                        name="apps"
                      />
                      <label className="form-check-label">{val?.name}</label>
                    </div>
                  </div>
                ))}
              {errors?.apps && (
                <div className="invalid-feedback d-block">{errors?.apps}</div>
              )}
            </div>

            <div className="separator separator-solid mt-5"></div>
            <div className="d-flex mt-10 gap-3 justify-content-end">
              <Link
                to="/apps/categories"
                onContextMenu={(e) => e.preventDefault()}
                state={{
                  app_id: Number(app_id),
                  app_name: String(app_name),
                }}
                className={`btn btn-bg-light btn-active-color-dark ${
                  submitLoading ? "disabled" : ""
                }`}
                // className="btn btn-bg-light btn-active-color-dark"
              >
                Back
              </Link>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={submitLoading}
              >
                {submitLoading ? (
                  <span
                    className="indicator-progress"
                    style={{ display: "block" }}
                  >
                    Please wait...{" "}
                    <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                  </span>
                ) : (
                  <span className="indicator-label">
                    {category_id ? "Update Category" : "Create Category"}
                  </span>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default CreateCategory;
