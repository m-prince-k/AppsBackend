import {
  Route,
  Routes,
  Outlet,
  Navigate,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { PageLink, PageTitle } from "../../../../../../_metronic/layout/core";
import { Link } from "react-router-dom";
import { Tooltip } from "react-tooltip";
import {
  capitalizeFirstLetter,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../_metronic/helpers";
import { Profile, useAuth } from "../../../../auth";
import { useDispatch, useSelector } from "react-redux";
import { CategoryFormData } from "./_model";
import { useEffect, useState } from "react";
import { AppDispatch } from "../../../../../../store/store";
import {
  activeAssetCategoryDeActive,
  viewAssetsCategoryByID,
} from "../../../../../../store/HP/Category/categorySlice";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "Single Sticker",
    path: "/apps/HP/HP/single-sticker",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

interface appParams {
  app_id: number;
  category_id: number;
  asset_id: number;
  app_name: string;
  title: string;
}

const SingleSticker = () => {
  const { currentUser, auth } = useAuth();
  const { state } = useLocation();
  const { category_id, asset_id, title, app_id, app_name } =
    (state as appParams) || {};
  const navigate = useNavigate();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;
  const [viewData, setViewData] = useState<any>(null);
  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      if (Number(asset_id)) {
        const query = `?app_id=${Number(app_id)}&asset_id=${asset_id}`;
        setLoading(true);
        const { payload } = await dispatch(viewAssetsCategoryByID(query));
        setViewData(payload?.data);
        setLoading(false);
      } else {
        SwalResponse("warning", "Warning", "Assets ID Required");
        navigate("/apps/HP/HP", {
          state: {
            app_id: Number(app_id),
            app_name: String(app_name),
          },
        });
      }
    } catch (err) {
      throw err;
    }
  };

  const handleActiveDeactive = async (assetId: number[], status: boolean) => {
    try {
      let statusSet = false;
      if (status === true) {
        statusSet = false;
      } else {
        statusSet = true;
      }
      if (assetId) {
        let _payload = {
          app_id: app_id,
          asset_id: [assetId],
          status: statusSet,
        };

        const { payload } = await dispatch(
          activeAssetCategoryDeActive(_payload)
        );
        if (payload.status === 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        } else if (payload.status === 200) {
          fetchData();
          await SwalResponse("success", "Status Updated", payload?.message);
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        await SwalResponse("danger", "error", "error");
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <>
      <PageTitle breadcrumbs={usersBreadcrumbs}>Single Sticker</PageTitle>

      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        {loading ? (
          <UsersListLoading />
        ) : (
          <>
            <div className="card-header align-items-center">
              <div className="card-title m-0">
                <h3 className="fw-bolder m-0">Assets Information</h3>
              </div>
              <Link
                to="#"
                onContextMenu={(e) => e.preventDefault()}
                onClick={() => navigate(-1)}
                className="d-flex align-items-center gap-2 text-primary"
              >
                <i className="bi bi-arrow-left text-primary"></i> Back
              </Link>
            </div>
            <div className="card-body p-9">
              <div className="edit-category-icon mb-10">
                <div className="symbol symbol-100px ">
                  {viewData?.image_url ? (
                    <img src={viewData?.image_url} alt="" />
                  ) : (
                    <img src={toAbsoluteUrl("media/sticker/04.png")} alt="" />
                  )}
                </div>
              </div>
              {/* <div className="row mb-7">
            <label className="col-lg-3 fw-bold text-muted">Sticker Asset</label>
            <div className="col-lg-9">
              <span className="fw-bold fs-6">
                cloud_Best_Mom_Ever_Bouquet_Mothers_Day_700
              </span>
            </div>
          </div> */}
              <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">
                  Category Title
                </label>
                <div className="col-lg-9">
                  <span className="fw-bold fs-6">
                    {" "}
                    {capitalizeFirstLetter(viewData?.category_id?.title)}
                  </span>
                </div>
              </div>

              <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">Status</label>
                <div className="col-lg-9">
                  {viewData?.status == false ? (
                    <span className="badge badge-danger">Deactive</span>
                  ) : (
                    viewData?.status === true && (
                      <span className="badge badge-light-success">Active</span>
                    )
                  )}
                </div>
              </div>
              <div className="row mb-7">
                {/* <label className="col-lg-3 fw-bold text-muted">Position</label>
                <div className="col-lg-9">
                  <span className="fw-bold fs-6">{viewData?.position}</span>
                </div> */}
              </div>
              <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">
                  Active Version Num
                </label>
                <div className="col-lg-9">
                  <span className="fw-bold fs-6">{viewData?.version}</span>
                </div>
              </div>
              {/* <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">
                  Sticker Category Analytics id
                </label>
                <div className="col-lg-9">
                  <span className="fw-bold fs-6"></span>
                </div>
              </div> */}
              <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">Metadata</label>
                <div className="col-lg-9">
                  <span className="fw-bold fs-6">{viewData?.metadata}</span>
                </div>
              </div>
              <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">
                  Image Links
                </label>
                <div className="col-lg-9">
                  <ul className="d-flex sticker-links gap-5">
                    <li>
                      <a
                        href={viewData?.image_url}
                        className="fw-bold fs-6"
                        target="_blank"
                        // rel="noopener noreferrer"
                      >
                        {viewData?.image_url?.split("/").pop()}
                      </a>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="mt-5">
                {(auth_permission || get_permissions?.category_write) && (
                  <Link
                    onContextMenu={(e) => e.preventDefault()}
                    to="/apps/create-sticker-category/categories"
                    state={{
                      category_id: category_id,
                      title: title,
                      app_id: app_id,
                      app_name: String(app_name),
                    }}
                  >
                    <button className="btn  btn-light-primary d-flex align-items-center ms-auto">
                      Edit Category
                    </button>
                  </Link>
                )}
              </div>
              <div className="mt-10">
                <h3 className="mb-5">Version History</h3>

                <div className="table-responsive">
                  <table className="table align-middle gs-0 gy-4">
                    <thead>
                      <tr className="fw-bold text-muted bg-light">
                        <th className="ps-4 rounded-start">Asset Image</th>
                        <th>Version Number</th>
                        <th>Matadata</th>
                        <th>Status</th>
                        <th className="text-end rounded-end pe-4 ">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="ps-4 fw-semibold  fs-7">
                          <div className="symbol symbol-50px ">
                            {viewData?.image_url ? (
                              <img src={viewData?.image_url} alt="" />
                            ) : (
                              <img
                                src={toAbsoluteUrl("media/sticker/04.png")}
                                alt=""
                              />
                            )}
                          </div>
                        </td>
                        <td className="ps-4 fw-semibold  fs-7">
                          {viewData?.version}
                        </td>
                        <td className="ps-4 fw-semibold  fs-7">
                          {viewData?.metadata}
                        </td>
                        <td>
                          {viewData?.status == false ? (
                            <span className="badge badge-danger">Deactive</span>
                          ) : (
                            viewData?.status === true && (
                              <span className="badge badge-light-success">
                                Active
                              </span>
                            )
                          )}
                        </td>
                        <td className="pe-4 text-end">
                          {(auth_permission ||
                            get_permissions?.category_active_deactive) && (
                            <>
                              <Link
                                onContextMenu={(e) => e.preventDefault()}
                                to="#"
                                onClick={() =>
                                  handleActiveDeactive(
                                    viewData?.asset_id,
                                    viewData?.status
                                  )
                                }
                                className="deactivate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i
                                  className={`ki-duotone ki-switch fs-3 ${
                                    viewData?.status === true
                                      ? "text-success"
                                      : viewData?.status === false &&
                                        "text-danger"
                                  }`}
                                >
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>
                              <Tooltip
                                anchorSelect=".deactivate"
                                content={`${
                                  viewData?.status == false
                                    ? "Deactive"
                                    : viewData?.status === true && "Active"
                                }`}
                              />
                            </>
                          )}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default SingleSticker;
