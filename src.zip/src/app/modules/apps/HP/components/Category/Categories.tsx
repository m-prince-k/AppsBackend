import { FC, useEffect, useState } from "react";
import { Tooltip } from "react-tooltip";
import { Link, useLocation } from "react-router-dom";
import {
  capitalizeFirstLetter,
  decryptData,
  encryptData,
  initialQueryState,
  KTSVG,
  SwalResponse,
  useDebounce,
} from "../../../../../../_metronic/helpers";
import { toAbsoluteUrl } from "../../../../../../_metronic/helpers";
import {
  items,
  initialDnDState,
  initialDnDState1,
  handleKeyTextType,
} from "./_model";

import ReactPaginate from "react-paginate";
import { Profile, useAuth } from "../../../../auth";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "../../../../../../store/store";
import {
  activeFrameDeActiveCategory,
  changeReArrangeCategories,
  listingCategory,
} from "../../../../../../store/HP/Category/categorySlice";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
import ReOrderCategories from "./ReOrderCategories";
import { SUCCESS } from "../../../../../../util/messages";

interface appParams {
  app_id: number;
  app_name: string;
  searchSatatus: boolean;
}

const Categories = (props: any) => {
  const {
    categories,
    catTotal,
    type,
    setCurrentPage,
    currentPage,
    itemsPerPage,
    searchTerm,
    setSearch,
    // sortKey,
    // setSortKey,
    // pageCount,
    // setPageCount,
    // itemOffset,
    // setItemOffset,
    // setCurrentItems,
    // currentItems,
  } = props || {};

  const { currentUser, auth } = useAuth();

  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));

  const app_id = filterId;
  const app_name = searchParams.get("name") && searchParams.get("name");

  const [dropCount, setDropCount] = useState(0);
  const [currentItems, setCurrentItems] = useState([]);

  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";

  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  const [category, setCategory] = useState([]);
  const [totalRec, setTotalRec] = useState(0);
  const [loading, setLoading] = useState(false);

  const get_permissions = fetchAuthDetails?.data;

  // const [category, setCategory] = useState(categoryListing);

  const debouncedSearchTerm = useDebounce(searchTerm, 150);

  const dispatch = useDispatch<AppDispatch>();

  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
  });
  const [shouldRefresh, setShouldRefresh] = useState(false);

  //API CONSUME FOR FETCH THE DETAIL RELATED TO CATEGORY
  useEffect(() => {
    if (type == "category") {
      fetchCategory();
    }
  }, [
    searchTerm,
    currentPage,
    itemsPerPage,
    sortKey?.key,
    sortKey?.order,
    app_id,
    type,
  ]);

  async function fetchCategory() {
    let queryParams = "";
    setLoading(true);
    try {
      if (searchTerm) {
        queryParams = `?app_id=${Number(app_id)}&searchTerm=${searchTerm}`;
      } else if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          app_id
        )}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        //here concat the key for paginatgion is here
        queryParams = `?app_id=${Number(app_id)}&page=${Number(
          currentPage
        )}&items_per_page=${Number(itemsPerPage)}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(listingCategory(queryParams));
      setLoading(false);
      if (payload.status === 200) {
        setCategory(payload?.data ? payload?.data : categories);
        setTotalRec(payload?.count ? payload?.count : catTotal);
      }
    } catch (error) {
      throw error;
    }
  }

  useEffect(() => {
    if (debouncedSearchTerm !== undefined && searchTerm !== undefined) {
      setSearch(debouncedSearchTerm);
    }
  }, [debouncedSearchTerm]);

  const [dragAndDrop1, setDragAndDrop1] = useState(initialDnDState1);

  //this is done for drag and drop table
  const onDragStart1 = (event: any) => {
    const initialPosition = Number(event.currentTarget?.dataset?.position);

    setDragAndDrop1({
      ...dragAndDrop1,
      draggedFrom1: initialPosition,
      isDragging1: true,
      originalOrder1: category,
    });

    event.dataTransfer.setData("text/html", "");
  };

  const onDragOver1 = (event: any) => {
    event.preventDefault();

    let newList = dragAndDrop1.originalOrder1;
    const draggedFrom = dragAndDrop1.draggedFrom1;
    const draggedTo = Number(event.currentTarget.dataset.position);

    const itemDragged = newList[draggedFrom];
    const remainingItems = newList.filter(
      (item, index) => index !== draggedFrom
    );

    newList = [
      ...remainingItems.slice(0, draggedTo),
      itemDragged,
      ...remainingItems?.slice(draggedTo),
    ];

    if (draggedTo !== dragAndDrop1.draggedTo1) {
      setDragAndDrop1({
        ...dragAndDrop1,
        updatedOrder1: newList,
        draggedTo1: draggedTo,
      });
    }
  };

  const onDrop1 = async (event: any) => {
    setCategory(dragAndDrop1?.updatedOrder1);
    const targetPosition = dragAndDrop1.draggedTo1;
    const targetCategory = dragAndDrop1.originalOrder1[targetPosition];

    let _payload = {
      category_id:
        dragAndDrop1.originalOrder1[dragAndDrop1.draggedFrom1]?.category_id,
      position: targetCategory?.position,
      app_id: Number(app_id),
    };
    // Call the API only once after drop
    const { payload } = await dispatch(changeReArrangeCategories(_payload));
    if (payload.status === 403) {
      await SwalResponse("danger", "warning", "Something went wrong");
    } else if (payload.status === 200) {
      await SwalResponse(
        "success",
        "Status Updated",
        SUCCESS.REARRANGE_CATEGORIES
      );
      fetchCategory();
    } else if (payload?.status === 401) {
      await SwalResponse("success", payload?.message, payload?.error_details);
    }
    // Reset the dragging state
    setDragAndDrop1({
      ...dragAndDrop1,
      draggedFrom1: null,
      draggedTo1: null,
      isDragging1: false,
    });
  };

  // Optional: If you want to reset the dragged state on drag leave (no need to call API here)
  const onDragLeave1 = (event: any, category_id: number, position: number) => {
    setDragAndDrop1({
      ...dragAndDrop1,
      draggedTo1: null,
    });
  };

  useEffect(() => {
    setDropCount(dragAndDrop1?.draggedTo1);
    console.log("Dragged From: ", dragAndDrop1 && dragAndDrop1.draggedFrom1);
    console.log("Dropping Into: ", dragAndDrop1 && dragAndDrop1.draggedTo1);
  }, [dragAndDrop1]);

  useEffect(() => {
    console.log("List updated!");
  }, [category]);

  //end of drag and drop functinality

  //custom sorting function here
  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "app_id") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "app_id") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: false }));
    } else if (order == "DESC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: true }));
    }
    // else if (order == "ASC" && key == "sticker_count") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "DESC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive3: false }));
    // } else if (order == "DESC" && key == "sticker_count") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "ASC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive3: true }));
    // } else if (order == "ASC" && key == "frame_count") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "DESC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive4: false }));
    // } else if (order == "DESC" && key == "frame_count") {
    //   setSortKey((prevState: any) => ({
    //     ...prevState,
    //     key: key,
    //     order: "ASC",
    //   }));
    //   setActive((prev: any) => ({ ...prev, isActive4: true }));
    // }
  };

  //PAGINATION START HERE FOR CATEGORIES SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(category?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, category]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % category?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };


  //END OF PAGINATION

  //ACTIVE DE-ACTIVE CATEGORY BASED ON CATEGORY ID
  const handleActiveDeactive = async (
    event: any,
    categoryId: number,
    status: boolean
  ) => {
    event.preventDefault();
    try {
      let statusSet = false;
      if (categoryId && app_id) {
        let _payload: object = {
          app_id: Number(app_id),
          category_id: categoryId,
          status: statusSet,
        };
        const { payload } = await dispatch(
          activeFrameDeActiveCategory(_payload)
        );
        if (payload.status === 403) {
          console.log(payload);

          await SwalResponse("danger", "warning", "Something went wrong");
        } else if (payload.status === 200) {
          await SwalResponse("success", "Status Updated", payload?.message);
          let query = `?app_id=${Number(app_id)}`;
          // const { payload: listingResponse } = await dispatch(
          //   listingCategory(query)
          // );
          fetchCategory();
          setShouldRefresh(true);
          // if (listingResponse?.status === 200) {
          //   setCategory(listingResponse?.data);
          //   setTotalRec(listingResponse?.count);
          // }
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        await SwalResponse(
          "danger",
          "warning",
          "category id must be required."
        );
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <>
      <div className="justify-content-end mb-10 d-flex gap-3">
        <div className="d-flex align-items-center position-relative me-auto">
          <i className="ki-duotone ki-magnifier fs-1 position-absolute ms-6">
            <span className="path1"></span>
            <span className="path2"></span>
          </i>
          <input
            type="text"
            data-kt-user-table-filter="search"
            className="form-control w-350px ps-14"
            placeholder="Search Categories"
            value={searchTerm?.trim()}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={handleKeyTextType}
          />
        </div>
        {/* Here button will be come for re order categories */}
        <ReOrderCategories
          shouldRefresh={shouldRefresh}
          setShouldRefresh={setShouldRefresh}
          fetchCategory={fetchCategory}
        />
        {(auth_permission || get_permissions?.category_archived) && (
          <>
            <Link
              to={{
                pathname: `/apps/archivedCategory`,
                search: `?id=${searchParams.get("id")}&name=${app_name}`,
              }}
              //state={{ app_id: app_id, app_name: app_name }}
              className="btn btn-light-warning d-flex align-items-center gap-2"
            >
              <span className="svg-icon svg-icon-1 bi bi-archive-fill"></span>
              Archived Categories
            </Link>
          </>
        )}
        {/* {(auth_permission || get_permissions?.category_create) && (
          <Link
            to="/apps/create-sticker-category/categories"
            className="btn  btn-light-primary d-flex align-items-center gap-2"
          >
            <span className="svg-icon svg-icon-1 bi bi-plus-lg"></span>Add
            Category
          </Link>
        )} */}
      </div>

      <div className="table-responsive">
        <table className="table align-middle gs-0 gy-4">
          <thead>
            <tr className="fw-bold text-muted bg-light">
              {/* <th className="ps-4 w-100px rounded-start">
                <div className="d-flex align-items-center">
                  Apps
                  {active?.isActive1 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("app_id", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short cursor-pointer"
                      onClick={() => onSortChange("app_id", "DESC")}
                    ></i>
                  )}
                </div>
              </th> */}
              <th className="ps-4 w-50px rounded-start">
                <div className="d-flex align-items-center">S.No.</div>
              </th>
              <th>
                <div className="d-flex align-items-center">
                  Category Title
                  {active?.isActive2 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("title", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short  cursor-pointer"
                      onClick={() => onSortChange("title", "DESC")}
                    ></i>
                  )}
                </div>
              </th>
              <th className="w-150px">
                <div className="d-flex align-items-center">
                  No. of Stickers
                  {/* {active?.isActive3 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("sticker_count", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short cursor-pointer"
                      onClick={() => onSortChange("sticker_count", "DESC")}
                    ></i>
                  )} */}
                </div>
              </th>
              <th className="w-150px">
                <div className="d-flex align-items-center">
                  No. of Frames
                  {/* {active?.isActive4 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("frame_count", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short cursor-pointer"
                      onClick={() => onSortChange("frame_count", "DESC")}
                    ></i>
                  )} */}
                </div>
              </th>
              <th className="w-150px">
                <div className="d-flex align-items-center">Status </div>
              </th>
              {auth_permission ||
              get_permissions?.category_re_arrange ||
              get_permissions?.category_active_deactive ||
              get_permissions?.category_read ||
              get_permissions?.category_write ? (
                <th className="w-200px text-end rounded-end pe-4">Actions</th>
              ) : (
                <th className="w-200px text-end rounded-end pe-4"></th>
              )}
            </tr>
          </thead>
          {loading ? (
            <UsersListLoading />
          ) : (
            <>
              {category?.length > 0 ? (
                category?.map((val: any, index: number) => (
                  <>
                    <tbody
                      key={index}
                      onDragStart={onDragStart1}
                      data-position={index}
                      // draggable

                      onDragOver={onDragOver1}
                      onDrop={onDrop1}
                      onDragLeave={(event) =>
                        onDragLeave1(event, val?.category_id, val?.position)
                      }
                      className={
                        dragAndDrop1 &&
                        dragAndDrop1.draggedTo1 === Number(index)
                          ? "dropArea"
                          : ""
                      }
                    >
                      <tr
                      // key={index}
                      // onDragStart={onDragStart1}
                      // data-position={index}
                      // draggable
                      // onDragOver={onDragOver1}
                      // onDrop={onDrop1}
                      // onDragLeave={(event) =>
                      //   onDragLeave1(event, val?.category_id, val?.position)
                      // }
                      // className={
                      //   dragAndDrop1 &&
                      //   dragAndDrop1.draggedTo1 === Number(index)
                      //     ? "dropArea"
                      //     : ""
                      // }
                      >
                        {/* <td className="ps-4 fw-semibold  fs-7">
                          {val?.app?.name || "N/A"}
                        </td> */}
                        <td className="ps-4 fw-semibold  fs-6">{index + 1}</td>
                        <td className="ps-4 fw-semibold  fs-7">
                          {capitalizeFirstLetter(val?.title) || "N/A"}
                        </td>
                        <td className="fw-semibold fs-7">
                          <Link
                            to={{
                              pathname: `/apps/viewSticker`,
                              search: `?id=${searchParams.get(
                                "id"
                              )}&name=${app_name}&catId=${encryptData(
                                val?.category_id
                              )}`,
                            }}
                            title="No of Stickers"
                          >
                            <span className="badge badge-light-success">
                              {val?.sticker_count}
                            </span>
                          </Link>
                          {/* {Number(val?.sticker_count) || 0} */}
                        </td>
                        <td className=" fw-semibold  fs-7">
                          {/* {Number(val?.frame_count) || 0} */}
                          <Link
                            to={{
                              pathname: `/apps/ViewFrame`,
                              search: `?id=${searchParams.get(
                                "id"
                              )}&name=${app_name}&catId=${encryptData(
                                val?.category_id
                              )}`,
                            }}
                            title="No of frames"
                          >
                            <span className="badge badge-light-success">
                              {val?.frame_count}
                            </span>
                          </Link>
                        </td>

                        <td>
                          {val?.status == false ? (
                            <span className="badge badge-danger">Deactive</span>
                          ) : (
                            val?.status === true && (
                              <span className="badge badge-light-success">
                                Active
                              </span>
                            )
                          )}
                        </td>
                        <td className="pe-4 text-end">
                          {(auth_permission ||
                            get_permissions?.category_re_arrange) && (
                            <>
                              <Link
                                to="#"
                                onClick={(e) => {
                                  e.preventDefault();
                                  dragAndDrop1;
                                }}
                                className="btn rearrange btn-icon btn-bg-light btn-active-color-primary btn-sm me-1 custom-rearrange"
                              >
                                <i className="ki-duotone ki-arrow-mix fs-3 custom-rearrange">
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>
                              <Tooltip
                                anchorSelect=".rearrange"
                                content="Rearrange Row"
                              />
                            </>
                          )}
                          {(auth_permission ||
                            get_permissions?.category_read) && (
                            <>
                              <Link
                                to={{
                                  pathname: `/apps/editCategory`,
                                  search: `?id=${searchParams.get(
                                    "id"
                                  )}&name=${app_name}&catId=${encryptData(
                                    val?.category_id
                                  )}`,
                                }}
                                // to="/apps/HP/editCategory"
                                // state={{
                                //   title: val?.title,
                                // }}
                                onContextMenu={(e) => e.preventDefault()}
                                className="btn view btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-eye fs-3">
                                  {" "}
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                  <span className="path3"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".view" content="View" />
                            </>
                          )}
                          {/* {(auth_permission ||
                            get_permissions?.category_write) && (
                            <>
                              <Link
                                to="/apps/HP/editCategory"
                                onContextMenu={(e) => e.preventDefault()}
                                state={{
                                  category_id: Number(val?.category_id),
                                  title: val.title,
                                  app_id: app_id,
                                  app_name:String(app_name)
                                }}
                                className="btn edit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-pencil fs-3">
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".edit" content="Edit" />
                            </>
                          )} */}
                          {(auth_permission ||
                            get_permissions?.category_active_deactive) && (
                            <>
                              <Link
                                to="#"
                                onContextMenu={(e) => e.preventDefault()}
                                onClick={(event) =>
                                  handleActiveDeactive(
                                    event,
                                    val?.category_id,
                                    val?.status
                                  )
                                }
                                className="deactivate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i
                                  className={`ki-duotone ki-switch fs-3 ${
                                    val.status === true
                                      ? "text-success"
                                      : val.status === false && "text-danger"
                                  }`}
                                >
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>

                              <Tooltip
                                anchorSelect=".deactivate"
                                content={`${
                                  val.status == false
                                    ? "Deactive"
                                    : val.status === true && "Active"
                                }`}
                              />
                            </>
                          )}
                        </td>
                      </tr>
                    </tbody>
                  </>
                ))
              ) : (
                <>
                  <tr></tr>
                  <tr>
                    <td colSpan={7}>
                      <div className="d-flex text-center w-100 align-content-center justify-content-center">
                        No matching records found
                      </div>
                    </td>
                  </tr>
                </>
              )}
            </>
          )}
        </table>
      </div>

      <div className="d-flex flex-stack flex-wrap pt-10">
        <div className="fs-6 text-gray-700">
          Showing {Number(currentPage) || 0} to {category?.length || 0} of{" "}
          {totalRec || 0} entries
        </div>
        <ul className="pagination">
          {category?.length > 0 && (
            <ReactPaginate
              nextLabel="Next>"
              onPageChange={(event) => handlePageClick(event)}
              pageRangeDisplayed={3}
              marginPagesDisplayed={2}
              pageCount={pageCount}
              forcePage={currentPage - 1}
              previousLabel="< Previous"
              pageClassName="page-item"
              pageLinkClassName="page-link"
              previousClassName="page-item"
              previousLinkClassName="page-link"
              nextClassName="page-item"
              nextLinkClassName="page-link"
              breakLabel="..."
              breakClassName="page-item"
              breakLinkClassName="page-link"
              containerClassName="pagination"
              activeClassName="active"
              renderOnZeroPageCount={null}
            />
          )}
        </ul>
      </div>
    </>
  );
};

export { Categories };
