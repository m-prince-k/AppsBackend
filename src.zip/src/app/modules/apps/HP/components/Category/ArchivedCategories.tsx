import { FC, useEffect, useState } from "react";
import { Tooltip } from "react-tooltip";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AppDispatch } from "../../../../../../store/store";
import { useDispatch } from "react-redux";
import {
  activeFrameDeActiveCategory,
  allArchivedCategories,
  listingCategory,
} from "../../../../../../store/HP/Category/categorySlice";
import {
  capitalizeFirstLetter,
  decryptData,
  encryptData,
  SwalResponse,
} from "../../../../../../_metronic/helpers";
import { SUCCESS } from "../../../../../../util/messages";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import ReactPaginate from "react-paginate";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";

interface checkCategories {
  app_id: number;
}

const ArchivedCategories: FC = () => {
  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));

  const app_id = filterId;
  const app_name = searchParams.get("name");

  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [archived, setArchived] = useState<Array<object>>([]);
  const navigate = useNavigate();
  const [currentItems, setCurrentItems] = useState([]);
  const itemsPerPage = ITEM_PER_PAGE;
  const [itemOffset, setItemOffset] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [totalRec, setTotalRec] = useState<number>(0);
  const dispatch = useDispatch<AppDispatch>();
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
  });

  //consume call the api for get archived category
  useEffect(() => {
    getAllArchivedCategories();
  }, [currentPage, itemsPerPage, sortKey?.key, sortKey?.order]);

  const getAllArchivedCategories = async () => {
    try {
      setLoading(true);
      let queryParams = "";
      if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          app_id
        )}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        queryParams = `?app_id=${Number(
          app_id
        )}&page=${currentPage}&items_per_page=${itemsPerPage}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(allArchivedCategories(queryParams));
      if (payload?.status === 200) {
        setArchived(payload?.data);
        setTotalRec(payload?.count);
      }
      setLoading(false);
    } catch (err) {
      throw err;
    }
  };
  //custom sorting function here
  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: false }));
    } else if (order == "DESC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: true }));
    } else if (order == "ASC" && key == "sticker_count") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "sticker_count") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    } else if (order == "ASC" && key == "frame_count") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: false }));
    } else if (order == "DESC" && key == "frame_count") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: true }));
    }
  };

  //PAGINATION START HERE FOR CATEGORIES SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(archived?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, archived]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % archived?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };
  //END OF PAGINATION

  //UnArchived category handle call here...
  const unArchivedHandle = async (
    event: any,
    category_id: number,
    status: boolean
  ) => {
    event.preventDefault();
    try {
      if (status == false) {
        const _payload = {
          category_id: category_id,
          status: true,
          app_id: Number(app_id),
        };
        const { payload } = await dispatch(
          activeFrameDeActiveCategory(_payload)
        );
        if (payload.status === 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        } else if (payload.status === 200) {
          await SwalResponse(
            "success",
            "Status Updated",
            SUCCESS.UNARCHIVED_SUCCESS
          );
          navigate(-1);
          const { payload: listingResponse } = await dispatch(
            allArchivedCategories("")
          );
          if (listingResponse.status === 200) {
            setArchived(listingResponse?.data);
            setTotalRec(listingResponse?.count);
          }
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        await SwalResponse(
          "warning",
          "Warning",
          "Category are already in UnArchived ,Please Try again"
        );
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <>
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header align-items-center">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">Archived Categories</h3>
          </div>
          <Link
            to="#"
            onClick={() => navigate(-1)}
            className="d-flex align-items-center gap-2 text-primary"
          >
            <i className="bi bi-arrow-left text-primary"></i> Back
          </Link>
        </div>

        <div className="card-body p-9">
          <div className="table-responsive">
            <table className="table align-middle gs-0 gy-4">
              <thead>
                <tr className="fw-bold text-muted bg-light">
                  {/* <th className="ps-4 w-100px rounded-start">
                    <div className="d-flex align-items-center">
                      Position
                      {active?.isActive1 ? (
                        <i
                          className="bi bi-arrow-up-short cursor-pointer"
                          onClick={() => onSortChange("position", "ASC")}
                        ></i>
                      ) : (
                        <i
                          className="bi bi-arrow-down-short cursor-pointer"
                          onClick={() => onSortChange("position", "DESC")}
                        ></i>
                      )}
                    </div>
                  </th> */}
                  <th>
                    <div className="d-flex align-items-center">
                      Category Title
                      {active?.isActive2 ? (
                        <i
                          className="bi bi-arrow-up-short cursor-pointer"
                          onClick={() => onSortChange("title", "ASC")}
                        ></i>
                      ) : (
                        <i
                          className="bi bi-arrow-down-short  cursor-pointer"
                          onClick={() => onSortChange("title", "DESC")}
                        ></i>
                      )}
                    </div>
                  </th>
                  <th className="w-150px">
                    <div className="d-flex align-items-center">
                      No. of Stickers
                      {/* {active?.isActive3 ? (
                        <i
                          className="bi bi-arrow-up-short cursor-pointer"
                          onClick={() => onSortChange("sticker_count", "ASC")}
                        ></i>
                      ) : (
                        <i
                          className="bi bi-arrow-down-short cursor-pointer"
                          onClick={() => onSortChange("sticker_count", "DESC")}
                        ></i>
                      )} */}
                    </div>
                  </th>
                  <th className="w-150px">
                    <div className="d-flex align-items-center">
                      No. of Frames
                      {/* {active?.isActive4 ? (
                        <i
                          className="bi bi-arrow-up-short cursor-pointer"
                          onClick={() => onSortChange("frame_count", "ASC")}
                        ></i>
                      ) : (
                        <i
                          className="bi bi-arrow-down-short cursor-pointer"
                          onClick={() => onSortChange("frame_count", "DESC")}
                        ></i>
                      )} */}
                    </div>
                  </th>
                  <th className="w-100px">
                    <div className="d-flex align-items-center">Status</div>
                  </th>
                  <th className="w-100px text-end rounded-end pe-4 ">
                    Actions
                  </th>
                </tr>
              </thead>
              {loading ? (
                <UsersListLoading />
              ) : (
                <>
                  <tbody>
                    {archived?.length > 0 ? (
                      archived?.map((val: any, index: number) => (
                        <tr>
                          {/* <td className="ps-4 fw-semibold  fs-7">
                            {val?.position || "N/A"}
                          </td> */}
                          <td className="ps-4 fw-semibold  fs-7">
                            {capitalizeFirstLetter(val?.title) || "N/A"}
                          </td>
                          <td>{val?.sticker_count || 0}</td>
                          <td>{val?.frame_count || 0}</td>

                          <td>
                            <span
                              className={`${
                                val.status === false
                                  ? "badge badge-light-danger"
                                  : val?.status === true &&
                                    "badge badge-light-success"
                              }`}
                            >
                              {val?.status == false && "Deactive"}
                            </span>
                          </td>
                          <td className="pe-4 text-end">
                            <Link
                              to="#"
                              onContextMenu={(e) => e.preventDefault()}
                              onClick={(event) =>
                                unArchivedHandle(
                                  event,
                                  val?.category_id,
                                  val?.status
                                )
                              }
                              className="btn unarchived btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                            >
                              <i
                                className={`ki-duotone ki-switch fs-3 ${
                                  val.status === true
                                    ? "text-success"
                                    : val.status === false && "text-danger"
                                }`}
                              >
                                <span className="path1"></span>
                                <span className="path2"></span>
                              </i>
                            </Link>
                            <Tooltip
                              anchorSelect=".unarchived"
                              content="Unarchived"
                            />
                          </td>
                        </tr>
                      ))
                    ) : (
                      <>
                        <tr></tr>
                        <tr>
                          <td colSpan={7}>
                            <div className="d-flex text-center w-100 align-content-center justify-content-center">
                              No matching records found
                            </div>
                          </td>
                        </tr>
                      </>
                    )}
                  </tbody>
                </>
              )}
            </table>
          </div>
          {archived?.length > 0 && (
            <div className="d-flex flex-stack flex-wrap pt-10">
              <div className="fs-6 text-gray-700">
                Showing {Number(currentPage) || 0} to{" "}
                {Number(archived?.length) || 0} of {Number(totalRec || 0)}{" "}
                entries
              </div>
              {archived?.length > 0 && (
                <ul className="pagination">
                  <ReactPaginate
                    nextLabel="Next>"
                    onPageChange={(event) => handlePageClick(event)}
                    pageRangeDisplayed={3}
                    marginPagesDisplayed={2}
                    pageCount={pageCount}
                    previousLabel="< Previous"
                    pageClassName="page-item"
                    pageLinkClassName="page-link"
                    previousClassName="page-item"
                    previousLinkClassName="page-link"
                    nextClassName="page-item"
                    nextLinkClassName="page-link"
                    breakLabel="..."
                    breakClassName="page-item"
                    breakLinkClassName="page-link"
                    containerClassName="pagination"
                    activeClassName="active"
                    renderOnZeroPageCount={null}
                  />
                </ul>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export { ArchivedCategories };
