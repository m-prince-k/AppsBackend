import { useEffect, useState } from "react";
import {
  decryptData,
  KTSVG,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../_metronic/helpers";
import { initialDnDState, items } from "./_model";
import { Link, useLocation } from "react-router-dom";
import { AppDispatch } from "../../../../../../store/store";
import { useDispatch } from "react-redux";
import {
  CategoriesReOrder,
  changeReArrangeCategories,
  changeReOrderCategories,
  listingCategory,
} from "../../../../../../store/HP/Category/categorySlice";
import { SUCCESS } from "../../../../../../util/messages";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";

type Props = {
  shouldRefresh: boolean;
  setShouldRefresh: React.Dispatch<React.SetStateAction<boolean>>;
  fetchCategory: () => void;
};

const ReOrderCategories = (props: Props) => {
  const [dragAndDrop, setDragAndDrop] = useState(initialDnDState);
  const [list, setList] = useState([]);
  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);

  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  const app_id = filterId;
  const app_name = searchParams.get("name");

  //api call here for fetching the re-order categories
  // useEffect(() => {
  //   ReOrderCategories();
  // }, [props?.app_id]);
  // useEffect(() => {
  //   if (props?.shouldRefresh) {
  //     // Call the function to fetch the reordered categories
  //     ReOrderCategories();

  //     // Reset the refresh flag after fetching
  //     props?.setShouldRefresh(false);
  //   }
  // }, [props?.shouldRefresh]); // Only run when the refresh flag is true

  async function fetchCategories() {
    try {
      setLoading(true);
      const query = `?app_id=${Number(app_id)}`;
      const { payload: data } = await dispatch(listingCategory(query));
      if (data?.status === 200) {
        setList(data?.data);
      }
      setLoading(false);
    } catch (err) {
      throw err;
    }
  }
  const onDragStart = (event: any) => {
    const initialPosition = Number(event?.currentTarget?.dataset?.position);

    setDragAndDrop({
      ...dragAndDrop,
      draggedFrom: initialPosition,
      isDragging: true,
      originalOrder: list,
    });

    event.dataTransfer.setData("text/html", "");
  };

  const onDragOver = (event: any) => {
    event.preventDefault();

    let newList = dragAndDrop?.originalOrder;
    const draggedFrom = dragAndDrop.draggedFrom;
    const draggedTo = Number(event.currentTarget.dataset.position);

    const itemDragged = newList[draggedFrom];
    const remainingItems = newList.filter(
      (item, index) => index !== draggedFrom
    );

    newList = [
      ...remainingItems.slice(0, draggedTo),
      itemDragged,
      ...remainingItems?.slice(draggedTo),
    ];

    if (draggedTo !== dragAndDrop.draggedTo) {
      setDragAndDrop({
        ...dragAndDrop,
        updatedOrder: newList,
        draggedTo: draggedTo,
      });
    }
  };

  const onDrop = async (event: any) => {
    setList(dragAndDrop?.updatedOrder);
    const targetPosition = dragAndDrop.draggedTo;
    const targetCategory = dragAndDrop.originalOrder[targetPosition];
    let _payload = {
      category_id:
        dragAndDrop.originalOrder[dragAndDrop.draggedFrom]?.category_id,
      position: targetCategory?.position,
      app_id: Number(app_id),
    };
    const { payload } = await dispatch(changeReArrangeCategories(_payload));
    if (payload.status === 403) {
      await SwalResponse("danger", "warning", payload?.error_details);
    } else if (payload.status === 200) {
      fetchCategories();
      props?.fetchCategory();
      await SwalResponse("success", "Status Updated", SUCCESS.REORDER_CATEGORY);
    } else if (payload?.status === 401) {
      await SwalResponse("success", payload?.message, payload?.error_details);
    }
    setDragAndDrop({
      ...dragAndDrop,
      draggedFrom: null,
      draggedTo: null,
      isDragging: false,
    });
  };

  const onDragLeave = async (event: any, assetId: number, position: number) => {
    setDragAndDrop({
      ...dragAndDrop,
      draggedTo: null,
    });
  };

  useEffect(() => {}, [dragAndDrop]);

  useEffect(() => {
    console.log("List updated!");
  }, [list]);

  console.log(list);

  return (
    <>
      <Link
        to="#"
        className="btn btn-light-info d-flex align-items-center gap-2"
        data-bs-toggle="modal"
        data-bs-target="#kt_modal_1"
        onClick={() => fetchCategories()}
      >
        <span className="svg-icon svg-icon-1 bi bi-arrows-move"></span>
        Reorder Categories
      </Link>

      <div className="modal fade" tabIndex={-1} id="kt_modal_1">
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <div>
                <h5 className="modal-title">Reorder Categories</h5>
                <p className="mb-0 f-8">
                  Click and drag the icons to re-order. Hover over for category
                  name.
                  {/* Click "Save changes" when finished. */}
                </p>
              </div>
              <div
                className="btn btn-icon btn-sm btn-active-light-primary ms-2"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <KTSVG
                  path="media/icons/duotune/arrows/arr061.svg"
                  className="svg-icon svg-icon-2x"
                />
              </div>
            </div>

            <div className="modal-body">
              <div className="d-flex gap-9 flex-wrap sticker-lists">
                {loading ? (
                  <>
                    <UsersListLoading />
                  </>
                ) : (
                  <>
                    {list?.length > 0 ? (
                      list.map((item, index) => (
                        <>
                          <ul>
                            <li
                              key={index}
                              data-position={index}
                              draggable
                              onDragStart={onDragStart}
                              onDragOver={onDragOver}
                              onDrop={onDrop}
                              onDragLeave={(event) =>
                                onDragLeave(
                                  event,
                                  item?.asset_id,
                                  item?.position
                                )
                              }
                              // onChange={() => handleChangePositionCategory(item?.asset_id,item?.position)}
                              className={
                                dragAndDrop &&
                                dragAndDrop.draggedTo === Number(index)
                                  ? "dropArea"
                                  : ""
                              }
                            >
                              <div className="sticker-item">
                                <div className="symbol symbol-100px ">
                                  {item?.image_url ? (
                                    <img
                                      className="mb-2"
                                      src={item?.image_url}
                                      title={item?.title}
                                    />
                                  ) : (
                                    <img
                                      className="mb-2"
                                      src="https://lh5.googleusercontent.com/proxy/t08n2HuxPfw8OpbutGWjekHAgxfPFv-pZZ5_-uTfhEGK8B5Lp-VN4VjrdxKtr8acgJA93S14m9NdELzjafFfy13b68pQ7zzDiAmn4Xg8LvsTw1jogn_7wStYeOx7ojx5h63Gliw"
                                      title={item?.title}
                                      alt="default Img"
                                    />
                                  )}
                                </div>
                                <div>{item?.title}</div>
                              </div>
                            </li>
                          </ul>
                        </>
                      ))
                    ) : (
                      <>
                        <tr></tr>
                        <tr>
                          <td colSpan={7}>
                            <div className="d-flex text-center w-100 align-content-center justify-content-center">
                              No matching records found
                            </div>
                          </td>
                        </tr>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
            {/* <div className="modal-footer">
                            <button
                                type="button"
                                className="btn btn-light"
                                data-bs-dismiss="modal"
                            >
                                Close
                            </button>
                            <button type="button" className="btn btn-primary">
                                Save changes
                            </button>
                        </div> */}
          </div>
        </div>
      </div>
    </>
  );
};
export default ReOrderCategories;
