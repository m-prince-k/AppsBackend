import {
  Route,
  Routes,
  Outlet,
  Navigate,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { PageLink, PageTitle } from "../../../../../../_metronic/layout/core";
import { Link } from "react-router-dom";
import { Tooltip } from "react-tooltip";
import {
  capitalizeFirstLetter,
  decryptData,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../_metronic/helpers";
import { Profile, useAuth } from "../../../../auth";
import { useDispatch, useSelector } from "react-redux";
import { CategoryElement, CategoryFormData } from "./_model";
import usePageTitle from "../../../../auth/components/PageTitle/usePageTitle";
import { AppDispatch } from "../../../../../../store/store";
import {
  viewCategoryByID,
  viewMasterCategoryByID,
} from "../../../../../../store/HP/Category/categorySlice";
import { useEffect, useState } from "react";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
import dummyImage from "../../../../../../_metronic/assets/images/dummy-image.jpg";
import crypto from "crypto-js";

const usersBreadcrumbs: Array<PageLink> = [
  {
    title: "View category",
    path: "/apps/HP/editCategory",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

interface appParams {
  app_id: number;
  category_id: number;
  app_name: string;
  title: string;
  isView: boolean;
}

const EditCategories = () => {
  usePageTitle("View Category");
  const { currentUser, auth } = useAuth();
  const navigate = useNavigate();

  const { search, state } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterAppId =
    searchParams.get("id") && decryptData(searchParams.get("id"));
  const app_name = searchParams.get("name");
  const filterCatId =
    searchParams.get("catId") && decryptData(searchParams.get("catId"));

  const app_id = filterAppId;
  let catId = filterCatId;

  const dispatch = useDispatch<AppDispatch>();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { fetchAuthDetails } = useSelector(
    (state: { auth: Profile }) => state?.auth
  );
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;
  const [viewData, setViewData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchCategory(); // Invoke fetchCategory to trigger the API
  }, []); // Add dependencies to trigger useEffect when these values change

  const fetchCategory = async () => {
    try {
      setLoading(true);
      //if (isView) {
      let query = `?category_id=${Number(catId)}`;
      let { payload } = await dispatch(viewMasterCategoryByID(query));
      if (payload?.status == 200) {
        setViewData(payload?.data);
      }
      // } else {
      //   let query = `?app_id=${app_id}&category_id=${catId}`;
      //   let { payload } = await dispatch(viewCategoryByID(query));
      //   setViewData(payload?.data);
      // }

      setLoading(false); // Set loading state to false after fetching
    } catch (err) {
      setLoading(false); // Ensure loading state is turned off even in case of an error
    }
  };

  // let apps = viewData.?.reduce((acc: any, obj: any) => {
  //   if (!acc?.some((o: any) => o === obj)) {
  //     acc?.push(obj);
  //   }
  //   return acc;
  // }, []);

  return (
    <>
      <PageTitle breadcrumbs={usersBreadcrumbs}>View Category</PageTitle>

      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">Category Information</h3>
          </div>

          <button
         
         onClick={() => navigate(`/apps/HP?id=${searchParams.get("id")}&name=${app_name}`,{ state: { activeTab: "category" } })}
         className="btn btn-bg"
       >
         <i className="bi bi-arrow-left text-primary"></i> Back
       </button>


        </div>
        {loading ? (
          <UsersListLoading />
        ) : (
          <div className="card-body p-9">
            <div className="row mb-7">
              <label className="col-lg-3 fw-bold text-muted">
                Sticker Category Title
              </label>
              <div className="col-lg-9">
                <span className="fw-bold fs-6">
                  {" "}
                  {viewData?.title
                    ? capitalizeFirstLetter(viewData?.title)
                    : "N/A"}
                </span>
              </div>
            </div>

            <div className="row mb-7">
              <label className="col-lg-3 fw-bold text-muted">Status</label>
              <div className="col-lg-9">
                {viewData?.status ? (
                  viewData?.status == false ? (
                    <span className="badge badge-danger">Deactive</span>
                  ) : (
                    viewData?.status === true && (
                      <span className="badge badge-light-success">Active</span>
                    )
                  )
                ) : (
                  "N/A"
                )}
              </div>
            </div>
            {!app_id && (
              <div className="row mb-7">
                <label className="col-lg-3 fw-bold text-muted">
                  Available in Apps
                </label>
                <div className="col-lg-9">
                  {viewData?.appsData
                    ? viewData?.appsData &&
                      viewData?.appsData?.map((val: any) => (
                        <span className="badge badge-primary">
                          {" "}
                          {val?.name || "N/A"}{" "}
                        </span>
                      ))
                    : "N/A"}
                </div>
              </div>
            )}
            <div className="mt-5">
              {/* {(auth_permission || get_permissions?.category_write) && (
                <Link
                  to="/apps/create-sticker-category/categories"
                  onContextMenu={(e) => e.preventDefault()}
                  state={{
                    category_id: category_id,
                    title: title,
                    app_id: app_id,
                    app_name:String(app_name)
                  }}
                >
                  <button className="btn  btn-light-primary d-flex align-items-center ms-auto">
                    Edit Category
                  </button>
                </Link>
              )} */}
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default EditCategories;
