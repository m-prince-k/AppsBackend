import { FC, useEffect, useState } from "react";
import { Tooltip } from "react-tooltip";
import { Link, useLocation } from "react-router-dom";
import {
  capitalizeFirstLetter,
  encryptData,
  initialQueryState,
  KTSVG,
  SwalResponse,
  useDebounce,
} from "../../../../../../_metronic/helpers";
import { toAbsoluteUrl } from "../../../../../../_metronic/helpers";
import {
  items,
  initialDnDState,
  initialDnDState1,
  handleKeyTextType,
} from "./_model";

import ReactPaginate from "react-paginate";
import { Profile, useAuth } from "../../../../auth";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "../../../../../../store/store";
import {
  activeFrameDeActiveCategory,
  changeReArrangeCategories,
  listingAllCategory,
  listingCategory,
} from "../../../../../../store/HP/Category/categorySlice";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
import ReOrderCategories from "./ReOrderCategories";
import { SUCCESS } from "../../../../../../util/messages";
import usePageTitle from "../../../../auth/components/PageTitle/usePageTitle";
import { PageTitle } from "../../../../../../_metronic/layout/core";

interface appParams {
  app_id: number;
  app_name: string;
}

const MasterCategories = (props: any) => {
  
  usePageTitle("Categories");
  const { categories, catTotal } = props || {};
  const { currentUser, auth } = useAuth();
  const { state } = useLocation();
  const { app_id, app_name } = (state as appParams) || {};
  const itemsPerPage = ITEM_PER_PAGE;
  const [itemOffset, setItemOffset] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [dropCount, setDropCount] = useState(0);
  const [currentItems, setCurrentItems] = useState([]);
  const [isView, setIsView] = useState(false);

  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";

  const [pageCount, setPageCount] = useState(0);

  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  const [category, setCategory] = useState([]);
  const [totalRec, setTotalRec] = useState(0);
  const [loading, setLoading] = useState(false);

  const get_permissions = fetchAuthDetails?.data;

  // const [category, setCategory] = useState(categoryListing);

  const [searchTerm, setSearch] = useState("");
  const debouncedSearchTerm = useDebounce(searchTerm, 150);

  const dispatch = useDispatch<AppDispatch>();

  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });

  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
  });

  //API CONSUME FOR FETCH THE DETAIL RELATED TO CATEGORY
  useEffect(() => {
    fetchAllCategory();
  }, [
    searchTerm,
    currentPage,
    itemsPerPage,
    sortKey?.key,
    sortKey?.order,
    app_id,
  ]);

  async function fetchAllCategory() {
    let queryParams = "";
    setLoading(true);
    try {
      if (searchTerm) {
        queryParams = `?searchTerm=${searchTerm}`;
      } else if (sortKey?.key && sortKey?.order) {
        queryParams = `?page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${sortKey?.key}&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        //here concat the key for paginatgion is here
        queryParams = `?page=${Number(currentPage)}&items_per_page=${Number(
          itemsPerPage
        )}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(listingAllCategory(queryParams));
      setLoading(false);
      if (payload.status === 200) {
        setCategory(payload?.data ? payload?.data : categories);
        setTotalRec(payload?.count ? payload?.count : catTotal);
      }
    } catch (error) {
      throw error;
    }
  }

  useEffect(() => {
    if (debouncedSearchTerm !== undefined && searchTerm !== undefined) {
      setSearch(debouncedSearchTerm);
    }
  }, [debouncedSearchTerm]);

  //custom sorting function here
  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "app_id") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "app_id") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: false }));
    } else if (order == "DESC" && key == "title") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive2: true }));
    } else if (order == "ASC" && key == "sticker") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "sticker") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    } else if (order == "ASC" && key == "frame") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: false }));
    } else if (order == "DESC" && key == "frame") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: true }));
    }
  };

  //PAGINATION START HERE FOR CATEGORIES SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(category?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, category]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % category?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };
  //END OF PAGINATION

  return (
    <>
      <PageTitle breadcrumbs={[]}>CATEGORIES</PageTitle>
      <div className="justify-content-end mb-10 d-flex gap-3">
        <div className="d-flex align-items-center position-relative me-auto">
          <i className="ki-duotone ki-magnifier fs-1 position-absolute ms-6">
            <span className="path1"></span>
            <span className="path2"></span>
          </i>
          <input
            type="text"
            data-kt-user-table-filter="search"
            className="form-control w-350px ps-14"
            placeholder="Search Categories"
            value={searchTerm?.trim()}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={handleKeyTextType}
          />
        </div>
        {(auth_permission || get_permissions?.category_create) && (
          <Link
            to="/apps/create-sticker-category/categories"
            className="btn  btn-light-primary d-flex align-items-center gap-2"
          >
            <span className="svg-icon svg-icon-1 bi bi-plus-lg"></span>Add
            Category
          </Link>
        )}
      </div>
      <div className="table-responsive">
        <table className="table align-middle gs-0 gy-4">
          <thead>
            <tr className="fw-bold text-muted bg-light">
              <th className="ps-4 w-100px rounded-start">
                <div className="d-flex align-items-center">Apps</div>
              </th>
              <th>
                <div className="d-flex align-items-center">
                  Category Title
                  {active?.isActive2 ? (
                    <i
                      className="bi bi-arrow-up-short cursor-pointer"
                      onClick={() => onSortChange("title", "ASC")}
                    ></i>
                  ) : (
                    <i
                      className="bi bi-arrow-down-short  cursor-pointer"
                      onClick={() => onSortChange("title", "DESC")}
                    ></i>
                  )}
                </div>
              </th>
              <th className="w-150px">
                <div className="d-flex align-items-center">Status </div>
              </th>
              {(auth_permission ||
                get_permissions?.category_re_arrange ||
                get_permissions?.category_active_deactive ||
                get_permissions?.category_read ||
                get_permissions?.category_write) ? (
                <th className="w-200px text-end rounded-end pe-4">Actions</th>
              ) : (
                <th className="w-200px text-end rounded-end pe-4"></th>
              )}
            </tr>
          </thead>
          {loading ? (
            <UsersListLoading />
          ) : (
            <>
              {category?.length > 0 ? (
                category?.map((val: any, index: number) => (
                  <>
                    <tbody key={index}>
                      <tr>
                        <td className="ps-4 fw-semibold  fs-7">
                          {val.apps &&
                            val.apps.map((vall: any, index: number) => (
                              <>
                                <span className="badge badge-secondary">
                                  {vall?.name || "Not Found"}
                                </span>{" "}
                              </>
                            ))}
                        </td>
                        <td className=" fw-semibold  fs-7">
                          {capitalizeFirstLetter(val?.title) || "N/A"}
                        </td>
                        <td>
                          {val?.status == false ? (
                            <span className="badge badge-danger">Deactive</span>
                          ) : (
                            val?.status === true && (
                              <span className="badge badge-light-success">
                                Active
                              </span>
                            )
                          )}
                        </td>
                        <td className="pe-4 text-end">
                          {(auth_permission ||
                            get_permissions?.category_read) && (
                            <>
                              <Link
                                to={{
                                  pathname: "/apps/editCategory",
                                  search: `?catId=${encryptData(val?.category_id)}`,
                                }}
                                onContextMenu={(e) => e.preventDefault()}
                                className="btn view btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-eye fs-3">
                                  {" "}
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                  <span className="path3"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".view" content="View" />
                            </>
                          )}
                          {(auth_permission ||
                            get_permissions?.category_write) && (
                            <>
                              <Link
                                to={{
                                  pathname:
                                    "/apps/create-sticker-category/categories",
                                  search: `?catId=${encryptData(val?.category_id)}`,
                                }}
                                onContextMenu={(e) => e.preventDefault()}
                                // state={{
                                //   category_id: Number(val?.category_id),
                                //   title: val.title,
                                //   app_id: app_id,
                                // }}
                                className="btn edit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-pencil fs-3">
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".edit" content="Edit" />
                            </>
                          )}
                        </td>
                      </tr>
                    </tbody>
                  </>
                ))
              ) : (
                <>
                  <tr></tr>
                  <tr>
                    <td colSpan={7}>
                      <div className="d-flex text-center w-100 align-content-center justify-content-center">
                        No matching records found
                      </div>
                    </td>
                  </tr>
                </>
              )}
            </>
          )}
        </table>
      </div>
      <div className="d-flex flex-stack flex-wrap pt-10">
        <div className="fs-6 text-gray-700">
          Showing {Number(currentPage) || 0} to {category?.length || 0} of{" "}
          {totalRec || 0} entries
        </div>
        <ul className="pagination">
          {category?.length > 0 && (
            <ReactPaginate
              nextLabel="Next>"
              onPageChange={(event) => handlePageClick(event)}
              pageRangeDisplayed={3}
              marginPagesDisplayed={2}
              pageCount={pageCount}
              previousLabel="< Previous"
              pageClassName="page-item"
              pageLinkClassName="page-link"
              previousClassName="page-item"
              previousLinkClassName="page-link"
              nextClassName="page-item"
              nextLinkClassName="page-link"
              breakLabel="..."
              breakClassName="page-item"
              breakLinkClassName="page-link"
              containerClassName="pagination"
              activeClassName="active"
              renderOnZeroPageCount={null}
            />
          )}
        </ul>
      </div>
    </>
  );
};

export { MasterCategories };
