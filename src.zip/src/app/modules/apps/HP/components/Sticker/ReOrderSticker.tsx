import { useState, useEffect } from "react";
import { KTSVG, SwalResponse } from "../../../../../../_metronic/helpers";
import { initialDnDState } from "./_model";
import { useDispatch } from "react-redux";
import {
  changeReOrderStickers,
  viewSticker,
} from "../../../../../../store/HP/Sticker/stickerSlice";
import { AppDispatch } from "../../../../../../store/store";
import { Modal } from "react-bootstrap";
import { SUCCESS } from "../../../../../../util/messages";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";

type Props = {
  app_id: any;
  category_id: any;
  modalOpen: boolean;
  setModalOpen: (open: boolean) => void;
};

const ReOrderSticker = ({
  app_id,
  category_id,
  modalOpen,
  setModalOpen,
}: Props) => {
  const [dragAndDrop, setDragAndDrop] = useState(initialDnDState);
  const [list, setList] = useState([]);
  const [totalRec, setTotalRec] = useState(0);

  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchReOrderedStickers();
  }, []);

  async function fetchReOrderedStickers() {
    let queryParams = `?app_id=${Number(app_id)}&category_id=${category_id}`;
    setLoading(true);
    try {
      const { payload } = await dispatch(viewSticker(queryParams));
      if (payload?.status === 200) {
        setList(payload?.data);
        setTotalRec(payload?.count);
      }
      setLoading(false);
    } catch (error) {
      throw error;
    }
  }

  // Handle drag and drop events
  const onDragStart = (event: any) => {
    const initialPosition = Number(event?.currentTarget?.dataset?.position);
    setDragAndDrop({
      ...dragAndDrop,
      draggedFrom: initialPosition,
      isDragging: true,
      originalOrder: list,
    });
    event.dataTransfer.setData("text/html", "");
  };

  const onDragOver = (event: any) => {
    event.preventDefault();
    let newList = dragAndDrop?.originalOrder;
    const draggedFrom = dragAndDrop.draggedFrom;
    const draggedTo = Number(event.currentTarget.dataset.position);
    const itemDragged = newList[draggedFrom];
    const remainingItems = newList.filter(
      (item, index) => index !== draggedFrom
    );
    newList = [
      ...remainingItems.slice(0, draggedTo),
      itemDragged,
      ...remainingItems?.slice(draggedTo),
    ];

    if (draggedTo !== dragAndDrop.draggedTo) {
      setDragAndDrop({
        ...dragAndDrop,
        updatedOrder: newList,
        draggedTo: draggedTo,
      });
    }
  };

  const onDrop = async (event: any) => {
    setList(dragAndDrop?.updatedOrder);
    const targetPosition = dragAndDrop.draggedTo;
    const targetCategory = dragAndDrop.originalOrder[targetPosition];
    let _payload = {
      sticker_id:
        dragAndDrop.originalOrder[dragAndDrop.draggedFrom]?.sticker_id,
      position: targetCategory?.position,
      app_id: Number(app_id),
      category_id: category_id,
    };
    const { payload } = await dispatch(changeReOrderStickers(_payload));
    if (payload.status === 403) {
      await SwalResponse("danger", "warning", payload?.error_details);
    } else if (payload.status === 200) {
      fetchReOrderedStickers();
      await SwalResponse("success", "Status Updated", SUCCESS.REORDER_STICKERS);
      // setModalOpen(false);
    } else if (payload?.status === 401) {
      await SwalResponse("success", payload?.message, payload?.error_details);
    }
    setDragAndDrop({
      ...dragAndDrop,
      draggedFrom: null,
      draggedTo: null,
      isDragging: false,
    });
  };

  const onDragLeave = async (
    event: any,
    stickerId: number,
    position: number
  ) => {
    setDragAndDrop({
      ...dragAndDrop,
      draggedTo: null,
    });
  };

  return (
    <Modal
      show={modalOpen}
      onHide={() => setModalOpen(false)}
      dialogClassName="sticker-custom-my-modal"
    >
      <Modal.Header closeButton>
        <div>
          <h5 className="modal-title">
            Reorder Stickers{" "}
            <small className="badge badge-success">{totalRec || 0}</small>
          </h5>
          <p className="mb-0 f-8">
            Click and drag the icons to re-order. Hover over for sticker name.
            {/* Click "Save changes" when finished. */}
          </p>
        </div>
      </Modal.Header>
      <Modal.Body>
        <div className="modal-body">
          <div className="d-flex gap-9 flex-wrap sticker-lists">
            {loading ? (
              <UsersListLoading />
            ) : (
              <>
                {list?.length > 0 ? (
                  list &&
                  list?.map((item, index) => (
                    <ul key={index}>
                      <li
                        key={index}
                        data-position={index}
                        draggable
                        onDragStart={onDragStart}
                        onDragOver={onDragOver}
                        onDrop={onDrop}
                        onDragLeave={(event) =>
                          onDragLeave(event, item?.sticker_id, item?.position)
                        }
                        // onChange={() => handleChangePositionCategory(item?.asset_id,item?.position)}
                        className={
                          dragAndDrop && dragAndDrop.draggedTo === Number(index)
                            ? "dropArea"
                            : ""
                        }
                      >
                        <div className="sticker-item">
                          <div className="symbol symbol-100px ">
                            <img
                              className="mb-2"
                              src={item?.image_url}
                              title={item?.category?.title}
                            />
                          </div>
                          <div>{item?.category?.title}</div>
                        </div>
                      </li>
                    </ul>
                  ))
                ) : (
                  <div>No matching records found</div>
                )}
              </>
            )}
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button
          className="btn btn-secondary"
          onClick={() => setModalOpen(false)}
        >
          Close
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default ReOrderSticker;
