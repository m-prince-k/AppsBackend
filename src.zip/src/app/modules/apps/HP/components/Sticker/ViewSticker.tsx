import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AppDispatch } from "../../../../../../store/store";
import { useEffect, useState } from "react";
import {
  activeStickerDeActiveFrame,
  changeReOrderStickers,
  viewSticker,
} from "../../../../../../store/HP/Sticker/stickerSlice";
import {
  capitalizeFirstLetter,
  decryptData,
  encryptData,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../_metronic/helpers";
import ReactPaginate from "react-paginate";
import { UsersListLoading } from "../../../user-management/users-list/components/loading/UsersListLoading";
import { ITEM_PER_PAGE } from "../../../../../../util/constant";
import { Profile, useAuth } from "../../../../auth";
import { Tooltip } from "react-tooltip";
import { initialDnDState1 } from "./_model";
import { SUCCESS } from "../../../../../../util/messages";

interface viewStickers {
  sticker_id: number;
  category_id: any;
}

const ViewSticker = () => {
  const navigate = useNavigate();
  const { currentUser, auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;

  const { search, state } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  let filterCatId =
    searchParams.get("catId") && decryptData(searchParams.get("catId"));

  const app_id = filterId;
  const category_id = filterCatId;
  const app_name = searchParams.get("name");

  // const { sticker_id, category_id } = (state as viewStickers) || {};

  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch<AppDispatch>();
  const itemsPerPage = ITEM_PER_PAGE;
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentItems, setCurrentItems] = useState([]);
  const [totalRec, setTotalRec] = useState(0);
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
    isActive5: true,
    isActive6: true,
    isActive7: true,
  });
  const [sticker, setSticker] = useState<any[]>([]);
  const [dragAndDrop1, setDragAndDrop1] = useState(initialDnDState1);

  useEffect(() => {
    fetchViewSticker();
  }, [currentPage, itemsPerPage, sortKey?.key, sortKey?.order]);

  async function fetchViewSticker() {
    let queryParams = "";
    setLoading(true);
    try {
      if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          app_id
        )}&category_id=${category_id}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}`;
      } else if (currentPage && itemsPerPage) {
        //here concat the key for paginatgion is here
        queryParams = `?app_id=${Number(
          app_id
        )}&category_id=${category_id}&page=${Number(
          currentPage
        )}&items_per_page=${Number(itemsPerPage)}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(viewSticker(queryParams));
      setLoading(false);
      if (payload?.status === 200) {
        setSticker(payload?.data);
        setTotalRec(payload?.count);
      } else if (payload?.status === 403) {
        throw payload?.error_details;
      }
    } catch (error) {
      throw error;
    }
  }

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "metadata") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "metadata") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    } else if (order == "ASC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: false }));
    } else if (order == "DESC" && key == "position") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive4: true }));
    }
  };

  //PAGINATION START HERE FOR ASSET SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    if (Array.isArray(sticker)) {
      setCurrentItems(sticker.slice(itemOffset, endOffset));
    }
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, sticker]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % sticker?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };
  //END OF PAGINATION

  const categoryID =
    sticker && sticker?.length > 0 ? sticker[0]?.category_id : null;
  const appID = sticker && sticker?.length > 0 ? sticker[0]?.app_id : null;

  const handleActiveDeactive = async (
    e: any,
    cagtegoryId: number,
    stickerId: number,
    status: boolean
  ) => {
    e.preventDefault();
    try {
      let statusSet = false;
      if (status === true) {
        statusSet = false;
      } else {
        statusSet = true;
      }

      if (cagtegoryId) {
        let _payload: object = {
          category_id: cagtegoryId,
          sticker_id: stickerId,
          status: statusSet,
          //   app_id: app_id,
        };
        const query = `?app_id=${Number(
          app_id
        )}&category_id=${categoryID}&page=${currentPage}&${itemsPerPage}`;
        const { payload } = await dispatch(
          activeStickerDeActiveFrame(_payload)
        );

        if (payload?.status === 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        } else if (payload.status === 200) {
          let { payload } = await dispatch(viewSticker(query));
          setLoading(false);
          if (payload?.status === 200) {
            setSticker(payload?.data);
            setTotalRec(payload?.count);
          }
          await SwalResponse("success", "Status Updated", payload?.message);
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
      } else {
        await SwalResponse("danger", "error", "error");
      }
    } catch (error) {
      throw error;
    }
  };

  const onDragStart1 = (event: any) => {
    const initialPosition = Number(event.currentTarget?.dataset?.position);

    setDragAndDrop1({
      ...dragAndDrop1,
      draggedFrom1: initialPosition,
      isDragging1: true,
      originalOrder1: sticker,
    });

    event.dataTransfer.setData("text/html", "");
  };

  const onDragOver1 = (event: any) => {
    event.preventDefault();

    let newList = dragAndDrop1.originalOrder1;
    const draggedFrom = dragAndDrop1.draggedFrom1;
    const draggedTo = Number(event.currentTarget.dataset.position);

    const itemDragged = newList[draggedFrom];
    const remainingItems = newList.filter(
      (item, index) => index !== draggedFrom
    );

    newList = [
      ...remainingItems.slice(0, draggedTo),
      itemDragged,
      ...remainingItems?.slice(draggedTo),
    ];

    if (draggedTo !== dragAndDrop1.draggedTo1) {
      setDragAndDrop1({
        ...dragAndDrop1,
        updatedOrder1: newList,
        draggedTo1: draggedTo,
      });
    }
  };

  const onDrop1 = async (event: any) => {
    setSticker(dragAndDrop1?.updatedOrder1);
    const targetPosition = dragAndDrop1.draggedTo1;
    const targetCategory = dragAndDrop1.originalOrder1[targetPosition];

    let _payload = {
      sticker_id:
        dragAndDrop1.originalOrder1[dragAndDrop1.draggedFrom1]?.sticker_id,
      position: targetCategory?.position,
      app_id: app_id,
      category_id: category_id,
    };
    const { payload } = await dispatch(changeReOrderStickers(_payload));
    if (payload.status === 403) {
      await SwalResponse("danger", "warning", payload?.error_details);
    } else if (payload.status === 200) {
      // fetchViewSticker();
      await SwalResponse("success", "Status Updated", SUCCESS.REORDER_STICKERS);
    }
    // Reset the dragging state
    setDragAndDrop1({
      ...dragAndDrop1,
      draggedFrom1: null,
      draggedTo1: null,
      isDragging1: false,
    });
  };

  // Optional: If you want to reset the dragged state on drag leave (no need to call API here)
  const onDragLeave1 = (event: any, category_id: number, position: number) => {
    setDragAndDrop1({
      ...dragAndDrop1,
      draggedTo1: null,
    });
  };

  return (
    <>
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header card-header align-items-center">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">View Sticker Information</h3>
          </div>
          <button
            onClick={() =>
              // navigate(
              //   `/apps/HP?id=${searchParams.get("id")}&name=${app_name}`,
              //   { state: { activeTab: "stickers" } }
              // )
              navigate(-1)
            }
            className="btn btn-bg"
          >
            <i className="bi bi-arrow-left text-primary"></i> Back
          </button>
        </div>
        <div className="card-body p-9">
          <div className="table-responsive">
            <table className="table align-middle gs-0 gy-4 stickersCategoriesAlls">
              <thead>
                <tr className="fw-bold text-muted bg-light ">
                  <th>
                    Sticker Images
                    {/* {active?.isActive1 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("image_url", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("image_url", "DESC")}
                      ></i>
                    )} */}
                  </th>
                  <th>
                    Category Name
                    {/* {active?.isActive3 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("metadata", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("metadata", "DESC")}
                      ></i>
                    )} */}
                  </th>
                  {/* <th>
                    Position
                    {active?.isActive4 ? (
                      <i
                        className="bi bi-arrow-up-short cursor-pointer"
                        onClick={() => onSortChange("position", "ASC")}
                      ></i>
                    ) : (
                      <i
                        className="bi bi-arrow-down-short cursor-pointer"
                        onClick={() => onSortChange("position", "DESC")}
                      ></i>
                    )}
                  </th> */}
                  <th>Status</th>
                  {(auth_permission ||
                    get_permissions?.sticker_re_order ||
                    get_permissions?.sticker_write ||
                    get_permissions?.sticker_active_deactive) && (
                    <th className="w-200px text-end rounded-end pe-4">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              {loading ? (
                <UsersListLoading />
              ) : (
                <>
                  {sticker?.length > 0 ? (
                    sticker?.map((val: any, index: number) => (
                      <>
                        <tbody
                        // key={index}
                        // onDragStart={onDragStart1}
                        // data-position={index}
                        // //draggable

                        // onDragOver={onDragOver1}
                        // onDrop={onDrop1}
                        // onDragLeave={(event) =>
                        //   onDragLeave1(event, val?.category_id, val?.position)
                        // }
                        // className={
                        //   dragAndDrop1 &&
                        //   dragAndDrop1.draggedTo1 === Number(index)
                        //     ? "dropArea"
                        //     : ""
                        // }
                        >
                          <tr>
                            <td>
                              {val?.image_url ? (
                                <img
                                  src={val?.image_url}
                                  alt=""
                                  className="w-50px"
                                />
                              ) : (
                                <img
                                  src={toAbsoluteUrl("media/sticker/04.png")}
                                  alt=""
                                  className="w-50px"
                                />
                              )}
                            </td>
                            <td className="ps-4 fw-semibold  fs-7">
                              {val?.category?.title
                                ? capitalizeFirstLetter(val?.category?.title)
                                : "N/A"}
                            </td>
                            {/* <td className="ps-4 fw-semibold  fs-7">
                              {val?.position}
                            </td> */}
                            <td>
                              {val?.status == false ? (
                                <span className="badge badge-danger">
                                  Deactive
                                </span>
                              ) : (
                                val?.status === true && (
                                  <span className="badge badge-light-success">
                                    Active
                                  </span>
                                )
                              )}
                            </td>
                            <td className="pe-4 text-end">
                              {/* {(auth_permission || get_permissions?.sticker_re_order) && (
                                <>
                                  <Link
                                    to="#"
                                    onClick={() => dragAndDrop1}
                                    className="btn rearrange btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                  >
                                    <i className="ki-duotone ki-arrow-mix fs-3 custom-rearrange">
                                      <span className="path1"></span>
                                      <span className="path2"></span>
                                    </i>
                                  </Link>
                                  <Tooltip
                                    anchorSelect=".rearrange"
                                    content="Rearrange Row"
                                  />
                                </>
                              )} */}
                              {(auth_permission ||
                                get_permissions?.sticker_write) && (
                                <>
                                  <Link
                                    to={{
                                      pathname: `/apps/addStickers`,
                                      search: `?id=${searchParams.get(
                                        "id"
                                      )}&name=${app_name}&catId=${encryptData(
                                        val?.category_id
                                      )}&stickId=${encryptData(
                                        val?.sticker_id
                                      )}`,
                                    }}
                                    onContextMenu={(e) => e.preventDefault()}
                                    // state={{
                                    //   category_id: Number(val?.category_id),
                                    //   sticker_id: Number(val?.sticker_id),
                                    //   title: val.title,
                                    // }}
                                    className="btn edit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                  >
                                    <i className="ki-duotone ki-pencil fs-3">
                                      <span className="path1"></span>
                                      <span className="path2"></span>
                                    </i>
                                  </Link>
                                  <Tooltip
                                    anchorSelect=".edit"
                                    content="Edit"
                                  />
                                </>
                              )}

                              {(auth_permission ||
                                get_permissions?.sticker_active_deactive) && (
                                <>
                                  <>
                                    <Link
                                      to="#"
                                      onContextMenu={(e) => e.preventDefault()}
                                      onClick={(e) =>
                                        handleActiveDeactive(
                                          e,
                                          val?.category_id,
                                          val?.sticker_id,
                                          val?.status
                                        )
                                      }
                                      className={`${
                                        val?.status == true
                                          ? "deactivate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                          : "activate btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                      }`}
                                    >
                                      <i
                                        className={`ki-duotone ki-switch fs-3 ${
                                          val?.status == false
                                            ? "text-danger"
                                            : "text-success"
                                        }`}
                                      >
                                        <span className="path1"></span>
                                        <span className="path2"></span>
                                      </i>
                                    </Link>

                                    <Tooltip
                                      anchorSelect={` ${
                                        val.status == true
                                          ? ".deactivate"
                                          : ".activate"
                                      } `}
                                      content={` ${
                                        val?.status == true
                                          ? "Activate"
                                          : "DeActivate"
                                      } `}
                                    />
                                  </>
                                </>
                              )}
                            </td>
                          </tr>
                        </tbody>
                      </>
                    ))
                  ) : (
                    <>
                      <tr>
                        <td colSpan={7}>
                          <div className="d-flex text-center w-100 align-content-center justify-content-center">
                            No matching records found
                          </div>
                        </td>
                      </tr>
                    </>
                  )}
                </>
              )}
            </table>
          </div>
          <div className="d-flex flex-stack flex-wrap pt-10">
            <div className="fs-6 text-gray-700">
              Showing {Number(currentPage) || 0} to {sticker?.length || 0} of{" "}
              {totalRec || 0} entries
            </div>
            <ul className="pagination">
              {sticker?.length > 0 && (
                <ReactPaginate
                  nextLabel="Next>"
                  onPageChange={(event) => handlePageClick(event)}
                  pageRangeDisplayed={3}
                  marginPagesDisplayed={2}
                  pageCount={pageCount}
                  previousLabel="< Previous"
                  pageClassName="page-item"
                  pageLinkClassName="page-link"
                  previousClassName="page-item"
                  previousLinkClassName="page-link"
                  nextClassName="page-item"
                  nextLinkClassName="page-link"
                  breakLabel="..."
                  breakClassName="page-item"
                  breakLinkClassName="page-link"
                  containerClassName="pagination"
                  activeClassName="active"
                  renderOnZeroPageCount={null}
                />
              )}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewSticker;
