export const initialDnDState = {
    draggedFrom: null,
    draggedTo: null,
    isDragging: false,
    originalOrder: [],
    updatedOrder: [],
  };
  
  export const initialDnDState1 = {
    draggedFrom1: null,
    draggedTo1: null,
    isDragging1: false,
    originalOrder1: [],
    updatedOrder1: [],
    draggedCategoryId1: null,
  };