import {Route, Routes, Outlet, Navigate, useNavigate} from 'react-router-dom'
import {PageLink, PageTitle} from '../../../../../../_metronic/layout/core'
import { Link } from 'react-router-dom'
import ViewSticker from './ViewSticker'

const usersBreadcrumbs: Array<PageLink> = [
  // {
  //   title: 'View Stickers',
  //   path: '#',
  //   isSeparator: false,
  //   isActive: false,
  // },
  // {
  //   title: '',
  //   path: '',
  //   isSeparator: true,
  //   isActive: false,
  // },
]

const ViewStickers = () => {
  return (
    <>
    <PageTitle breadcrumbs={usersBreadcrumbs}>View Stickers</PageTitle>
    <ViewSticker/>
  </>
  )
}

export default ViewStickers
