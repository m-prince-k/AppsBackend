import React, { useState } from 'react';
import Select from 'react-select';

interface OptionType {
  value: string;
  label: string;
}

const options: OptionType[] = [
  { value: 'option1', label: 'Option 1' },
  { value: 'option2', label: 'Option 2' },
  { value: 'option3', label: 'Option 3' },
  { value: 'option4', label: 'Option 4' },
];

const MultiSelectDropdown: React.FC = () => {
  const [selectedOptions, setSelectedOptions] = useState<OptionType[]>([]);

  const handleChange = (selected: OptionType[] | null) => {
    setSelectedOptions(selected || []);
  };

  return (
    <div>
      <Select
        isMulti
        options={options}
        value={selectedOptions}
        // onChange={handleChange}
        placeholder="Select options..."
      />
    </div>
  );
};

export default MultiSelectDropdown;
