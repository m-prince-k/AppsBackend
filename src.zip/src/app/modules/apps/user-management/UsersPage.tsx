import { FC } from "react";
import { Route, Routes, Outlet, Navigate } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../../_metronic/layout/core'
import { Link } from 'react-router-dom'
import Select from 'react-select'
import MultiSelectDropdown from "./MultiSelect";
import FileUpload from "./FileUpload";


const usersBreadcrumbs: Array<PageLink> = [
  {
    title: 'User Management',
    path: '/apps/user-management/users',
    isSeparator: false,
    isActive: false,
  },
  {
    title: '',
    path: '',
    isSeparator: true,
    isActive: false,
  },
]

const options = [
  { value: 'option 1', label: 'Option 1' },
  { value: 'option 2', label: 'Option 2' },
  { value: 'option 3', label: 'Option 3' },
  { value: 'option 4', label: 'Option 4' },
  { value: 'option 5', label: 'Option 5' },
]
const UsersPage = () => {
  return (
    <Routes>
      <Route element={<Outlet />}>
        <Route
          path='users'
          element={
            <>
              <PageTitle breadcrumbs={usersBreadcrumbs}>Users list</PageTitle>
             


              <div className='card mb-5 mb-xl-10' id='kt_profile_details_view'>
                <div className='card-header'>
                  <div className='card-title m-0'>
                    <h3 className='fw-bolder m-0'>Add Information</h3>
                  </div>


                </div>

                <div className='card-body p-9'>
                  <div className="row">
                    <div className="col-md-6">
                    <div className='mb-10'>
                    <label className='form-label'>Sticker Category </label>
                    <Select
                      className='react-select-styled'
                      classNamePrefix='react-select'
                      options={options}
                      placeholder='Select an option'
                    />
                  </div>
                  <div className='mb-10 mutiselect-box'>
                    <label className='form-label'>Available in Apps </label>
                      <MultiSelectDropdown/>
                  </div>
                    </div>
                    <div className="col-md-6">

             
            <FileUpload />
     
                    </div>
                  </div>
                
                </div>
              </div>
            </>
          }
        />
      </Route>
      <Route index element={<Navigate to='/apps/user-management/users' />} />
    </Routes>
  )
}

export default UsersPage
