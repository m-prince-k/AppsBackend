import { useEffect, useState } from "react";
import * as Yup from "yup";
import clsx from "clsx";
import { Link, Outlet, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";

import { useAuth0 } from "@auth0/auth0-react";
import { useAuth } from "../../../auth";
import { toAbsoluteUrl } from "../../../../../_metronic/helpers";

const loginSchema = Yup.object().shape({
  email: Yup.string()
    .email("Wrong email format")
    .min(3, "Minimum 3 symbols")
    .max(50, "Maximum 50 symbols")
    .required("Email is required"),
  password: Yup.string()
    .min(3, "Minimum 3 symbols")
    .max(50, "Maximum 50 symbols")
    .required("Password is required"),
});

export function InviteForm() {
  const [loading, setLoading] = useState(false);
  const { saveAuth, setCurrentUser } = useAuth();
  const { demoDetails } = useSelector((state: any) => state.auth);
  const { loginWithRedirect } = useAuth0();
  const navigate = useNavigate();
  //   const queryParams = new URLSearchParams(search);
  //   const token = queryParams.get("token");
  //   const inviteType = queryParams.get("type");
  const { logout } = useAuth();
  const [isVisible, setVisible] = useState(false);
  const [isVisible1, setVisible1] = useState(false);
  //   const [initialValues, setIntialiValues] = useState({
  //     old_password: "",
  //     new_password: "",
  //     password: "",
  //     confirm_password: "",
  //     error1: "",
  //     error2: "",
  //     error3: "",
  //     error4: "",

  //     old_password_error: "",
  //     new_password_error: "",
  //     confirm_password_error: "",
  //   });

  const formik = useFormik({
    initialValues: {
      password: "",
      confirm_password: "",
    },
    validationSchema: Yup.object({
      password: Yup.string()
        .min(8, "Password must be at least 8 characters")
        .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
        .matches(/[0-9]/, "Password must contain at least one number")
        .matches(
          /[@$!%*?&]/,
          "Password must contain at least one special character"
        )
        .required("Password is required"),
      confirm_password: Yup.string()
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .required("Confirm password is required"),
    }),
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      setLoading(true);
      try {
        setLoading(false);
      } catch (error) {
        setSubmitting(false);
        setLoading(false);
      }
    },
  });


  return (
    <>
      <div className="d-flex flex-column flex-lg-row flex-column-fluid h-100">
        <div className="d-flex flex-column flex-lg-row-fluid w-lg-50 p-10 order-2 order-lg-1">
          <div className="d-flex flex-center flex-column flex-lg-row-fluid">
            <div className="w-lg-500px p-10">
              <form
                className="form w-100"
                onSubmit={formik.handleSubmit}
                noValidate
                id="kt_login_signin_form"
              >
                {/* begin::Heading */}
                <div className="text-center mb-11">
                  <h1 className="text-gray-900 fw-bolder mb-3">Invite User</h1>
                  <div className="text-gray-500 fw-semibold fs-6">
                    Your Appsbackend Portal
                  </div>
                </div>
                <div className="fv-row mb-8">
                  <label className="form-label fs-6 fw-bolder text-gray-900">
                    Password
                  </label>
                  <div className="d-flex position-relative">
                    <input
                      maxLength={50}
                      placeholder="Password"
                      {...formik.getFieldProps("password")}
                      className={clsx(
                        "form-control bg-transparent",
                        {
                          "is-invalid":
                            formik?.touched?.password &&
                            formik?.errors.password,
                        },
                        {
                          "is-valid":
                            formik?.touched?.password &&
                            !formik?.errors?.password,
                        }
                      )}
                      type={!isVisible ? "password" : "text"}
                      onChange={formik.handleChange}
                      value={formik.values.password}
                      autoComplete="off"
                    />
                    {isVisible ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible(!isVisible)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible(!isVisible)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                  </div>
                  {formik.touched.password && formik.errors.password && (
                    <div className="fv-plugins-message-container">
                      <div className="fv-help-block">
                        <span role="alert">{formik.errors.password}</span>
                      </div>
                    </div>
                  )}
                </div>
                <div className="fv-row mb-3">
                  <label className="form-label fw-bolder text-gray-900 fs-6 mb-0">
                    Confirm Password
                  </label>
                  <div className="d-flex position-relative">
                    <input
                      maxLength={50}
                      type={!isVisible1 ? "confirm_password" : "text"}
                      placeholder="Confirm password"
                      autoComplete="off"
                      {...formik.getFieldProps("confirm_password")}
                      className={clsx(
                        "form-control bg-transparent",
                        {
                          "is-invalid":
                            formik?.touched?.confirm_password &&
                            formik?.errors?.confirm_password,
                        },
                        {
                          "is-valid":
                            formik?.touched?.confirm_password &&
                            !formik?.errors?.confirm_password,
                        }
                      )}
                      name="confirm_password"
                      onChange={formik.handleChange}
                      value={formik.values.confirm_password}
                    />
                    {isVisible1 ? (
                      <i
                        className="ki-duotone ki-eye fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible1(!isVisible1)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                      </i>
                    ) : (
                      <i
                        className="ki-duotone ki-eye-slash fs-6 cursor-pointer password-icon"
                        onClick={() => setVisible1(!isVisible1)}
                      >
                        <span className="path1"></span>
                        <span className="path2"></span>
                        <span className="path3"></span>
                        <span className="path4"></span>
                      </i>
                    )}
                  </div>
                  {formik.touched.confirm_password &&
                    formik.errors.confirm_password && (
                      <div className="fv-plugins-message-container">
                        <div className="fv-help-block">
                          <span role="alert">
                            {formik.errors.confirm_password}
                          </span>
                        </div>
                      </div>
                    )}
                </div>
                <div className="d-flex flex-stack flex-wrap gap-3 fs-base fw-semibold mb-8"></div>
                {/* begin::Action */}
                <div className="d-grid mb-8">
                  <button
                    type="submit"
                    id="kt_sign_in_submit"
                    className="btn btn-primary"
                    disabled={formik.isSubmitting || !formik.isValid}
                  >
                    {!loading && (
                      <span className="indicator-label">Continue</span>
                    )}
                    {loading && (
                      <span
                        className="indicator-progress"
                        style={{ display: "block" }}
                      >
                        Please wait...
                        <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                      </span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
          {/* end::Form */}
        </div>
        <div
          className="d-flex flex-lg-row-fluid w-lg-50 bgi-size-cover bgi-position-center order-1 order-lg-2"
          style={{
            backgroundImage: `url(${toAbsoluteUrl("media/misc/auth-bg.png")})`,
          }}
        >
          {/* begin::Content */}
          <div className="d-flex flex-column flex-center py-15 px-5 px-md-15 w-100">
            {/* begin::Logo */}
            <Link to="/" className="mb-12">
              <img
                alt="Logo"
                src={toAbsoluteUrl("media/logos/custom-1.png")}
                className="h-100px"
              />
            </Link>
            {/* end::Logo */}

            {/* begin::Image */}
            <img
              className="mx-auto w-275px w-md-50 w-xl-500px mb-10 mb-lg-20"
              src={toAbsoluteUrl("media/misc/auth-screens.png")}
              alt=""
            />
            {/* end::Image */}

            {/* begin::Title */}
            <h1 className="text-white fs-2qx fw-bolder text-center mb-7">
              Appsbackend
            </h1>
            {/* end::Title */}
          </div>
          {/* end::Content */}
        </div>
        {/* end::Aside */}
      </div>
    </>
  );
}
