// src/FileUpload.js
import React, { useState, useCallback } from 'react';

const FileUpload = () => {
    const [files, setFiles] = useState([]);

    // const handleFiles = (newFiles) => {
    //     setFiles((prevFiles) => [...prevFiles, ...newFiles]);
    // };
    

    const onDrop = useCallback((e:any) => {
        e.preventDefault();
        const droppedFiles = Array.from(e.dataTransfer.files);
        // handleFiles(droppedFiles);
    }, []);

    const onDragOver = (e:any) => {
        e.preventDefault();
    };

    const onFileChange = (e:any) => {
        const selectedFiles = Array.from(e.target.files);
        // handleFiles(selectedFiles);
    };

    const handleRemove = (index:any) => {
        setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
    };

    return (
        <div>
            <label className='form-label'>Choose Sticker </label>
            <div
                onDrop={onDrop}
                onDragOver={onDragOver}
               className='upload-draggable'
            >
               <svg stroke="currentColor" fill="currentColor" stroke-width="0" version="1" viewBox="0 0 48 48" enable-background="new 0 0 48 48" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><polygon fill="#90CAF9" points="40,45 8,45 8,3 30,3 40,13"></polygon><polygon fill="#E1F5FE" points="38.5,14 29,14 29,4.5"></polygon><polygon fill="#1565C0" points="21,23 14,33 28,33"></polygon><polygon fill="#1976D2" points="28,26.4 23,33 33,33"></polygon><circle fill="#1976D2" cx="31.5" cy="24.5" r="1.5"></circle></svg>
               Drop your image here, or
                <span className="text-blue-500">Browse</span>
                <input type="file" multiple onChange={onFileChange} />
                <span className='text-muted'>Support: jpeg, png</span>
            </div>
            <ul>
                {files.map((file, index) => (
                    <li key={index}><button onClick={() => handleRemove(index)}>Remove</button></li>
                ))}
            </ul>
        </div>
    );
};

export default FileUpload;
