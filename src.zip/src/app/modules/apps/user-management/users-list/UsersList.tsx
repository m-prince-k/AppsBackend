import { UsersListHeader } from "./components/header/UsersListHeader";
import { UsersTable } from "./table/UsersTable";
import { KTCard } from "../../../../../_metronic/helpers";

const UsersList = () => {
  // const {itemIdForUpdate} = useListView()
  return (
    <>
      <KTCard>
        <UsersListHeader />
        <UsersTable />
      </KTCard>
      {/* {itemIdForUpdate !== undefined && <UserEditModal />} */}
    </>
  );
};

const UsersListWrapper = () => (
  <>
    <UsersList />
  </>
);

export { UsersListWrapper };
