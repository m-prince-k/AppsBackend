import { Route, Routes } from "react-router-dom";
import { PageLink, PageTitle } from "../../../../_metronic/layout/core";
import CreateApp from "./component/CreateApp";


const profileBreadCrumbs: Array<PageLink> = [
    {
        title: "Apps",
        path: "apps",
        isSeparator: false,
        isActive: false,
    },
    {
        title: "",
        path: "",
        isSeparator: true,
        isActive: false,
    },
];

const AppPage = () => (

    <Routes>
        <Route
            path="createApp"
            element={
                <>
                    <PageTitle breadcrumbs={profileBreadCrumbs}>Apps</PageTitle>
                    <CreateApp />
                </>
            }
        >

    </Route>
</Routes >
)

export default AppPage;