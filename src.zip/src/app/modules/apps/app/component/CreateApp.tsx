import { useState } from "react";
import { PageTitle } from "../../../../../_metronic/layout/core";
import { Link, useNavigate } from "react-router-dom";
import Select from "react-select";
import { AppOption } from "../core/_models";
import { AppDispatch } from "../../../../../store/store";
import { useDispatch } from "react-redux";
import { makeApp } from "../../../../../store/Apps/appSlice";
import { SwalResponse } from "../../../../../_metronic/helpers";
import usePageTitle from "../../../auth/components/PageTitle/usePageTitle";

const CreateApp = () => {
  usePageTitle("Create An App");
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const [appName, setAppName] = useState("");
  const [validation, setValidation] = useState("");
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [loading, setLoading] = useState(false);

  // const handleCreateApp = async (event: any) => {
  //   try {
  //     event.preventDefault();
  //     setLoading(true);
  //     if (appName == "") {
  //       setValidation("Please enter the app name");
  //       setLoading(false);
  //     } else {
  //       setValidation("");
  //       //Here api will consume while create the app
  //       let _payload = { name: appName ? appName?.trim() : "" };

  //       const { payload } = await dispatch(makeApp(_payload));
  //       if (payload?.status === 403) {
  //         await SwalResponse(
  //           "warning",
  //           "Warning",
  //           payload?.message || payload?.error_details
  //         );
  //       } else if (payload?.status === 200) {
  //         await SwalResponse("success", "App Created", payload?.message);
  //         navigate("/");
  //       } else {
  //         await SwalResponse("danger", "Wrong", payload?.error_details);
  //       }
  //       setLoading(false);
  //     }
  //   } catch (error) {
  //     throw error;
  //   }
  // };

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  const handleKeyUp = () => {
    // Regular expression check for only letters and spaces
    const regex = /^[A-Za-z0-9 ]*$/;
    if (appName !== "" && !regex.test(appName)) {
      setValidation(
        "Please enter an app name (only letters, numbers, and spaces allowed)"
      );
    } else if (appName === "") {
      setValidation("Please enter the app name");
    } else {
      setValidation("");
    }
  };
  console.log(appName);

  const handleCreateApp = async (event: any) => {
    event.preventDefault();
    const regex = /^[A-Za-z0-9 ]*$/;
    if (appName.trim() === "") {
      setValidation("Please enter the app name");
      setLoading(false);
      return;
    }

    if (!regex.test(appName)) {
      setValidation(
        "Please enter an app name (only letters, numbers, and spaces allowed)"
      );
      setLoading(false);
      return;
    }

    setValidation("");
    try {
      setLoading(true);
      let _payload = { name: appName.trim() };
      // Dispatch the API call
      const { payload } = await dispatch(makeApp(_payload));

      // Handle the response based on status codes
      if (payload?.status === 403) {
        await SwalResponse(
          "warning",
          "Warning",
          payload?.message || payload?.error_details
        );
      } else if (payload?.status === 200) {
        await SwalResponse("success", "App Created", payload?.message);
        navigate("/");
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      } else {
        await SwalResponse("danger", "Wrong", payload?.error_details);
      }

      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error(error);
    }
  };

  return (
    <>
      <PageTitle>Create App</PageTitle>
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">Create An App</h3>
          </div>
        </div>

        {/* Form section */}
        <form onSubmit={handleCreateApp}>
          <div className="card-body p-9">
            <div className="row">
              <div className="col-md-6">
                {/* Sticker Category Select */}
                <div className="mb-10">
                  <label className="form-label required">App Name</label>
                  <input
                    type="text"
                    maxLength={20}
                    onKeyUp={handleKeyUp}
                    onKeyDown={handleKeyTextType}
                    value={appName}
                    onChange={(e) => {
                      setAppName(e.target.value);
                      setValidation("");
                    }}
                    placeholder="Enter the app name"
                    className="form-control"
                  />
                  <small className="text-danger">{validation}</small>
                </div>

                <div className="mb-10 mutiselect-box">
                  {/* <label className="form-label">Version </label>
                                    <Select
                                        isMulti
                                        options={AppOption}
                                        value={selectedOptions}
                                        placeholder="Select options..."
                                    /> */}
                </div>
              </div>

              {/* Form buttons */}
              <div className="d-flex mt-10 gap-3 justify-content-end">
                <Link
                  to="#"
                  onClick={() => navigate(-1)}
                  className={`btn btn-bg-light btn-active-color-dark ${
                    loading ? "disabled" : ""
                  }`}
                  // className="btn btn-bg-light btn-active-color-dark"
                  aria-disabled={loading}
                >
                  Back
                </Link>

                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {loading ? (
                    <span
                      className="indicator-progress"
                      style={{ display: "block" }}
                    >
                      Please wait...{" "}
                      <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                  ) : (
                    <span className="indicator-label">Create App</span>
                  )}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};
export default CreateApp;
