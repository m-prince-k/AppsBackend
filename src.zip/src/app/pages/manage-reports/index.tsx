import { Outlet, Route, Routes } from "react-router-dom";
import { PageLink, PageTitle } from "../../../_metronic/layout/core";
import ReportManage from "./reports";

const reportBreadcrumbs: Array<PageLink> = [
    {
        title: "Manage Reports",
        path: "/apps/manage-reports",
        isSeparator: false,
        isActive: false,
    },
    {
        title: "",
        path: "",
        isSeparator: true,
        isActive: false,
    },
];

const ManageReports = () => {
    return (
        <Routes>
            <Route element={<Outlet />}>
                <Route
                    path="reports"
                    element={
                        <>
                            <PageTitle breadcrumbs={reportBreadcrumbs}>Manage Reports</PageTitle>
                            <ReportManage />
                        </>
                    }
                />
            </Route>
        </Routes>
    )
}

export default ManageReports;