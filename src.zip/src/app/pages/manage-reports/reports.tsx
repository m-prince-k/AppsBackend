import usePageTitle from "../../modules/auth/components/PageTitle/usePageTitle";

const ReportManage = () => {
    usePageTitle("Manage Reports");
    return (
        <>
       
        </>
    )
}
export default ReportManage;