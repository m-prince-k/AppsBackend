export const Validation = {
  app_id: "",
  printer: "",
  version: "",
  file_url: "",
  file_name: "",
  file_type: "",
  isForce: "",
  comment: "",
  file_version:""
};

export interface firmware {
  firmware_app_id: number;
  firmware_id: number;
  firmware_app_name: string;
  activeFirmwareTab: any;
}
