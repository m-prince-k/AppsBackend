import { useLocation } from "react-router-dom";
import { DevEnvironment } from "./HP/DevEnvironment";
import { ProductionEnvironment } from "./ProductionEnvironment";
import { useState, useEffect } from "react";
import { firmware } from "./core/_model";
import { ITEM_PER_PAGE } from "../../../util/constant";
import { decryptData } from "../../../_metronic/helpers";

interface LocationState {
  activeTab1: string;
}

const FirmwareLayout = () => {
  const { state, search } = useLocation();
  const locationState = state as LocationState;
  const { activeFirmwareTab } = (state as firmware) || {};
  const searchParams = new URLSearchParams(search);
  let filterId = searchParams.get("id") && decryptData(searchParams.get("id"));
  const firmware_app_id = filterId;
  const firmware_app_name = searchParams.get("name");
  const itemsPerPage = ITEM_PER_PAGE;
  const [activeTab, setActiveTab] = useState("development");
  const [currentPage, setCurrentPage] = useState(1);
  console.log(firmware_app_id);

  useEffect(() => {
    if (locationState?.activeTab1) {
      setActiveTab(locationState.activeTab1);
    } else if (Number(firmware_app_id)) {
      setActiveTab("development");
      setCurrentPage(1); // Reset the current page when app_id changes
    }
  }, [locationState?.activeTab1, firmware_app_id]);

  const handleTabClick = (type: string) => {
    setActiveTab(type);
  };

  return (
    <div className="card">
      <div className="card-body">
        <ul className="nav nav-tabs nav-line-tabs mb-10 fs-6 nav-pills">
          <li className="nav-item">
            <a
              className={`nav-link ${
                activeTab === "development" ? "active" : ""
              }`}
              data-bs-toggle="tab"
              href="#kt_tab_pane_4"
              onClick={(e) => {
                e.preventDefault();
                handleTabClick("development"); // Set active tab to development and trigger API
              }}
            >
              Dev Environment
            </a>
          </li>
          <li className="nav-item">
            <a
              className={`nav-link ${
                activeTab === "production" ? "active" : ""
              }`}
              data-bs-toggle="tab"
              href="#kt_tab_pane_5"
              onClick={(e) => {
                e.preventDefault();
                handleTabClick("production"); // Set active tab to production and trigger API
              }}
            >
              Production Environment
            </a>
          </li>
        </ul>
        <div className="tab-content" id="myTabContent">
          <div
            className={`tab-pane fade ${
              activeTab === "development" ? "show active" : ""
            }`}
            id="kt_tab_pane_4"
            role="tabpanel"
          >
            <DevEnvironment
              type={activeTab}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              itemsPerPage={itemsPerPage} // Pass the type to identify the environment
            />
          </div>
          <div
            className={`tab-pane fade ${
              activeTab === "production" ? "show active" : ""
            }`}
            id="kt_tab_pane_5"
            role="tabpanel"
          >
            <ProductionEnvironment
              type={activeTab}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              itemsPerPage={itemsPerPage} // Pass the type to identify the environment
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FirmwareLayout;
