import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { decryptData, SwalResponse } from "../../../../../_metronic/helpers";
import { SUCCESS } from "../../../../../util/messages";
import { AppDispatch } from "../../../../../store/store";
import { useDispatch } from "react-redux";
import {
  firmwareUpdateStatus,
  viewFirmwareByID,
} from "../../../../../store/HP/FirmWare/firmWareSlice";
import { UsersListLoading } from "../../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";

const FirmWareChangeStatus = () => {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();

  const { search, state } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterAppId = decryptData(searchParams.get("id"));
  let filterFirmwareId = decryptData(searchParams.get("firmware_id"));

  const firmware_app_id = filterAppId;
  const firmware_app_name = searchParams.get("name");
  const firmware_id = filterFirmwareId;

  const [loading, setLoading] = useState(false);
  const [loadingSubmit, setLoadingSubmit] = useState(false);
  const [validation, setValidation] = useState({
    update_status_error: "",
    comments_error: "",
    reasons_error: "",
  });

  const [formData, setFormData] = useState({
    app_name: "",
    app_id: "",
    firmware_status: "",
    firmware_version: "",
    comments: "",
    reasons: "",
  });

  useEffect(() => {
    if (Number(firmware_id)) {
      fetchFirmwareDetails();
    }
  }, [firmware_id]);

  const fetchFirmwareDetails = async () => {
    try {
      if (firmware_id) {
        setLoading(true);
        const query = `?app_id=${firmware_app_id}&firmware_id=${firmware_id}`;
        const { payload } = await dispatch(viewFirmwareByID(query));
        setFormData((prev: any) => ({
          ...prev,
          app_name: payload?.data?.app?.name,
          firmware_version: payload?.data?.version || "",
          firmware_status: payload?.data?.status || "",
          comments: payload?.data?.comment,
          reasons: payload?.data?.reason,
        }));
        setLoading(false);
      }
    } catch (err) {
      throw err;
    }
  };

  // Corrected the handleFirmwareStatusUpdate function
  const handleFirmwareStatusUpdate = async (e: any) => {
    e.preventDefault();
    let isValid = true;
    const errors: any = {};
    if (!formData?.firmware_status || formData?.firmware_status === "pending") {
      errors.update_status_error = "Please select the update status.";
      isValid = false;
    }
    // If "approved", validate comments
    if (formData?.firmware_status === "approved" && !formData?.comments) {
      errors.comments_error = "Comments are required when status is approved.";
      isValid = false;
    }
    // If "rejected", validate reasons
    if (formData?.firmware_status === "rejected" && !formData?.reasons) {
      errors.reasons_error = "Reasons are required when status is rejected.";
      isValid = false;
    }
    if (!isValid) {
      setValidation(errors);
      return;
    }
    try {
      setLoadingSubmit(true);
      const updateformData: any = {
        firmware_id: firmware_id,
        app_id: firmware_app_id,
        status: formData?.firmware_status,
      };
      if (formData?.firmware_status === "rejected") {
        updateformData.reason = formData?.reasons;
      }

      // Only include comments if the status is "approved"
      if (formData?.firmware_status === "approved") {
        updateformData.comment = formData?.comments;
      }

      console.log("Update formData:", updateformData);
      const { payload } = await dispatch(firmwareUpdateStatus(updateformData));
      if (payload?.status === 403) {
        await SwalResponse("danger", payload?.message, payload?.error_details);
      } else if (payload?.status === 200) {
        await SwalResponse(
          "success",
          payload?.message,
          SUCCESS.UPDATE_STATUS_FIRMWARE
        );
        navigate(
          `/firmware/HP?id=${searchParams.get("id")}&name=${searchParams.get(
            "name"
          )}`,
          {
            state: { activeTab1: "production" },
          }
        );
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      } else if (payload?.status === 500) {
        await SwalResponse("danger", payload?.message, payload?.error_details);
      }
      setLoadingSubmit(false);
    } catch (error) {
      console.error("Error updating firmware status:", error);
    }
  };

  return (
    <>
      <form onSubmit={handleFirmwareStatusUpdate}>
        <div className="card" id="kt_profile_details_view">
          <div className="card-body p-9">
            <div className="row">
              <div className="col-md-5">
                {loading && <UsersListLoading />}
                <div className="mb-5">
                  <label className="mb-2">App Name</label>
                  <input
                    type="text"
                    disabled
                    placeholder="Enter the app name"
                    maxLength={50}
                    value={formData?.app_name}
                    className="form-control"
                  />
                </div>
                <div className="mb-5">
                  <label className="mb-2">Firmware Version</label>
                  <input
                    type="text"
                    placeholder="Enter the firmware version"
                    maxLength={20}
                    value={formData?.firmware_version}
                    className="form-control"
                    disabled
                  />
                </div>
              </div>

              <div className="col-md-7">
                <div className="mb-5">
                  <label className="mb-5 required">Update Status</label>
                  <div>
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input"
                        type="radio"
                        onChange={(e) =>
                          setFormData((prev: any) => ({
                            ...prev,
                            firmware_status: "approved",
                          }))
                        }
                        name="inlineRadioOptions"
                        id="inlineRadio1"
                        value="option1"
                      />
                      <label className="form-check-label">
                        Approve for Production
                      </label>
                    </div>
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input"
                        type="radio"
                        value="rejected" // You can directly assign the value to "rejected" as this will be used for comparison
                        checked={formData?.firmware_status === "rejected"} // Ensures the radio button is selected based on the state
                        onChange={(e) => {
                          setFormData((prev) => ({
                            ...prev,
                            firmware_status: "rejected",
                          }));
                        }}
                        name="inlineRadioOptions"
                        id="inlineRadio2"
                      />

                      <label className="form-check-label">
                        Reject With Reasons
                      </label>
                    </div>
                  </div>
                  {validation.update_status_error && (
                    <div className="text-danger">
                      {validation.update_status_error}
                    </div>
                  )}
                </div>

                {/* Conditionally render the textareas */}
                {formData?.firmware_status === "approved" && (
                  <div className="mb-5">
                    <label className="mb-2">Comments</label>
                    <textarea
                      className="form-control"
                      value={formData?.comments}
                      maxLength={200}
                      onChange={(e) => {
                        setFormData((prev: any) => ({
                          ...prev,
                          comments: e.target.value,
                        }));
                        setValidation((prev: any) => ({
                          ...prev,
                          comments_error: "",
                        }));
                      }}
                      placeholder="Comments"
                    ></textarea>
                    {validation.comments_error && (
                      <div className="text-danger">
                        {validation.comments_error}
                      </div>
                    )}
                  </div>
                )}

                {formData?.firmware_status === "rejected" && (
                  <div className="mb-5">
                    <label className="mb-2">Reasons</label>
                    <textarea
                      className="form-control"
                      value={formData?.reasons}
                      maxLength={200}
                      onChange={(e) => {
                        setFormData((prev: any) => ({
                          ...prev,
                          reasons: e.target.value,
                        }));
                        setValidation((prev: any) => ({
                          ...prev,
                          reasons_error: "",
                        }));
                      }}
                      placeholder="Reasons for rejection"
                    ></textarea>
                    {validation.reasons_error && (
                      <div className="text-danger">
                        {validation.reasons_error}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="justify-content-end d-flex gap-3 mt-5">
              <button
                type="button"
                className="btn btn-light-dark"
                // to="/firmware/HP/HP"
                onClick={() => navigate(-1)}
                // state={{ firmware_app_id: Number(firmware_app_id) }}
              >
                Back
              </button>
              <button
                className="btn btn-primary d-flex align-items-center gap-2"
                type="submit"
                disabled={loadingSubmit}
              >
                {loadingSubmit ? (
                  <span
                    className="indicator-progress"
                    style={{ display: "block" }}
                  >
                    Please wait...{" "}
                    <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                  </span>
                ) : (
                  <span className="indicator-label">Update</span>
                )}
              </button>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};

export default FirmWareChangeStatus;
