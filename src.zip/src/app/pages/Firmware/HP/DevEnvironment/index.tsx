import { FC, useEffect, useState } from "react";
import { Tooltip } from "react-tooltip";
import { Link, useLocation, useNavigate } from "react-router-dom";
import FileUpload from "./uploadFile";
import { UploadDragDrop } from "../../../../modules/apps/HP/components/UploadDragDrop";
import { AppDispatch } from "../../../../../store/store";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import {
  listingFirmware,
  viewFirmwareByID,
} from "../../../../../store/HP/FirmWare/firmWareSlice";
import {
  capitalizeFirstLetter,
  decryptData,
  encryptData,
  SwalResponse,
} from "../../../../../_metronic/helpers";
import { ITEM_PER_PAGE } from "../../../../../util/constant";
import ReactPaginate from "react-paginate";
import { Profile, useAuth } from "../../../../modules/auth";
import { UsersListLoading } from "../../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";

interface firmware {
  firmware_app_id: number;
  firmware_app_name: string;
}

interface LocationState {
  activeTab1: string;
}

const DevEnvironment = (props: any) => {
  const { type, currentPage, setCurrentPage, itemsPerPage } = props || {};

  const { auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "Firmware Engineer";

  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  const get_permissions = fetchAuthDetails?.data;

  const { search, state } = useLocation();
  const locationState = state as LocationState;
  const searchParams = new URLSearchParams(search);

  let filterAppId = decryptData(searchParams.get("id"));

  const firmware_app_id = filterAppId;
  const firmware_app_name = searchParams.get("name");

  // const { firmware_app_id, firmware_app_name } = (state as firmware) || {};
  const [searchTerm, setSearch] = useState("");
  const dispatch = useDispatch<AppDispatch>();
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [firmware, setFirmWare] = useState<any>([]);
  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
    isActive5: true,
  });
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [itemOffset, setItemOffset] = useState(0);
  const [totalRec, setTotalRec] = useState(0);
  const [pageCount, setPageCount] = useState(0);
  const [currentItems, setCurrentItems] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (type == "development" || locationState?.activeTab1 == "development") {
      fetchFirmware();
    }
  }, [
    currentPage,
    itemsPerPage,
    sortKey?.key,
    sortKey?.order,
    firmware_app_id,
    type,
    locationState?.activeTab1,
  ]);

  async function fetchFirmware() {
    try {
      setLoading(true);
      let queryParams = "";
      if (sortKey?.key && sortKey?.order) {
        queryParams = `?app_id=${Number(
          firmware_app_id
        )}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
          sortKey?.key
        }&sortBy=${sortKey?.order}&type=${0}`;
      } else if (currentPage && itemsPerPage) {
        queryParams = `?app_id=${firmware_app_id}&page=${Number(
          currentPage
        )}&items_per_page=${Number(itemsPerPage)}&type=${0}`;
      } else {
        queryParams = ``;
      }
      const { payload } = await dispatch(listingFirmware(queryParams));
      if (payload.status === 200) {
        setFirmWare(payload?.data ? payload?.data : firmware);
        setTotalRec(payload?.count);
        setLoading(false);
      }
      setLoading(false);
    } catch (error) {
      throw error;
    }
  }

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "version") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "version") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "status") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "status") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    }

    //upload_date
    //uploaded_by
  };

  //PAGINATION START HERE FOR CATEGORIES SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(firmware?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, firmware]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % firmware?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };

  return (
    <>
      {(auth_permission || get_permissions?.firmware_create) && (
        <>
          <Link
            to={{
              pathname: `/firmware/addFirmware`,
              search: `?id=${searchParams.get("id")}&name=${firmware_app_name}`,
            }}
            //to={"/firmware/addFirmware"}
            className="btn btn-light-primary d-flex align-items-center gap-2 add-firmware"
          >
            <span className="svg-icon svg-icon-1 bi bi-plus-lg"></span>Add
            Firmware
          </Link>
        </>
      )}

      <div className="tablQe-responsive">
        <table className="table align-middle gs-0 gy-4">
          <thead>
            <tr className="fw-bold text-muted bg-light">
              <th className="ps-4 w-50px rounded-start">S.No.</th>
              <th>
                Firmware Version Number
                {active?.isActive1 ? (
                  <i
                    className="bi bi-arrow-up-short cursor-pointer"
                    onClick={() => onSortChange("version", "ASC")}
                  ></i>
                ) : (
                  <i
                    className="bi bi-arrow-down-short  cursor-pointer"
                    onClick={() => onSortChange("version", "DESC")}
                  ></i>
                )}
              </th>
              <th className="w-150px">
                Upload Date
                {/* {active?.isActive2 ? (
                  <i
                    className="bi bi-arrow-up-short cursor-pointer"
                    onClick={() => onSortChange("upload_date", "ASC")}
                  ></i>
                ) : (
                  <i
                    className="bi bi-arrow-down-short  cursor-pointer"
                    onClick={() => onSortChange("upload_date", "DESC")}
                  ></i>
                )} */}
              </th>
              <th>Type</th>
              <th>File Version</th>
              <th className="w-150px">
                Status
                {active?.isActive3 ? (
                  <i
                    className="bi bi-arrow-up-short cursor-pointer"
                    onClick={() => onSortChange("status", "ASC")}
                  ></i>
                ) : (
                  <i
                    className="bi bi-arrow-down-short  cursor-pointer"
                    onClick={() => onSortChange("status", "DESC")}
                  ></i>
                )}
              </th>
              <th className="w-150px">Uploaded By</th>
              <th className="w-350px">Comments</th>
              <th className="w-350px">Printer</th>
              <th className="w-350px">Reasons</th>
              <th className="w-150px text-end rounded-end pe-4 ">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <UsersListLoading />
            ) : (
              <>
                {firmware?.length > 0 ? (
                  firmware?.map((val: any, index: number) => (
                    <>
                      <tr key={index}>
                        <td className="ps-4 fw-semibold  fs-6">{index + 1}</td>
                        <td className=" fw-semibold  fs-6">
                          {val?.version || 'N/A'}
                        </td>
                        <td className=" fw-semibold  fs-6">
                          {moment(val?.create_ts).format("YYYY-MM-DD")}
                        </td>
                        <td>{capitalizeFirstLetter(val?.file_type)}</td>
                        <td>{val?.file_version || 0.0}</td>
                        <td>
                          <span
                            className={` ${
                              val?.status == "pending"
                                ? "badge badge-light-danger"
                                : val?.status == "rejected"
                                ? "badge badge-light-warning"
                                : "badge badge-light-success"
                            } `}
                          >
                            {capitalizeFirstLetter(val?.status)}{" "}
                          </span>
                        </td>
                        <td className=" fw-semibold  fs-6">
                          {val?.user?.full_name || "N/A"}
                        </td>
                        <td className="fw-semibold  fs-6">
                          {val?.comment || "N/A"}
                        </td>

                        <td className="fw-semibold  fs-6">
                          {val?.printer?.title || "N/A"}
                        </td>

                        <td className="fw-semibold  fs-6">
                          {val?.reason || "N/A"}
                        </td>
                        <td className="pe-4 text-end">
                          {(auth_permission ||
                            get_permissions?.firmware_read) && (
                            <>
                              <Link
                                //to="/firmware/HP/viewFirmware"

                                to={{
                                  pathname: `/firmware/viewFirmware`,
                                  search: `?id=${searchParams.get(
                                    "id"
                                  )}&name=${firmware_app_name}&firmware_id=${encryptData(
                                    val?.firmware_id
                                  )}`,
                                }}
                                onContextMenu={(e) => e.preventDefault()}
                                className="btn view btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-eye fs-3">
                                  {" "}
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                  <span className="path3"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".view" content="View" />
                            </>
                          )}
                          {(auth_permission ||
                            get_permissions?.firmware_write) && (
                            <>
                              <Link
                                //to="/firmware/HP/changeStatus"
                                to={{
                                  pathname: `/firmware/changeStatus`,
                                  search: `?id=${searchParams.get(
                                    "id"
                                  )}&name=${firmware_app_name}&firmware_id=${encryptData(
                                    val?.firmware_id
                                  )}`,
                                }}
                                className="changeStatus btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-toggle-on-circle fs-3">
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>

                              <Tooltip
                                anchorSelect=".changeStatus"
                                content="Change Status"
                              />
                            </>
                          )}
                        </td>
                      </tr>
                    </>
                  ))
                ) : (
                  <>
                    <tr></tr>
                    <tr>
                      <td colSpan={7}>
                        <div className="d-flex text-center w-100 align-content-center justify-content-center">
                          No matching records found
                        </div>
                      </td>
                    </tr>
                  </>
                )}
              </>
            )}
          </tbody>
        </table>
      </div>

      <div className="d-flex flex-stack flex-wrap pt-10">
        <div className="fs-6 text-gray-700">
          Showing {Number(currentPage) || 0} to {firmware?.length || 0} of{" "}
          {totalRec || 0} entries
        </div>
        {firmware?.length > 0 && (
          <ReactPaginate
            nextLabel="Next>"
            onPageChange={(event) => handlePageClick(event)}
            pageRangeDisplayed={3}
            marginPagesDisplayed={2}
            pageCount={pageCount}
            forcePage={currentPage - 1}
            previousLabel="< Previous"
            pageClassName="page-item"
            pageLinkClassName="page-link"
            previousClassName="page-item"
            previousLinkClassName="page-link"
            nextClassName="page-item"
            nextLinkClassName="page-link"
            breakLabel="..."
            breakClassName="page-item"
            breakLinkClassName="page-link"
            containerClassName="pagination"
            activeClassName="active"
            renderOnZeroPageCount={null}
          />
        )}
      </div>
    </>
  );
};

export { DevEnvironment };
