import Select from "react-select";
import FileUpload from "./uploadFile";
import usePageTitle from "../../../../modules/auth/components/PageTitle/usePageTitle";
import { useEffect, useState } from "react";
import { AppDispatch } from "../../../../../store/store";
import { useDispatch } from "react-redux";
import { fetchAllPrinters } from "../../../../../store/Printer/printerSlice";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Validation } from "../../core/_model";
import { firmwareCreate } from "../../../../../store/HP/FirmWare/firmWareSlice";
import { decryptData, SwalResponse } from "../../../../../_metronic/helpers";

const AddFirmWare = () => {
  usePageTitle("Add Firmware");
  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterAppId = decryptData(searchParams.get("id"));
  const firmware_app_id = filterAppId;

  const firmware_app_name = searchParams.get("name");

  const navigate = useNavigate();

  const [validation, setValidation] = useState(Validation);

  const [payload, setPayload] = useState<any>({
    app_id: firmware_app_id,
    printer_id: [{ label: "", value: 0 }],
    version: 0,
    file_version: 0,
    file_url: "",
    file_name: "",
    file_type: "",
    isForce: false,
    comment: "",
  });

  const [versionNumber, setVersionNumber] = useState<any>(0);
  const [printers, setPrintes] = useState<any>([]);
  const dispatch = useDispatch<AppDispatch>();
  const [isSelectedType, setIsSelectedType] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingSubmit, setLoadingSubmit] = useState(false);
  const [versions, setVersions] = useState<any>([]);

  useEffect(() => {
    getPrinters();
  }, []);

  async function getPrinters() {
    try {
      setLoading(true);
      let queryParams = `?app_id=${Number(firmware_app_id)}`;
      const { payload } = await dispatch(fetchAllPrinters(queryParams));
      if (payload?.status === 200) {
        const output =
          (await payload?.data) &&
          payload?.data?.map((val: any) => ({
            value: val?.printer_id,
            label: val?.title,
          }));
        setPrintes(output);

        //populate version in select dropdown
        let getVersions = payload?.data && payload?.data?.map((val: any) => val?.version);
        let filterVersions = getVersions?.flat();

        let fitlerVersions = filterVersions?.reduce((acc: any, obj: any) => {
          if (!acc?.some((o: any) => o === obj)) {
            acc?.push(obj);
          }
          return acc;
        }, []);
        setVersions(fitlerVersions);

        setLoading(false);
      }
    } catch (error) {
      throw error;
    }
  }

  const handleFileChange = (e: any) => {
    const file = e?.target?.files[0];
    const fileExtension = file?.name?.split(".")?.pop().toLowerCase();

    if (payload?.file_type === "tmd" && fileExtension !== "bin") {
      setValidation((prev: any) => ({
        ...prev,
        file_url: "Please upload a .bin file for TMD type.",
      }));
    } else if (
      payload?.file_type === "rbn" &&
      !["rbn", "brn"].includes(fileExtension)
    ) {
      setValidation((prev: any) => ({
        ...prev,
        file_url: "Please upload a .rbn or .brn file for RBN type.",
      }));
    } else if (payload?.file_type === "apk" && fileExtension !== "apk") {
      setValidation((prev: any) => ({
        ...prev,
        file_url: "Please upload a .apk file for APK type.",
      }));
    } else {
      setValidation((prev: any) => ({
        ...prev,
        file_url: "",
      }));
      setPayload((prev: any) => ({
        ...prev,
        file_url: file,
        file_name: file?.name,
      }));
    }
  };

  const handleAddFirmwareSubmit = async (e: any) => {
    try {
      e.preventDefault();
      setLoadingSubmit(true);

      let fileExt = payload?.file_url.name?.split(".")?.pop();

      // Use OR (||) to check for any validation errors

      if (payload?.printer_id[0]?.value == 0) {
        setValidation((prev: any) => ({
          ...prev,
          printer: "Please select the printer.",
        }));
      }
      if (Object.keys(payload?.file_url)?.length === 0) {
        setValidation((prev: any) => ({
          ...prev,
          file_url: "Please select file",
        }));
      }
      if (versionNumber == 0) {
        setValidation((prev: any) => ({
          ...prev,
          version: "Please select the version.",
        }));
      }

      if (payload?.file_version == 0) {
        setValidation((prev: any) => ({
          ...prev,
          file_version: "Please enter the file version.",
        }));
      }

      if (payload.file_type == "") {
        setValidation((prev: any) => ({
          ...prev,
          file_type: "Please select the file type.",
        }));
      }
      if (payload.comment == "") {
        setValidation((prev: any) => ({
          ...prev,
          comment: "Please enter the comment.",
        }));
      } else {
        // If no validation errors, proceed with form submission
        setValidation((prev: any) => ({
          ...prev,
          printer: "",
          version: "",
          file_url: "",
          file_name: "",
          file_type: "",
          isForce: "",
          comment: "",
        }));

        const formData = new FormData();
        formData.append("app_id", payload?.app_id);
        formData.append("file_url", payload?.file_url);
        formData.append("file_type", payload?.file_type);
        formData.append("printer_id", payload?.printer_id[0]?.value);
        formData.append("version", versionNumber);
        formData.append("comment", payload?.comment);
        formData.append("isForce", payload?.isForce);
        formData.append("file_version", payload?.file_version);



        const { payload: response } = await dispatch(firmwareCreate(formData));

        if (response?.status === 403) {
          await SwalResponse("warning", "Warning", response?.error_details);
          setLoadingSubmit(false);
        } else if (response?.status === 200) {
          await SwalResponse("success", "Added", response?.message);
          setLoadingSubmit(false);
          navigate(
            `/firmware/HP?id=${searchParams.get(
              "id"
            )}&name=${firmware_app_name}`,
            {
              state: { activeTab1: "development" },
            }
          );
          // navigate(-1);
        } else if (response?.status === 401) {
          await SwalResponse(
            "success",
            response?.message,
            response?.error_details
          );
        }
      }
      setLoadingSubmit(false);
    } catch (error) {
      throw error;
    }
  };

  const handleKeyNumberType = (event: any) => {
    const allowedKeys = [
      "Backspace",
      "Delete",
      "ArrowLeft",
      "ArrowRight",
      "Tab",
    ];
    const isNumberKey = !isNaN(Number(event.key)) && event.key !== " ";
    const isDotKey = event.key === ".";
    const hasDot = event.target.value.includes(".");

    const isAllowedKey =
      allowedKeys.includes(event.code) ||
      isNumberKey ||
      (event.ctrlKey && event.key === "a") ||
      (isDotKey && !hasDot);

    if (!isAllowedKey) {
      event.preventDefault();
    }
  };

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLElement>) => {
    const target = event?.target as HTMLInputElement | HTMLTextAreaElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  return (
    <form>
      <div className="card">
        <div className="card-body">
          <div className="row">
            <div className="col-md-6 mb-5">
              <label className="mb-2 form-label required">App</label>
              <input
                type="text"
                className="form-control"
                placeholder="App"
                value={firmware_app_name ? firmware_app_name : ""}
                readOnly
                disabled
              />
            </div>
            <div className="col-md-6 mb-5">
              <label className="mb-2 form-label required">Select Printer</label>
              <Select
                name="printer"
                className="react-select-styled"
                classNamePrefix="react-select"
                options={printers}
                placeholder="Select an Printer"
                value={
                  payload?.printer_id[0]?.value !== 0
                    ? payload?.printer_id
                    : null
                }
                onChange={(e) => {
                  setPayload((prev: any) => ({
                    ...prev,
                    printer_id: [{ label: e?.label, value: e?.value }],
                  }));
                  setValidation((prev: any) => ({ ...prev, printer: "" }));
                }}
                isLoading={loading}
              />
              <small className="text-danger">{validation?.printer}</small>
            </div>
            <div className="col-md-6 mb-5">
              <label className="mb-2 form-label required">Version Number</label>
              <select className="form-control" aria-placeholder="asfasf" onChange={(e) => {
                setVersionNumber(e.target.value);
                setValidation((prev: any) => ({
                  ...prev,
                  version: "",
                }));
              }
              }>
                <option value="" disabled selected>Select Version</option>
                {
                  versions && versions?.map((val: any) => (
                    <>
                      <option key={val} value={val} >{val}</option>
                    </>
                  ))
                }

              </select>


              {/* <Select
                name="printer"
             
                options={versions}
                placeholder="Select an Version"
              /> */}

              {/* <input
                // type="number"
                className="form-control"
                placeholder="Version Number"
                // value={payload?.version}
                onChange={(e: any) => {
                  setPayload((prev: any) => ({
                    ...prev,
                    version: e.target.value,
                  }));
                  setValidation((prev: any) => ({ ...prev, version: "" }));
                }}
                maxLength={6}
                onKeyDown={handleKeyNumberType}
              /> */}
              <small className="text-danger">{validation?.version}</small>
            </div>

            <div className="col-md-6 mb-5">
              <label className="mb-5 form-label required">File Version</label>
              <div className="d-flex gap-5">
                <input type="number" className="form-control" placeholder="Enter the file version"
                  onChange={(e) => {
                    setPayload((prev: any) => ({
                      ...prev,
                      file_version: e?.target?.value,
                    }));
                    setValidation((prev: any) => ({ ...prev, file_version: "" }));
                  }}
                />

              </div>
              <small className="text-danger">{validation?.file_version}</small>
            </div>

            <div className="col-md-6 mb-5">
              <label className="mb-5 form-label required">File Type</label>
              <div className="d-flex gap-5">
                {/* <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "tmd",
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    type="radio"
                    value=""
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">TMD</label>
                </div>

                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    type="radio"
                    value=""
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "firmware",
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">FIRMWARE</label>
                </div>

                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    type="radio"
                    value=""
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "apk",
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">APK</label>
                </div>
                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "cnx",
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    type="radio"
                    value=""
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">CNX</label>
                </div> */}
                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "tmd",
                        file_url: "", // Clear the file when switching to TMD
                        file_name: "", // Clear the file name
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                        file_url: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    type="radio"
                    value=""
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">TMD</label>
                </div>

                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    type="radio"
                    value=""
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "firmware",
                        file_url: "", // Clear the file when switching to Firmware
                        file_name: "", // Clear the file name
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">FIRMWARE</label>
                </div>

                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    type="radio"
                    value=""
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "apk",
                        file_url: "", // Clear the file when switching to APK
                        file_name: "", // Clear the file name
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">APK</label>
                </div>

                <div className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    onChange={(e) => {
                      setPayload((prev: any) => ({
                        ...prev,
                        file_type: "cnx",
                        file_url: "", // Clear the file when switching to CNX
                        file_name: "", // Clear the file name
                      }));
                      setValidation((prev: any) => ({
                        ...prev,
                        file_type: "",
                      }));
                      setIsSelectedType(true);
                    }}
                    type="radio"
                    value=""
                    name="one"
                    id="flexRadioDefault"
                  />
                  <label className="form-check-label">CNX</label>
                </div>
              </div>
              <small className="text-danger">{validation?.file_type}</small>
            </div>

            {isSelectedType && (
              <>
                <div className="col-md-6 mb-10">
                  <label className="form-label required">Upload File </label>
                  <div className="upload-draggable flex-row gap-3">
                    {payload.file_name
                      ? payload?.file_name
                      : `Select your file ${payload.file_type === "tmd"
                        ? ".bin"
                        : payload.file_type === "firmware" ||
                          payload.file_type === "cnx"
                          ? ".rbn,.brn" // Allow both .rbn and .brn for firmware and CNX
                          : ".apk"
                      }`}{" "}
                    <span className="text-blue-500">Browse</span>
                    <input
                      type="file"
                      accept={
                        payload.file_type === "tmd"
                          ? ".bin"
                          : payload.file_type === "firmware" ||
                            payload.file_type === "cnx"
                            ? ".rbn,.brn" // Allow both .rbn and .brn for firmware and CNX
                            : ".apk"
                      }
                      onChange={handleFileChange}
                    />
                  </div>

                  <small className="text-danger">{validation?.file_url}</small>
                </div>
              </>
            )}
            <div className="col-md-6 mb-10">
              <label className="mb-2 form-label required">Comment</label>
              <textarea
                placeholder="Comment"
                className="form-control"
                onKeyDown={handleKeyTextType}
                onChange={(e) => {
                  setPayload((prev: any) => ({
                    ...prev,
                    comment: e?.target?.value,
                  }));
                  setValidation((prev: any) => ({ ...prev, comment: "" }));
                }}
              >
              </textarea>
              <small className="text-danger">{validation?.comment}</small>
            </div>

            <div className="d-flex gap-3 justify-content-end flex-wrap">
              <div className="form-check form-check-custom form-check-solid w-100 justify-content-end mb-5">
                <input
                  className="form-check-input"
                  type="checkbox"
                  onChange={(e) =>
                    setPayload((prev: any) => ({
                      ...prev,
                      isForce: e.target.checked,
                    }))
                  }
                  checked={payload?.isForce}
                  value=""
                  id="flexCheckDefault"
                />
                <label className="form-check-label">Force Update</label>
              </div>
              <button
                type="button"
                className="btn btn-light-dark"
                onClick={() => navigate(-1)}
                disabled={loadingSubmit}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-light-primary"
                onClick={(e) => handleAddFirmwareSubmit(e)}
                disabled={loadingSubmit}
              >
                {loadingSubmit ? (
                  <span
                    className="indicator-progress"
                    style={{ display: "block" }}
                  >
                    Please wait...{" "}
                    <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                  </span>
                ) : (
                  <span className="indicator-label">Submit</span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default AddFirmWare;
