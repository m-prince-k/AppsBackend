
import { FC, useState } from 'react'
import { Tooltip } from 'react-tooltip';
import { Link, useLocation } from 'react-router-dom';
import { PageLink, PageTitle } from '../../../../../_metronic/layout/core'
import FirmWareChangeStatus from './FirmWareChangeStatus';

const usersBreadcrumbs: Array<PageLink> = [
    {
        title: 'Change Status',
        path: '/firmware/HP/HP/changeStatus',
        isSeparator: false,
        isActive: false,
    },
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]

const ChangeStatus: FC = () => {
    return (
        <>
            <PageTitle breadcrumbs={usersBreadcrumbs}>Change Status</PageTitle>
            <FirmWareChangeStatus />
        </>
    )
}

export { ChangeStatus }
