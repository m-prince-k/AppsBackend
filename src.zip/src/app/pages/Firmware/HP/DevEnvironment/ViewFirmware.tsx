import { Link, useLocation, useNavigate } from "react-router-dom";
import usePageTitle from "../../../../modules/auth/components/PageTitle/usePageTitle";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../../../../store/store";
import { useEffect, useState } from "react";
import { firmware } from "../../core/_model";
import { viewFirmwareByID } from "../../../../../store/HP/FirmWare/firmWareSlice";
import {
  capitalizeFirstLetter,
  decryptData,
  SwalResponse,
} from "../../../../../_metronic/helpers";
import { UsersListLoading } from "../../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";



const ViewFirmware = () => {
  usePageTitle("View Firmware");
  const { search,state } = useLocation();
 
  const searchParams = new URLSearchParams(search);
 

  let filterAppId=decryptData(searchParams.get("id"));
  let filter_firmware_id=decryptData(searchParams.get("firmware_id"));


  const firmware_app_id = filterAppId;
  const firmware_app_name = searchParams.get("name");
  const firmware_id = filter_firmware_id;

  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();

  const [viewFirmware, setViewFirmWare] = useState<any>("");
  
 

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchFirmWareById();
  }, [firmware_app_id]);

  async function fetchFirmWareById() {
    try {
      setIsLoading(true);
      let queryParams = `?app_id=${firmware_app_id}&firmware_id=${firmware_id}`;
      const { payload } = await dispatch(viewFirmwareByID(queryParams));
      setViewFirmWare(payload?.data);
      setIsLoading(false);
    } catch (error) {
      throw error;
    }
  }

  return (
    <>
      {isLoading && <UsersListLoading />}
      <div className="card">
        <div className="card-header  align-items-center">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">View Firmware</h3>
          </div>
          <button
            className="btn btn-bg"
            // to="#"
            onClick={() => navigate(-1)}
          >
            <i className="bi bi-arrow-left text-primary"></i> Back
          </button>
        </div>
        <div className="card-body p-9">
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">App Name</label>
            <div className="col-lg-8 fv-row">
              <span className="fw-bold fs-6">
                {viewFirmware?.app?.name || "N/A"}
              </span>
            </div>
          </div>
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">User Name</label>
            <div className="col-lg-8 fv-row">
              <span className="fw-bold fs-6">
                {capitalizeFirstLetter(viewFirmware?.user?.full_name) || "N/A"}
              </span>
            </div>
          </div>
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">File url</label>
            <div className="col-lg-8 fv-row">
              <Link
                to={`${viewFirmware?.file_url}`}
                target="_blank"
                className="fw-bold fs-6"
              >
                {viewFirmware?.file_url?.split("/").pop() || "N/A"}
              </Link>
            </div>
          </div>
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">File Type</label>
            <div className="col-lg-8 fv-row">
              <span className="fw-bold fs-6">
                {capitalizeFirstLetter(viewFirmware?.file_type) || "N/A"}
              </span>
            </div>
          </div>
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">Printer</label>
            <div className="col-lg-8 fv-row">
              <span className="fw-bold fs-6">
                {capitalizeFirstLetter(viewFirmware?.printer?.title) || "N/A"}
              </span>
            </div>
          </div>
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">IsForce</label>
            <div className="col-lg-8 fv-row">
              <span className="fw-bold fs-6">
                {viewFirmware?.isForce ? "True" : "False"}
              </span>
            </div>
          </div>
          <div className="row mb-7">
            <label className="col-lg-4 fw-bold text-muted">Status</label>
            <div className="col-lg-8">
              <span className="badge badge-success">
                {capitalizeFirstLetter(viewFirmware?.status) || "N/A"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default ViewFirmware;
