// src/FileUpload.js
import React, { useState, useCallback } from 'react';

const FileUpload = () => {
    const [files, setFiles] = useState([]);

    // const handleFiles = (newFiles: any) => {
    //     setFiles((prevFiles:any) => [...prevFiles, ...newFiles]);
    // };

    const onDrop = useCallback((e:any) => {
        e.preventDefault();
        const droppedFiles = Array.from(e.dataTransfer.files);
        // handleFiles(droppedFiles);
    }, []);

    const onDragOver = (e:any) => {
        e.preventDefault();
    };

    const onFileChange = (e:any) => {
        const selectedFiles = Array.from(e.target.files);
        // handleFiles(selectedFiles);
    };

    const handleRemove = (index:any) => {
        setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
    };

    return (
        <div>
            <label className='form-label required'>Upload File </label>
            <div
                onDrop={onDrop}
                onDragOver={onDragOver}
               className='upload-draggable flex-row gap-3'
            >
               Drop your file here, or <span className="text-blue-500"> Browse</span>
                <input type="file" multiple onChange={onFileChange} />
       
            </div>
            <ul>
                {files.map((file, index) => (
                    <li key={index}><button onClick={() => handleRemove(index)}>Remove</button></li>
                ))}
            </ul>
        </div>
    );
};

export default FileUpload;
