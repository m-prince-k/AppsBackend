
import { FC } from 'react'
import { Route, Routes, Outlet, Navigate } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../../_metronic/layout/core'
import { DevEnvironment } from './DevEnvironment'
import { ProductionEnvironment } from '../ProductionEnvironment'
import { ChangeStatus } from './DevEnvironment/ChangeStatus'
import FirmwareLayout from '../FirmwareLayout'
import AddFirmWare from './DevEnvironment/AddFirmware'
import ViewFirmware from './DevEnvironment/ViewFirmware'

const usersBreadcrumbs: Array<PageLink> = [
    {
        title: 'HP',
        path: '/firmware/HP/HP',
        isSeparator: false,
        isActive: false,
    },
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]
const FirmwareHP = () => {

    return (

        <Routes>
            <Route element={<Outlet />}>
                <Route
                    path='HP'
                    element={
                        <>
                            <PageTitle breadcrumbs={usersBreadcrumbs}>HP</PageTitle>
                            <FirmwareLayout />
                        </>
                    }
                />
                <Route
                    path='changeStatus'
                    element={
                        <>
                            <PageTitle>Change Status</PageTitle>
                            <ChangeStatus />
                        </>
                    }
                />

                <Route
                    path='addFirmware'
                    element={
                        <>
                            <PageTitle>Upload Firmware</PageTitle>
                            <AddFirmWare />
                        </>
                    }
                />


                <Route
                    path='viewFirmware'
                    element={
                        <>
                            <PageTitle>View Firmware</PageTitle>
                            <ViewFirmware />
                        </>
                    }
                />

            </Route>
            <Route index element={<Navigate to='/firmware/HP/HP' />} />
        </Routes>

    )
}

export { FirmwareHP }
