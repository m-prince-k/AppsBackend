import { FC, useEffect, useState } from "react";
import { Tooltip } from "react-tooltip";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  firmwareUpdateStatus,
  listingFirmware,
} from "../../../../store/HP/FirmWare/firmWareSlice";
import { AppDispatch } from "../../../../store/store";
import { useDispatch, useSelector } from "react-redux";
import { ITEM_PER_PAGE } from "../../../../util/constant";
import moment from "moment";
import {
  capitalizeFirstLetter,
  decryptData,
  SwalResponse,
} from "../../../../_metronic/helpers";
import ReactPaginate from "react-paginate";
import { Profile, useAuth } from "../../../modules/auth";
import { Button, Modal } from "react-bootstrap";
import { UsersListLoading } from "../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";
import usePageTitle from "../../../modules/auth/components/PageTitle/usePageTitle";

interface firmware {
  firmware_app_id: number;
  firmware_app_name: string;
}

const ProductionEnvironment = (props: any) => {
  const { search, state } = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(search);

  let filterAppId = decryptData(searchParams.get("id"));

  const firmware_app_id = filterAppId;
  const firmware_app_name = searchParams.get("name");

  usePageTitle(firmware_app_name);

  const { type, currentPage, setCurrentPage, itemsPerPage } = props || {};

  const { currentUser, auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "Firmware Engineer";
  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  const get_permissions = fetchAuthDetails?.data;

  const dispatch = useDispatch<AppDispatch>();
  const [firmware, setFirmWare] = useState<any>([]);

  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
    isActive5: true,
  });
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [itemOffset, setItemOffset] = useState(0);
  const [totalRec, setTotalRec] = useState(0);
  const [pageCount, setPageCount] = useState(0);
  const [currentItems, setCurrentItems] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [reason, setReason] = useState("");
  const [selectedFirmwareId, setSelectedFirmwareId] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingSubmit, setLoadingSubmit] = useState(false);

  useEffect(() => {
    if (type == "production") {
      fetchProductionFirmware();
    }
  }, [
    currentPage,
    itemsPerPage,
    sortKey?.key,
    sortKey?.order,
    type,
    firmware_app_id,
  ]);

  async function fetchProductionFirmware() {
    try {
      if (type == "production") {
        setLoading(true);
        let queryParams = "";
        if (sortKey?.key && sortKey?.order) {
          queryParams = `?app_id=${Number(
            firmware_app_id
          )}&page=${currentPage}&items_per_page=${itemsPerPage}&sortKey=${
            sortKey?.key
          }&sortBy=${sortKey?.order}&type=${1}`;
        } else if (currentPage && itemsPerPage) {
          queryParams = `?app_id=${firmware_app_id}&page=${Number(
            currentPage
          )}&items_per_page=${Number(itemsPerPage)}&type=${1}`;
        } else {
          queryParams = ``;
        }
        const { payload } = await dispatch(listingFirmware(queryParams));

        if (payload.status === 200) {
          setFirmWare(payload?.data ? payload?.data : firmware);
          setTotalRec(payload?.count);
        }
        setLoading(false);
      }
    } catch (error) {
      throw error;
    }
  }

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "version") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: false }));
    } else if (order == "DESC" && key == "version") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive1: true }));
    } else if (order == "ASC" && key == "status") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "DESC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: false }));
    } else if (order == "DESC" && key == "status") {
      setSortKey((prevState: any) => ({
        ...prevState,
        key: key,
        order: "ASC",
      }));
      setActive((prev: any) => ({ ...prev, isActive3: true }));
    }

    //upload_date
    //uploaded_by
  };

  //PAGINATION START HERE FOR CATEGORIES SECTION
  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    setCurrentItems(firmware?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, firmware]);

  const handlePageClick = (event: any) => {
    const nextPage = event.selected + 1;
    const newOffset = (nextPage * itemsPerPage) % firmware?.length;
    setItemOffset(newOffset);
    setCurrentPage(nextPage);
  };

  const openModal = (firmwareId: number) => {
    setSelectedFirmwareId(firmwareId);
    setShowModal(true);
    setReason("");
    setError("");
  };
  const handleClose = () => setShowModal(false);

  //ACTIVE UPDATE STATUS BASED ON FIRMARE ID
  const handleUpdateStatus = async (event: any) => {
    try {
      event?.preventDefault();
      setLoadingSubmit(true);
      if (reason == "") {
        setError("Please enter the reason.");
        setLoadingSubmit(false);
      } else {
        let _payload: object = {
          app_id: Number(firmware_app_id),
          firmware_id: Number(selectedFirmwareId),
          status: "rejected",
          reason: reason,
        };

        const { payload } = await dispatch(firmwareUpdateStatus(_payload));
        if (payload?.status === 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status === 200) {
          await SwalResponse("success", "Status Updated", payload?.message);
          fetchProductionFirmware();
          navigate(
            `/firmware/HP?id=${searchParams.get(
              "id"
            )}&name=${firmware_app_name}`,
            {
              state: { activeTab1: "development" },
            }
          );
        }
        setReason("");
        setError("");
        setShowModal(false);
        setLoadingSubmit(false);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <>
      <div className="tablQe-responsive">
        <table className="table align-middle gs-0 gy-4">
          <thead>
            <tr className="fw-bold text-muted bg-light">
              <th className="ps-4 w-50px rounded-start">S.No.</th>
              <th>
                Firmware Version Number
                {active?.isActive1 ? (
                  <i
                    className="bi bi-arrow-up-short cursor-pointer"
                    onClick={() => onSortChange("version", "ASC")}
                  ></i>
                ) : (
                  <i
                    className="bi bi-arrow-down-short  cursor-pointer"
                    onClick={() => onSortChange("version", "DESC")}
                  ></i>
                )}
              </th>
              <th className="w-150px">Upload Date</th>
              <th className="w-150px">Approved By</th>
              <th className="w-150px">
                Status
                {active?.isActive3 ? (
                  <i
                    className="bi bi-arrow-up-short cursor-pointer"
                    onClick={() => onSortChange("status", "ASC")}
                  ></i>
                ) : (
                  <i
                    className="bi bi-arrow-down-short  cursor-pointer"
                    onClick={() => onSortChange("status", "DESC")}
                  ></i>
                )}
              </th>
              <th className="w-350px">Comments</th>
              <th className="w-150px text-end rounded-end pe-4 ">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <UsersListLoading />
            ) : (
              <>
                {firmware?.length > 0 ? (
                  firmware?.map((val: any, index: number) => (
                    <>
                      <tr key={index}>
                        <td className="ps-4 fw-semibold  fs-6">{index + 1}</td>
                        <td className=" fw-semibold  fs-6">
                          Version {val?.version}
                        </td>
                        <td className=" fw-semibold  fs-6">
                          {moment(val?.create_ts).format("YYYY-MM-DD")}
                        </td>
                        <td className=" fw-semibold  fs-6">
                          {capitalizeFirstLetter(val?.user?.full_name) || "N/A"}
                        </td>
                        <td>
                          <span className="badge badge-light-success">
                            {capitalizeFirstLetter(val?.status)}{" "}
                          </span>
                        </td>
                        <td className=" fw-semibold  fs-6">
                          {capitalizeFirstLetter(val?.comment) || "N/A"}
                        </td>

                        <td className="pe-4 text-end">
                          {/* <Link
                        to="#"
                        className="btn download btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                      >
                        <i className="ki-duotone ki-cloud-download fs-3">
                          <span className="path1"></span>
                          <span className="path2"></span>
                        </i>
                      </Link>
                      <Tooltip anchorSelect=".download" content="Download" /> */}
                          {(auth_permission ||
                            get_permissions?.firmware_write) && (
                            <>
                              <Link
                                to={{
                                  pathname: `/firmware/HP`,
                                  search: `?id=${searchParams.get(
                                    "id"
                                  )}&name=${firmware_app_name}`,
                                }}
                                //to="#"
                                className="rejectBuild btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                onClick={() => openModal(val?.firmware_id)}
                              >
                                <i className="ki-duotone ki-cross fs-3">
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>

                              <Tooltip
                                anchorSelect=".rejectBuild"
                                content="Reject Reason"
                              />
                            </>
                          )}
                        </td>
                      </tr>
                    </>
                  ))
                ) : (
                  <>
                    <tr></tr>
                    <tr>
                      <td colSpan={7}>
                        <div className="d-flex text-center w-100 align-content-center justify-content-center">
                          No matching records found
                        </div>
                      </td>
                    </tr>
                  </>
                )}
              </>
            )}
          </tbody>
        </table>
      </div>
      <div className="d-flex flex-stack flex-wrap pt-10">
        <div className="fs-6 text-gray-700">
          Showing {Number(currentPage) || 0} to {firmware?.length || 0} of{" "}
          {totalRec || 0} entries
        </div>
        {firmware?.length > 0 && (
          <ReactPaginate
            nextLabel="Next>"
            onPageChange={(event) => handlePageClick(event)}
            pageRangeDisplayed={3}
            marginPagesDisplayed={2}
            pageCount={pageCount}
            previousLabel="< Previous"
            pageClassName="page-item"
            pageLinkClassName="page-link"
            previousClassName="page-item"
            previousLinkClassName="page-link"
            nextClassName="page-item"
            nextLinkClassName="page-link"
            breakLabel="..."
            breakClassName="page-item"
            breakLinkClassName="page-link"
            containerClassName="pagination"
            activeClassName="active"
            renderOnZeroPageCount={null}
          />
        )}
      </div>

      {showModal && (
        <Modal show={showModal} onHide={handleClose} centered>
          <Modal.Header closeButton>
            <Modal.Title>Reject Reason</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="modal-body">
              <textarea
                className="form-control"
                placeholder="Please provide a reason for rejecting this build."
                value={reason}
                onKeyUp={() => {
                  if (reason != "") {
                    setError("");
                  } else {
                    setError("Please enter the reason.");
                  }
                }}
                onChange={(e) => setReason(e.target.value)}
                rows={4}
              />

              {error && <div className="text-danger mt-2">{error}</div>}
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              className="btn btn-bg-light btn-active-color-dark"
              onClick={handleClose}
            >
              Close
            </button>
            <button
              className="btn btn-primary d-flex align-items-center gap-2"
              onClick={(event) => handleUpdateStatus(event)}
              disabled={loadingSubmit}
            >
              {loadingSubmit ? (
                <span
                  className="indicator-progress"
                  style={{ display: "block" }}
                >
                  Please wait...{" "}
                  <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                </span>
              ) : (
                <span className="indicator-label">Update</span>
              )}
            </button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
};

export { ProductionEnvironment };
