import axios from "axios";

const API_URL = import.meta.env.VITE_APP_THEME_API_URL;



const generateFrames = async (formData?: FormData) => {
    try {
      const response = await axios.post("http://192.168.29.112:3000/", formData);
      return response.data;
    } catch (error) {
      throw error;
    }
  };


  export {generateFrames};