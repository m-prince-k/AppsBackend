import { Route, Routes, Outlet, Navigate } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import { toAbsoluteUrl } from '../../../_metronic/helpers';

const usersBreadcrumbs: Array<PageLink> = [
    {
        title: 'Frame Collection',
        path: '/Frames/FrameCollection/Frame-Collection',
        isSeparator: false,
        isActive: false,
    },
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]
const FrameCollection = () => {
    return (
        <Routes>
            <Route element={<Outlet />}>
                <Route
                    path='FrameCollection'
                    element={
                        <>
                            <PageTitle breadcrumbs={usersBreadcrumbs}>Frame Collection</PageTitle>
                            <div className='card'>
                                    <div  className='card-header'>
                                        <h4 className='card-title'>Happy Father Day Frames</h4>
                                        
                                    </div>
                                <div className='card-body'>
                                    <div className='row row-gap-5'>
                                        <div className='col-md-4'>
                                            <div className='frame-wrap'>
                                                   <div className='inner-frame'></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    }
                />
            </Route>
            <Route index element={<Navigate to='/Frames/FrameCollection/Frame-Collection' />} />
        </Routes>
    )
}

export default FrameCollection
