import { Route, Routes, Outlet, Navigate, useLocation, Link, useNavigate } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../_metronic/layout/core'
import { toAbsoluteUrl } from '../../../_metronic/helpers';

interface frames {
    payload: []
}
const FramesListing = (props: any) => {
    const location = useLocation();
    const navigate=useNavigate();
    const { payload } = location?.state as frames || {};

    return (
        <>
            <div className='card'>
                 
                <div className='card-header align-items-center'>
                    <h4 className='card-title'>Happy Father Day Frames</h4>
                    <Link to="#" onClick={() => navigate(-1)} className='btn btn-success '>Back</Link>
                </div>
                <div className='card-body'>
                    <div className='horizontal-scroll'>
                        <div className='row row-gap-5'>
                            {
                                payload && payload.map((val: any) => (
                                    <>
                                        <div className='col-auto'>
                                            <div className={`frame-wrap ${val?.class}`} style={{ background: `url(${val?.frame})`, width: `${val?.width}px`, height: 600 }}>
                                                <div className="stickers-wrap">
                                                    {

                                                        <img src={val?.element1} className="icon01 postionAbs" height={100} width={100} style={{ top: `${Number(val?.pos1)}%`, left: `${Number(val?.pos2)}%` }} />
                                                    }
                                                    {
                                                        <img src={val?.element2} className="icon02 postionAbs" height={100} width={100} style={{ top: `${Number(val?.pos3)}%`, left: `${Number(val?.pos4)}%` }} />
                                                    }
                                                    {
                                                        <img src={val?.element3} className="icon03 postionAbs" height={100} width={100} style={{ top: `${Number(val?.pos5)}%`, left: `${Number(val?.pos6)}%` }} />
                                                    }

                                                    {
                                                        <img src={val?.element4} className="icon04 postionAbs" height={100} width={100} style={{ top: `${Number(val?.pos7)}%`, left: `${Number(val?.pos8)}%` }} />
                                                    }

                                                    {/* <img src={dimenstion.image} alt="" /> */}
                                                </div>
                                                <div className='inner-frame'></div>
                                            </div>
                                        </div>
                                    </>
                                ))
                            }

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default FramesListing;
