import { useEffect, useState } from "react";
import styled from 'styled-components';
 
import Resizer from "react-image-file-resizer";
import dummyFrames from "./icon/dummyFrames.png"
import { resizeFileSizes } from "../../../_metronic/helpers";
import { generateFrames } from "./core/_request";
 
import bgframe01 from "../Frames/bg-frame01.png";
import FramesListing from "./FramesListing";
import { Link } from "react-router-dom";
 
 
 
const FrameGenerate = () => {
 
  const [ratio, setRatio] = useState([
    { width: 150, status: false },
    { width: 300, status: false },
    { width: 600, status: false },
    { width: 900, status: false },
    { width: 1200, status: false },
    { width: 1500, status: false },
    { width: 1800, status: false },
    { width: 2100, status: false },
    { width: 2400, status: false },
    { width: 2700, status: false }
  ])
 
 
  const [dimenstion, setDimentsions] = useState<any>({
    otherFrameStatus: false,
    frameImage: "",
    height: 600,
    width: 0,
    image: '',
    error1: '',
    error2: '',
    positionError: '',
    icon1: '',
    iconfile1: '',
    icon2: '',
    iconfile2: '',
    icon3: '',
    iconfile3: '',
    icon4: '',
    iconfile4: '',
    pos1: -4,
    pos2: 30,
    pos3: 40,
    pos4: -8,
    pos5: 40,
    pos6: 74,
    pos7: 88,
    pos8: 34,
  });
  const [globalFrameImage, setGlobalFrameImage] = useState([]);
  const [globalFrameName, setGlobalFrameName] = useState("");
  const [payload, setPayload] = useState<any>([]);
  const [generateFrame, setGenerateFrame] = useState<any>([]);
 
  const [dynamicFrameClass, setDynamicFrameClass] = useState<any>(0);

  const [latestFrame, setFrame] = useState<any>({ frameImg: "", width: 0, height: 600, fixed_checked: false, edit_checked: true,
    pos1:0,pos2:0,pos3:0,pos4:0,pos5:0,pos6:0,pos7:0,pos8:0,
    elementWidth1:0,elementWidth2:0,elementWidth3:0,elementWidth4:0
   });
  const [checkDisabled, setCheckDisabled] = useState(true);

  const [positionElement1, setPositionElement1] = useState([]);
  const [positionElement2, setPositionElement2] = useState([]);
  const [positionElement3, setPositionElement3] = useState([]);
  const [positionElement4, setPositionElement4] = useState([]);
 
  const [collectFile, setCollectFile] = useState([]);
 
 
  const [frames, setFrames] = useState([]);
 
  const fileChangedHandler = (event: any) => {
 
    setGlobalFrameImage([...globalFrameImage, event.target.files[0]]);
 
 
    // let frame = {
    //   frameFile: event.target.files[0]
    // }
    // let newData = [...payload].concat(frame);
    // setPayload(newData);
 
    var fileInput = false;
    if (event.target.files[0]) {
      fileInput = true;
    }
    if (fileInput) {
      try {
        Resizer.imageFileResizer(event.target.files[0], dimenstion.width, 600, "JPEG,PNG", 100, 0, (uri) => {
          setDimentsions((prev: any) => ({ ...prev, image: uri }));
        },
          "base64",
          dimenstion?.width, dimenstion?.height
        );
      } catch (err) {
        console.log(err);
      }
    }
 
  }
 
  const handleImageChange = (e: any, type: string) => {
    try {
 
      if (type === "first") {
 
        e.preventDefault();
        setPositionElement1([...positionElement1, e.target.files[0]])
        // let elementFirst = {
        //   element1: e.target.files[0]
        // }
        // let newData = [...payload].concat(elementFirst);
        // setPayload(newData);
 
 
        let reader = new FileReader();
        let file = e.target.files[0];
 
        reader.onloadend = () => {
          setDimentsions((prev: any) => ({ ...prev, iconfile1: file, icon1: reader.result }));
        }
        reader.readAsDataURL(file);
      } else if (type === "second") {
        e.preventDefault();
 
        setPositionElement2([...positionElement2, e.target.files[0]])
        // let elementSecond = {
        //   element2: e.target.files[0]
        // }
        // let newData = [...payload].concat(elementSecond);
        // setPayload(newData);
 
        let reader = new FileReader();
        let file = e.target.files[0];
 
        reader.onloadend = () => {
          setDimentsions((prev: any) => ({ ...prev, iconfile2: file, icon2: reader.result }));
        }
        reader.readAsDataURL(file);
      } else if (type === "third") {
        e.preventDefault();
 
        setPositionElement3([...positionElement3, e.target.files[0]])
 
        let reader = new FileReader();
        let file = e.target.files[0];
 
        reader.onloadend = () => {
          setDimentsions((prev: any) => ({ ...prev, iconfile3: file, icon3: reader.result }));
        }
        reader.readAsDataURL(file);
      } else if (type === "four") {
        e.preventDefault();
        setPositionElement4([...positionElement4, e.target.files[0]])
        // let elementFourth = {
        //   element4: e.target.files[0].name
        // }
        // let newData = [...payload].concat(elementFourth);
        // setPayload(newData);
 
 
        let reader = new FileReader();
        let file = e.target.files[0];
 
        reader.onloadend = () => {
          setDimentsions((prev: any) => ({ ...prev, iconfile4: file, icon4: reader.result }));
        }
        reader.readAsDataURL(file);
      }
    } catch (error) {
      throw error;
    }
  }
 
  //handle edit position is start here
  const handleEditPosition = async (e: any) => {
    e.preventDefault();

    setFrame((prev: any) => ({ ...prev, edit_checked: true }))
    setFrame((prev: any) => ({ ...prev, fixed_checked: false }))

    if (payload?.length > 0) {

      await payload.filter((item: any) => payload.lastIndexOf(item) == payload.indexOf(item)).map((val: any) => {
        setDimentsions((prev: any) => ({
          ...prev,
          pos1: val.pos1,
          pos2: val.pos2,
          pos3: val.pos3,
          pos4: val.pos4,
          pos5: val.pos5,
          pos6: val.pos6,
          pos7: val.pos7,
          pos8: val.pos8,
        })
        )
      })
    }
    setFrame((prev: any) => ({ ...prev, edit_checked: true }))
  }
 
 
 
  //fixed position start here
  const handleFixedPostion = (e: any) => {
    e.preventDefault();

    setFrame((prev: any) => ({ ...prev, fixed_checked: true }))

    setFrame((prev: any) => ({ ...prev, edit_checked: false }))


    //validation set here for position
    if (latestFrame?.width == 0) {
      setDimentsions((prev: any) => ({ ...prev, error1: "Please enter the width." }))
    } 
     else {
      setFrame((prev: any) => ({ ...prev, fixed_checked: true,
        pos1:dimenstion.pos1,
        pos2:dimenstion.pos2,
        pos3:dimenstion.pos3,
        pos4:dimenstion.pos4,
        pos5:dimenstion.pos5,
        pos6:dimenstion.pos6,
        pos7:dimenstion.pos7,
        pos8:dimenstion.pos8,
       }))

      setDimentsions((prev: any) => ({ ...prev, error1: "", error2: "" }))
      let myNewList = {
        pos1: Number(dimenstion?.pos1),
        pos2: Number(dimenstion?.pos2),
        pos3: Number(dimenstion?.pos3),
        pos4: Number(dimenstion?.pos4),
        pos5: Number(dimenstion?.pos5),
        pos6: Number(dimenstion?.pos6),
        pos7: Number(dimenstion?.pos7),
        pos8: Number(dimenstion?.pos8),
      }
      setFrame((prev: any) => ({ ...prev, edit_checked: false }))

      setDimentsions((prev: any) => ({ ...prev, pos1: 0, pos2: 0, pos3: 0, pos4: 0, pos5: 0, pos6: 0, pos7: 0, pos8: 0 }))
      //let newData = [...payload].concat(myNewList);
      // if (newData) {
      //   // const uniqueArray = newData.filter(function (item) {
      //   //   return newData.lastIndexOf(item) == newData.indexOf(item);
      //   // });
      //   //setPayload(uniqueArray);
      //   //if (uniqueArray?.length > 0) {
          
      //   //}
      // }
    }
  }


  const handleOtherFrames = (e: any, width: any, index: number) => {
    if (e.target.checked) {
 
      let myNewList = {
        // frameFileName: globalFrameImage,
        // frameName: globalFrameName,
        frame: latestFrame?.frameImg,
        width: width,
        class: `frame-${width}`,
        element1: dimenstion.icon1,
        element2: dimenstion.icon2,
        element3: dimenstion.icon3,
        element4: dimenstion.icon4,
        pos1: latestFrame?.pos1,
        pos2: latestFrame?.pos2,
        pos3: latestFrame?.pos3,
        pos4: latestFrame?.pos4,
        pos5: latestFrame?.pos5,
        pos6: latestFrame?.pos6,
        pos7: latestFrame?.pos7,
        pos8: latestFrame?.pos8,
        elementWidth1:latestFrame.elementWidth1,
        elementWidth2:latestFrame.elementWidth2,
        elementWidth3:latestFrame.elementWidth3,
        elementWidth4:latestFrame.elementWidth4
      }
      let newData = [...payload].concat(myNewList);
 
      var result = newData.reduce((unique, o) => {
        if (!unique.some((obj: any) => obj.width === o.width)) {
          unique.push(o);
        }
        return unique;
      }, []);
 
      setPayload(result);
      // setDimentsions((prev: any) => ({ ...prev, handleOtherFrames: e.target.checked }));
    } else if (e.target.checked == false) {
      //payload.filter((e:any) => e.width !== width);

      setPayload(payload.filter((l: any) => l.width !== width))
    }
  }
 
  const resizeFile = (file: any, width: number) =>
    new Promise((resolve) => {
 
      Resizer.imageFileResizer(
        file[0],
        width,
        600,
        "JPEG",
        100,
        0,
        (uri) => {
          setDimentsions((prev: any) => ({ ...prev, frameImage: uri }));
          //resolve(uri);
        },
        "base64"
      );
    });
 
 
  const handleFramesSubmit = async (e: any) => {
    try {
      e.preventDefault();
      if (dimenstion?.width == "") {
        setDimentsions((prev: any) => ({ ...prev, error1: "Please enter the width." }))
      } else {
 
        // let myNewList = {
        //   pos1: Number(dimenstion?.pos1),
        //   pos2: Number(dimenstion?.pos2),
        //   pos3: Number(dimenstion?.pos3),
        //   pos4: Number(dimenstion?.pos4),
        //   pos5: Number(dimenstion?.pos5),
        //   pos6: Number(dimenstion?.pos6),
        //   pos7: Number(dimenstion?.pos7),
        //   pos8: Number(dimenstion?.pos8),
 
        // }
        // let newData = [...payload].concat(myNewList);
        // setPayload(newData);
        // if (newData?.length > 0) {
        //   setDimentsions((prev: any) => ({ ...prev, pos1: 0, pos2: 0, pos3: 0, pos4: 0, pos5: 0, pos6: 0, pos7: 0, pos8: 0 }))
        // }
        if (payload?.length > 0) {
          setFrames(payload);
        }
 
        // const {data,message}=await generateFrames();
 
        let output = payload?.map(async (val: any) => {
 
          const image = await resizeFile(val?.frameFileName, val?.width);
 
          // let reader = new FileReader();
          // let file = val?.frameFileName;
 
          // reader.onloadend = () => {
          //   setDimentsions((prev: any) => ({ ...prev, image: file }));
          // }
 
          // reader.readAsDataURL(file);
 
          setCollectFile([...collectFile, val?.frameFileName])
        });
      }
    } catch (error) {
      throw error;
    }
  }
 
  const handleChangeFrame = (event: any) => {
    event.preventDefault();
 
    let reader = new FileReader();
    let file1 = event.target.files[0];
 
    reader.onloadend = () => {
      setFrame((prev: any) => ({ ...prev, frameImg: reader.result }));
    }
    reader.readAsDataURL(file1);
  }


  console.log(payload,"_________________________________________________________payload is here=>>>>>>>>>>>>>>>>>>>>>>>>>>")

  return (
    <>
      <form onSubmit={handleFramesSubmit}>
        <div className="row">
          <div>
            <div className="row">
              <div className="col-md-3 col-lg-2 mb-5">
                <input type="number" maxLength={3} className="form-control" value={latestFrame?.width} onChange={(e) => setFrame((prev: any) => ({ ...prev, width: e.target.value }))}
                  placeholder="Frame Width" />
                <small style={{ color: 'red' }}>{dimenstion?.error1}</small>
              </div>
              <div className="col-md-3 col-lg-2  mb-5">
                <input type="number" maxLength={3} readOnly className="form-control" value={dimenstion?.height}
                  onChange={
                    (e: any) =>
                      setDimentsions((prev: any) => ({ ...prev, height: e.target.value, error2: "" }),
                      )}
                  placeholder="Frame Height"
 
                />
                <small style={{ color: 'red' }}>{dimenstion.error2}</small>
              </div>
            </div>
 
            {
              dimenstion?.width > 0 &&
              <>
                Choose Frame <div className="col-md-12 mb-5">
                  <input className="form-control w-25" type="file" onChange={fileChangedHandler} /></div>
              </>
            }
 
          </div>
          <div>
 
 
 
 
            <img src={dimenstion?.frameImage} />
            {/* <ImageBorderFrame width="300px" height="200px" borderImage="./path-to-border-image.png"><p>Content inside the frame</p></ImageBorderFrame> */}
 
            {
              latestFrame.width != 0 &&
              <>
                <h1>Upload Frame</h1>
                <input type="file" className="form-control w-25 mb-10" onChange={handleChangeFrame} />
              </>
            }
 
            <div className="row">
 
              {
                latestFrame?.frameImg?.length > 0 &&
                <>
                  <div className="col-md-5">
                    <h6>Add Element</h6>
 
                    Element 1.
                    <div className="d-flex gap-3 align-items-center mb-5">
                      <input type="file" className="form-control" onChange={(e) => handleImageChange(e, "first")} />

                      <input type="number" max={2} className="w-80px form-control" placeholder="x" disabled={positionElement1?.length > 0 ? false : true} value={ positionElement1.length > 0 && dimenstion?.pos1} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos1: e.target.value }))} />
                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement1?.length > 0 ? false : true} value={ positionElement1.length > 0 && dimenstion?.pos2} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos2: e.target.value }))} />
                      
                      width <input type="number" className="w-80px form-control" placeholder="x" value={latestFrame?.elementWidth1} onChange={(e) => setFrame((prev:any) => ({...prev,elementWidth1:e.target.value}) ) } />

                    </div>
                    Element 2.
                    <div className="d-flex gap-3 align-items-center mb-5">
                      <input type="file" className="form-control" onChange={(e) => handleImageChange(e, "second")} />
                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement2?.length > 0 ? false : true} value={positionElement2.length > 0 && dimenstion?.pos3} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos3: e.target.value }))} />
                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement2?.length > 0 ? false : true} value={positionElement2.length > 0 && dimenstion?.pos4} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos4: e.target.value }))} />

                      width <input type="number" className="w-80px form-control" placeholder="x" value={latestFrame?.elementWidth2} onChange={(e) => setFrame((prev:any) => ({...prev,elementWidth2:e.target.value}) ) } />

                    </div>
                    Element 3.
                    <div className="d-flex gap-3 align-items-center mb-5">
                      <input type="file" className="form-control" onChange={(e) => handleImageChange(e, "third")} />

                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement3?.length > 0 ? false : true} value={positionElement3.length > 0 && dimenstion?.pos5} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos5: e.target.value }))} />
                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement3?.length > 0 ? false : true} value={positionElement3.length > 0 && dimenstion?.pos6} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos6: e.target.value }))} />
                    
                      width <input type="number" className="w-80px form-control" placeholder="x" value={latestFrame?.elementWidth3} onChange={(e) => setFrame((prev:any) => ({...prev,elementWidth3:e.target.value}) ) } />
                    
                    </div>
 
                    Element 4.
                    <div className="d-flex gap-3 align-items-center mb-5">
                      <input type="file" className="form-control " onChange={(e) => handleImageChange(e, "four")} />
                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement4?.length > 0 ? false : true} value={positionElement4.length > 0 && dimenstion?.pos7} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos7: e.target.value }))} />
                      <input type="number" className="w-80px form-control" placeholder="x" disabled={positionElement4?.length > 0 ? false : true} value={positionElement4.length > 0 && dimenstion?.pos8} onChange={(e) => setDimentsions((prev: any) => ({ ...prev, pos8: e.target.value }))} />
                    
                      width <input type="number" className="w-80px form-control" placeholder="x" value={latestFrame?.elementWidth4} onChange={(e) => setFrame((prev:any) => ({...prev,elementWidth4:e.target.value}) ) } />
                    </div>
                    {

                      <div className="text-end d-flex gap-3  mt-5 mb-5">
                        <button className="btn btn-light-secondary d-flex align-items-center" disabled={latestFrame?.edit_checked} onClick={handleEditPosition}>Edit Position</button>
                        <button className="btn btn-light-primary d-flex align-items-center" disabled={latestFrame?.fixed_checked} onClick={handleFixedPostion}>Fixed Position</button>
                      </div>
                    }

                  </div>
                </>
              }
 
 
              <div className="col-md-7">
                <div className="sticker-nav-wrap mb-5">
                    <div className="btn-group">
                      <button className="btn btn-sm">Top Left</button>
                      <button className="btn btn-sm">Top Center</button>
                      <button className="btn btn-sm">Top Right</button>
                      <button className="btn btn-sm">Bottom Left</button>
                      <button className="btn btn-sm ">Bottom  Center</button>
                      <button className="btn btn-sm">Bottom Right</button>
                      <button className="btn btn-sm">Center Left</button>
                      <button className="btn btn-sm">Center Right</button>
                      <button className="btn btn-sm">Align Center</button>
                    
                     
                    </div>
                </div>
                <div className={`frame-wrap frame-${latestFrame?.width}`} style={{ background: `url(${latestFrame?.frameImg})`, width: `${latestFrame?.width}px`, height: `${latestFrame?.height}px` }}>
 
 
                  <div className="stickers-wrap">
                    {
                      dimenstion?.icon1 &&
                      <img src={dimenstion?.icon1} className="icon01 postionAbs"  width={latestFrame?.elementWidth1 ? latestFrame?.elementWidth1 : ''} style={{ top: `${dimenstion?.pos1}%`, left: `${dimenstion?.pos2}%` }} />
                    }
                    {
                      dimenstion?.icon2 &&
                      <img src={dimenstion?.icon2} className="icon02 postionAbs"  width={latestFrame?.elementWidth2 ? latestFrame?.elementWidth2 : ''} style={{ top: `${dimenstion?.pos3}%`, left: `${dimenstion?.pos4}%` }} />
                    }
                    {
                      dimenstion?.icon3 &&
                      <img src={dimenstion?.icon3} className="icon03 postionAbs" width={latestFrame?.elementWidth3 ? latestFrame?.elementWidth3 : ''} style={{ top: `${dimenstion?.pos5}%`, left: `${dimenstion?.pos6}%` }} />
                    }
 
                    {
                      dimenstion?.icon4 &&
                      <img src={dimenstion?.icon4} className="icon04 postionAbs" width={latestFrame?.elementWidth4 ? latestFrame?.elementWidth4 : ''} style={{ top: `${dimenstion?.pos7}%`, left: `${dimenstion?.pos8}%` }} />
                    }
 
                    <img src={dimenstion.image} alt="" />
                  </div>
 
                  <div className="inner-frame"></div>
                </div>
              </div>
 
            </div>
            <hr />


            <h5 className="mb-5 mt-10">Other Frames</h5>
            <div className="row mb-10">
              {
                ratio && ratio?.map((val: any, index: number) => (
                  <>
                    <div className="col-md-3 align-items-center mb-3 d-flex">
                      <div className="w-150px">({val?.width} x 600)</div>
 
                      <div className="form-check form-check-custom">
                        <input className="form-check-input" type="checkbox"
 
                          value={dimenstion?.otherFrameStatus} onChange={(e) => handleOtherFrames(e, val?.width, index)} /></div>
                    </div>
                  </>
                ))
 
              }
            </div>
 
            {/* <div className="text-end d-flex gap-3 justify-content-end mt-10">
 
              <button className="btn  btn-light-success d-flex align-items-center">Generate Frames</button>
            </div> */}
          </div>
 
        </div>
      </form>
 
 
 
 
 
      <div className="mt-5 horizontal-scroll">
        {
          payload && payload.map((val: any) => (
            <>
 
              <div className={`frame-wrap ${val?.class}`} style={{ background: `url(${val?.frame})`, width: `${val?.width}px`, height: 600 }}>
 
                <div className="stickers-wrap">
                  {
                    val?.element1 &&
                    <img src={val?.element1} className="icon01 postionAbs"  width={val.elementWidth1 ? val.elementWidth1 : '' }  style={{ top: `${val?.pos1}%`, left: `${val?.pos2}%` }} />
                  }
                  {
                    val?.element2 &&
                    <img src={val?.element2} className="icon02 postionAbs" width={val.elementWidth2 ? val.elementWidth2 : '' } style={{ top: `${val?.pos3}%`, left: `${val?.pos4}%` }} />
                  }
                  {
                    val?.element3 &&
                    <img src={val?.element3} className="icon03 postionAbs"width={val.elementWidth3 ? val.elementWidth3 : '' }  style={{ top: `${val?.pos5}%`, left: `${val?.pos6}%` }} />
                  }
 
                  {
                    val?.element4 &&
                    <img src={val?.element4} className="icon04 postionAbs" width={val.elementWidth4 ? val.elementWidth4 : '' } style={{ top: `${val?.pos7}%`, left: `${val?.pos8}%` }} />
                  }

                  {/* <img src={dimenstion.image} alt="" /> */}
                </div>

                <div className="inner-frame"></div>
              </div>
            </>
          ))
        }

      </div>

      <Link to={"/apps/HP/frameListing"} state={{ payload: payload }} className="btn btn-light-success  mb-5 w-200px text-center">Generate Frames
      </Link>
    </>
  )
}

export { FrameGenerate }
 
 