import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { PageLink, PageTitle } from "../../../_metronic/layout/core";
import { useAuth } from "../../modules/auth";
import Users from "./users";
import ViewUser from "./component/ViewUser";

const usersBreadcrumbs: Array<PageLink> = [
    {
        title: "Manage Users",
        path: "/apps/manage-users/users",
        isSeparator: false,
        isActive: false,
    },
    {
        title: "",
        path: "",
        isSeparator: true,
        isActive: false,
    },
];


const ManageUsers = () => {

    const { currentUser, auth } = useAuth();

    // Check if the user has admin or app manager permissions
    const auth_permission =
        auth?.access_type?.access_type_name === "Admin" || auth?.access_type?.access_type_name === "App Manager";

    // If the user doesn't have the necessary permissions, redirect them to a 404 page
    if (!auth_permission) {
        return <Navigate to="/error/404" />;
    }

    return (
        <Routes>
            <Route element={<Outlet />}>
                <Route
                    path="users"
                    element={
                        <>
                            <PageTitle breadcrumbs={usersBreadcrumbs}>Manage Users</PageTitle>
                            <Users />
                        </>
                    }
                />

                <Route
                    path="viewUser"
                    element={
                        <>
                            <PageTitle breadcrumbs={usersBreadcrumbs}>Manage Users</PageTitle>
                            <ViewUser />
                        </>
                    }
                />


            </Route>
        </Routes>
    )
}
export default ManageUsers;