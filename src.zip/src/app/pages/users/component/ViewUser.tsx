import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";

import { useLocation } from "react-router-dom";
import { AppDispatch } from "../../../../store/store";
import { getUserById } from "../../../../store/User/userSlice";
import {
  capitalizeFirstLetter,
  decryptData,
  SwalResponse,
} from "../../../../_metronic/helpers";
import moment from "moment";
import usePageTitle from "../../../modules/auth/components/PageTitle/usePageTitle";
import { UsersListLoading } from "../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";

const ViewUser = () => {
  usePageTitle("View User");

  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterId = decryptData(searchParams.get("u_id"));

  const user_id = filterId;

  const dispatch = useDispatch<AppDispatch>();

  const [user, setUser] = useState<any>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user_id && searchParams.get("u_id")) {
      fetchUsrById();
    } else {
      SwalResponse("warning", "Warning", "User ID Required");
    }
  }, [user_id]);

  async function fetchUsrById() {
    try {
      setLoading(true);
      let queryParams = `?user_id=${user_id}`;
      const { payload } = await dispatch(getUserById(queryParams));
      if (payload?.status == 403) {
        await SwalResponse("danger", "warning", payload.error_details);
      } else if (payload?.status == 200) {
        setUser(payload?.data);
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      }
      setLoading(false);
    } catch (err) {
      throw err;
    }
  }

  return (
    <>
      <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div className="card-header">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">View User</h3>
          </div>
        </div>
        {loading ? (
          <UsersListLoading />
        ) : (
          <div className="card-body p-9">
            <div className="row mb-7">
              <label className="col-lg-3 fw-bold text-muted">Name:</label>
              <div className="col-lg-9">
                <span className="fw-bold fs-6">
                  {" "}
                  {capitalizeFirstLetter(user?.full_name) || "N/A"}
                </span>
              </div>
            </div>

            <div className="row mb-7">
              <label className="col-lg-3 fw-bold text-muted">Email:</label>
              <div className="col-lg-9">{user?.email}</div>
            </div>
            <div className="row mb-7">
              <label className="col-lg-3 fw-bold text-muted">
                Access Type:
              </label>
              <div className="col-lg-9">
                {user?.access_type?.access_type_name
                  ? user?.access_type?.access_type_name
                  : "N/A"}
              </div>
            </div>
            <div className="row mb-7">
              <label className="col-lg-3 fw-bold text-muted">Last Login:</label>
              <div className="col-lg-9">
                {user?.last_login_ts != null
                  ? moment
                      .utc(user?.last_login_ts)
                      .format("MM/DD/YYYY hh:mm:ss A")
                  : "N/A"}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
export default ViewUser;
