import { FC, useEffect, useState } from "react";

import { useFormik } from "formik";

import { initialUser, User } from "../core/_model";
import clsx from "clsx";
import Select from "react-select";
import { Button, Modal } from "react-bootstrap";

import { useAuth } from "../../../modules/auth";
import { listingRbac } from "../../../../store/HP/RBAC/rbacSlice";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../../../store/store";
import { SwalResponse, KTIcon } from "../../../../_metronic/helpers";
import { TITLE } from "../../../../util/messages";
import { editUserSchema } from "../validation/validation";
import { getAllUsers, UserCreate } from "../../../../store/User/userSlice";

type Props = {
  isUserLoading: boolean;
  user: User;
  handleRefresh: () => void;
  setUsers: any;
  setTotalRec: any;
};

const AddUser: FC<Props> = ({ user, isUserLoading, setUsers, setTotalRec }) => {
  const { auth } = useAuth();
  const dispatch = useDispatch<AppDispatch>();
  const get_permissions = localStorage.getItem("permissions");
  //@ts-ignore
  const parse_permission = JSON.parse(get_permissions);

  //@ts-ignore
  // const authType =
  //   parse_permission != null ? parse_permission : auth.roles_permission;
  // const authType = auth?.roles_permission;
  const superAdmin = auth?.access_type?.access_type_name === "Super Admin";

  // console.log(auth,"auth is here*****************************************8867890");

  // const loggedInUserName = auth?.given_name + "" + auth?.surname;

  const [roles, setRoles] = useState([]);

  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false), formik.resetForm();
  };
  const handleShow = () => setShow(true);
  const [error, setError] = useState("");
  const [accessType, setAccessType] = useState<any | undefined>([]);

  const [valueAccessType, setValueAccessType] = useState<any | undefined>({
    value: "Select Type",
    label: "Select Type",
  });

  const [radio, setRadio] = useState({
    access_type_id: 0,
    radio_slug: false,
  });

  const [ldapMsg, setLdapMsg] = useState<any>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // getAllRoles();
    callAccessType();
  }, []);

  async function callAccessType() {
    let { payload } = await dispatch(listingRbac(""));
    let filterRole = payload?.data?.reduce((acc: any, obj: any) => {
      if (
        !acc?.some((o: any) => o?.access_type_name === obj?.access_type_name)
      ) {
        acc?.push(obj);
      }
      return acc;
    }, []);

    const options2 = await filterRole?.map(
      (d: { access_type_id: number; access_type_name: string }) => ({
        value: d?.access_type_id,
        label: d?.access_type_name,
      })
    );
    setAccessType(options2);
  }

  const [userForEdit] = useState<User>({
    ...user,
    first_name: user?.first_name || initialUser.first_name,
    last_name: user?.last_name || initialUser.last_name,
    access_type: user?.access_type || initialUser.access_type,
    email: user?.email || initialUser.email,
  });

  const formik = useFormik({
    initialValues: userForEdit,
    validationSchema: editUserSchema,
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      let errorState = false;
      if (valueAccessType.value == "Access Type") {
        setError("Please select the access type");
        errorState = false;
      } else {
        setError("");
        errorState = true;
        setSubmitting(true);
        try {
          const val = valueAccessType?.value;

          let _payload = {
            first_name: values?.first_name,
            last_name: values?.last_name,
            email: values.email,
            access_type_id: val,
            // loggedIn_user_name: loggedInUserName,
          };

          let { payload } = await dispatch(UserCreate(_payload));
          if (payload?.status === 200) {
            resetForm();
            setShow(false);
            const query = `?active_inactive=${false}&page=${1}&items_per_page=${10}`;
            const { payload } = await dispatch(getAllUsers(query));
            setUsers(payload?.data);
            setTotalRec(payload?.count);
            await SwalResponse("success", "User Added", TITLE?.USER_CREATE);
          } else if (payload?.status === 401) {
            await SwalResponse(
              "success",
              payload?.message,
              payload?.error_details
            );
          } else if (payload?.status == 403) {
            await SwalResponse(
              "danger",
              payload?.message,
              payload?.error_details
            );
            // if (result?.status === 403) {
            //   return;
            // }
            // setShow(true);
          }
        } catch (ex) {
          await SwalResponse("danger", "Error", "Something went wrong");
        } finally {
          setSubmitting(false);
          // cancel(true);
        }
      }
    },
  });

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLElement>) => {
    const target = event.target as HTMLInputElement | HTMLTextAreaElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  return (
    <>
      <div>
        {/* {(authType?.users_create || superAdmin) && ( */}
        <div
          className="d-flex justify-content-end btn-outer"
          data-kt-user-table-toolbar="base"
        >
          <Button
            className="btn  btn-light-primary d-flex align-items-center gap-2"
            onClick={handleShow}
          >
            <KTIcon iconName="plus" className="fs-2" />
            Add User
          </Button>
        </div>
        {/* )} */}
      </div>
      <Modal show={show} onHide={handleClose} animation={false}>
        <Modal.Header closeButton>
          <Modal.Title>Add User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form
            id="kt_modal_add_user_form"
            className="form"
            onSubmit={formik.handleSubmit}
            noValidate
          >
            {/* begin::Scroll */}
            <div
              className="d-flex flex-column me-n7 pe-7"
              id="kt_modal_add_user_scroll"
              data-kt-scroll="true"
              data-kt-scroll-activate="{default: false, lg: true}"
              data-kt-scroll-max-height="auto"
              data-kt-scroll-dependencies="#kt_modal_add_user_header"
              data-kt-scroll-wrappers="#kt_modal_add_user_scroll"
              data-kt-scroll-offset="300px"
            >
              {/* begin::Input group */}
              <div className="fv-row mb-7">
                {/* begin::Label */}
                <label className="required fw-bold fs-6 mb-2">First Name</label>
                {/* end::Label */}

                {/* begin::Input */}
                <input
                  placeholder="First Name"
                  {...formik.getFieldProps("first_name")}
                  type="text"
                  onKeyDown={handleKeyTextType}
                  name="first_name"
                  className={clsx(
                    "form-control mb-3 mb-lg-0",
                    {
                      "is-invalid":
                        formik.touched.first_name && formik.errors.first_name,
                    },
                    {
                      "is-valid":
                        formik.touched.first_name && !formik.errors.first_name,
                    }
                  )}
                  autoComplete="off"
                  disabled={formik.isSubmitting || isUserLoading}
                />
                {formik.touched.first_name && formik.errors.first_name && (
                  <div className="fv-plugins-message-container">
                    <div className="fv-help-block">
                      <span role="alert">{formik.errors.first_name}</span>
                    </div>
                  </div>
                )}
                {/* end::Input */}
              </div>
              {/* end::Input group */}

              <div className="fv-row mb-7">
                {/* begin::Label */}
                <label className="required fw-bold fs-6 mb-2">Last Name</label>
                {/* end::Label */}

                {/* begin::Input */}
                <input
                  placeholder="last name"
                  {...formik.getFieldProps("last_name")}
                  type="text"
                  onKeyDown={handleKeyTextType}
                  name="last_name"
                  className={clsx(
                    "form-control mb-3 mb-lg-0",
                    {
                      "is-invalid":
                        formik.touched.last_name && formik.errors.last_name,
                    },
                    {
                      "is-valid":
                        formik.touched.last_name && !formik.errors.last_name,
                    }
                  )}
                  autoComplete="off"
                  disabled={formik.isSubmitting || isUserLoading}
                />
                {formik.touched.last_name && formik.errors.last_name && (
                  <div className="fv-plugins-message-container">
                    <div className="fv-help-block">
                      <span role="alert">{formik.errors.last_name}</span>
                    </div>
                  </div>
                )}
                {/* end::Input */}
              </div>

              {/* <div className="d-flex align-items-center">
              <label className="form-check form-check-custom form-check-inline form-check-solid me-5">

                <input className="form-check-input" name="account_disabled[]" onChange={(e) => setUserAccess(e.target.checked)} type="checkbox" value={userAccess} />
                <span className="fw-semibold ps-2 fs-6">{RESERVED_KEY.ACCOUNT_DISABLED} </span></label>
              <label className="form-check form-check-custom form-check-inline form-check-solid me-5">

                <input className="form-check-input" name="must_change_password[]" onChange={(e) => setMustPassword(e.target.checked)} type="checkbox" value={mustPassword} />
                <span className="fw-semibold ps-2 fs-6">{RESERVED_KEY.MUST_CHANGE_PASSWORD}</span>
              </label>
            </div> */}

              {/* begin::Input group */}

              {/* begin::Label */}
              {/* <label className="required fw-bold fs-6 mb-2">Login</label> */}
              {/* end::Label */}

              {/* begin::Input */}
              {/* <input
                  placeholder="Login"
                  {...formik.getFieldProps("login")}
                  type="text"
                  onKeyDown={handleKeyTextType}
                  name="login"
                  className={clsx(
                    "form-control mb-3 mb-lg-0",
                    {
                      "is-invalid": formik.touched.login && formik.errors.login,
                    },
                    {
                      "is-valid": formik.touched.login && !formik.errors.login,
                    }
                  )}
                  autoComplete="off"
                  disabled={formik.isSubmitting || isUserLoading}
                />
                {formik.touched.login && formik.errors.login && (
                  <div className="fv-plugins-message-container">
                    <div className="fv-help-block">
                      <span role="alert">{formik.errors.login}</span>
                    </div>
                  </div>
                )} */}

              {/* <div className="fv-row mb-7">
                <label className="form-check form-check-custom form-check-solid">
                  <input
                    className="form-check-input"
                    name="ldap[]"
                    onChange={(e) => setLdapMsg(e.target.checked)}
                    type="checkbox"
                    value={ldapMsg}
                  />
                  <span className="fw-semibold ps-2 fs-6">
                    {TITLE?.LDAP}
                  </span>
                </label>
              </div> */}

              {/* begin::Input group */}
              <div className="fv-row mb-7">
                {/* begin::Label */}
                <label className="required fw-bold fs-6 mb-2">Email</label>
                {/* end::Label */}

                {/* begin::Input */}
                <input
                  placeholder="Email"
                  {...formik.getFieldProps("email")}
                  className={clsx(
                    "form-control mb-3 mb-lg-0",
                    {
                      "is-invalid": formik.touched.email && formik.errors.email,
                    },
                    {
                      "is-valid": formik.touched.email && !formik.errors.email,
                    }
                  )}
                  type="text"
                  name="email"
                  onKeyDown={handleKeyTextType}
                  autoComplete="off"
                  //disabled={formik.isSubmitting || isUserLoading}
                />
                {formik.touched.email && formik.errors.email && (
                  <div className="fv-plugins-message-container">
                    <div className="fv-help-block">
                      <span role="alert">{formik.errors.email}</span>
                    </div>
                  </div>
                )}
              </div>
              {/* end::Input group */}

              <div className="fv-row mb-7">
                <label className="required fw-bold fs-6 mb-2">
                  Access Type
                </label>

                <Select
                  {...formik.getFieldProps("access_type")}
                  className="mb-2 select2-hidden-accessible sel-box"
                  placeholder="Public"
                  onChange={(e) => {
                    if (valueAccessType.value != "") {
                      setError("");
                    }
                    setValueAccessType({ value: e.value, label: e.label });
                  }}
                  value={valueAccessType}
                  options={accessType}
                />
                <span className="text-danger">{error}</span>
              </div>

              {/* <div className="fv-row mb-7"><label className="fw-bold fs-6 mb-2"> Role</label>
             
              {
                 roles && roles?.map((val:{access_type_id:number,access_type_name:string,checked:boolean},index:number) => (
                  <>
                  <div key={index}>
                      <input className="radio" type="radio" name="myRadios" value={val.access_type_id}  onChange={(e) => setRadio((prev:any) => ({...prev,access_type_id:e.target.value}) )} />{val.access_type_name}
                    </div>
                  </>
                ))
              }
              </div> */}
            </div>
            <div className="text-end">
              <button
                type="reset"
                onClick={handleClose}
                className="btn btn-light me-3"
                data-kt-users-modal-action="cancel"
                disabled={formik.isSubmitting || isUserLoading}
              >
                Cancel
              </button>

              <button
                type="submit"
                className="btn  btn-light-primary d-flex align-items-center gap-2 btn btn-primary"
                data-kt-users-modal-action="submit"
                disabled={
                  isUserLoading ||
                  formik.isSubmitting ||
                  !formik.isValid ||
                  !formik.touched
                }
              >
                <span className="indicator-label">
                  {formik.isSubmitting || isUserLoading ? (
                    <span>
                      Please wait...{" "}
                      <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                  ) : (
                    "Submit"
                  )}
                </span>
                {/* <span className="indicator-label">Submit</span>
                {(formik.isSubmitting || isUserLoading) && (
                  <span className="indicator-progress">
                    Please wait...{" "}
                    <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                  </span>
                )} */}
              </button>
            </div>
            {/* end::Actions */}
          </form>
        </Modal.Body>
      </Modal>
    </>
  );
};

export { AddUser };
