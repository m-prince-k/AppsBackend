import { FC, useEffect, useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import clsx from "clsx";
import Select from "react-select";
import { Modal } from "react-bootstrap";

import { User } from "../core/_model";

import { UsersListLoading } from "../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";
import { useAuth } from "../../../modules/auth";
import { editUserSchema } from "../validation/validation";
import { SwalResponse } from "../../../../_metronic/helpers";
import { AppDispatch } from "../../../../store/store";
import { useDispatch } from "react-redux";
import { listingRbac } from "../../../../store/HP/RBAC/rbacSlice";
import {
  getAllUsers,
  getUserById,
  UserCreate,
} from "../../../../store/User/userSlice";

type Props = {
  isUserLoading: boolean;
  user: User;
  userId?: any;
  isOpen: boolean;
  onClose: () => void;
  setUsers: any;
};

const EditUser: FC<Props> = ({
  user,
  isUserLoading,
  userId,
  onClose,
  isOpen,
  setUsers,
}) => {
  const { auth } = useAuth();
  const loggedInUserName = auth?.first_name + "" + auth?.last_name;
  const [error, setError] = useState("");
  const [accessType, setAccessType] = useState<any[]>([]);
  const dispatch = useDispatch<AppDispatch>();
  const [inputField, setInputFields] = useState<any>({
    given_name: "",
    surname: "",
    login: "",
    email: "",
    inactive_ind: false,
    // must_change_password_ind: false,
    ldap_ind: false,
    access_type: {
      value: "Access Type",
      label: "Access Type",
    },
  });
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    fetchData();
    callAccessType();
  }, []);

  const fetchData = async () => {
    try {
      const query = `?user_id=${userId}`;
      const { payload } = await dispatch(getUserById(query));

      if (payload.status == 403) {
        SwalResponse("danger", "warning", payload.error_details);
      } else if (payload?.status === 200) {
        setLoading(true);
        setInputFields((prev: any) => ({
          ...prev,
          first_name: payload?.data.first_name || "",
          last_name: payload?.data?.last_name || "",
          email: payload?.data.email || "",
          access_type: {
            label:
              payload?.data?.access_type?.access_type_name || "Access Type",
            value: payload?.data?.access_type?.access_type_id || "Access Type",
          },
        }));
        setLoading(true);
      }
    } catch (error) {
      throw error;
    }
  };

  async function callAccessType() {
    let { payload } = await dispatch(listingRbac(""));
    let filterRole = payload?.data?.reduce((acc: any, obj: any) => {
      if (
        !acc?.some((o: any) => o?.access_type_name === obj?.access_type_name)
      ) {
        acc?.push(obj);
      }
      return acc;
    }, []);

    const options2 = await filterRole?.map(
      (d: { access_type_id: number; access_type_name: string }) => ({
        value: d?.access_type_id,
        label: d?.access_type_name,
      })
    );
    setAccessType(options2);
  }

  const formik = useFormik({
    initialValues: {
      first_name: inputField?.first_name,
      last_name: inputField?.last_name,
      email: inputField?.email,
      access_type: inputField?.access_type?.label || "",
    },
    validationSchema: editUserSchema,
    enableReinitialize: true,
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      // if (!inputField?.access_type?.value) {
      //   setError("Please select the access type");
      //   return;
      // }
      // setError("");
      setSubmitting(true);
      try {
        const updateUser = {
          user_id: userId,
          first_name: values?.first_name && values?.first_name.trim(),
          last_name: values?.last_name && values?.last_name.trim(),
          email: values?.email?.toLowerCase(),
          access_type_id: inputField?.access_type?.value,
        };

        const { payload } = await dispatch(UserCreate(updateUser));
        if (payload?.status == 200) {
          const query = `?active_inactive=${false}`;
          const { payload: response } = await dispatch(getAllUsers(query));
          resetForm();
          await SwalResponse("success", "User Update", payload?.message);
          setUsers(response?.data);
          onClose();
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        } else if (payload?.status == 403) {
          await SwalResponse("danger", "warning", payload?.error_details);
        }
      } catch (error) {
        throw error;
      } finally {
        setSubmitting(false);
      }
    },
  });

  const handleSaveChanges = () => {
    formik.handleSubmit();
  };

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLElement>) => {
    const target = event.target as HTMLInputElement | HTMLTextAreaElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  return (
    <Modal
      show={isOpen}
      onHide={onClose}
      animation={false}
      className="edit-note-modal"
    >
      <Modal.Header closeButton>
        <Modal.Title>Edit User</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {!loading && userId && <UsersListLoading />}
        <form
          id="kt_modal_add_user_form"
          className="form"
          onSubmit={formik.handleSubmit}
          noValidate
        >
          <div
            className="d-flex flex-column scroll-y me-n7 pe-7"
            id="kt_modal_add_user_scroll"
            data-kt-scroll="true"
            data-kt-scroll-activate="{default: false, lg: true}"
            data-kt-scroll-max-height="auto"
            data-kt-scroll-dependencies="#kt_modal_add_user_header"
            data-kt-scroll-wrappers="#kt_modal_add_user_scroll"
            data-kt-scroll-offset="300px"
          ></div>

          <div className="fv-row mb-7">
            <label className="required fw-bold fs-6 mb-2">First Name</label>
            <input
              placeholder="First Name"
              //    {...formik.getFieldProps("first_name")}
              type="text"
              onKeyDown={handleKeyTextType}
              value={inputField.first_name}
              onChange={(e) => {
                setInputFields((prev: any) => ({
                  ...prev,
                  first_name: e.target.value,
                }));
              }}
              className={clsx("form-control mb-3 mb-lg-0", {
                "is-invalid":
                  formik.touched.first_name && formik.errors.first_name,
                "is-valid":
                  formik.touched.first_name && !formik.errors.first_name,
              })}
              autoComplete="off"
              disabled={formik.isSubmitting || isUserLoading}
            />

            {formik.touched.first_name && formik.errors.first_name && (
              <div className="fv-plugins-message-container">
                <div className="fv-help-block">
                  {typeof formik.errors.first_name === "string" ? (
                    <span role="alert">{formik.errors.first_name}</span>
                  ) : (
                    <span role="alert">Invalid error format</span>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="fv-row mb-7">
            <label className="required fw-bold fs-6 mb-2">Last Name</label>
            <input
              placeholder="Last Name"
              // {...formik.getFieldProps("surname")}
              value={inputField.last_name}
              onChange={(e) => {
                setInputFields((prev: any) => ({
                  ...prev,
                  last_name: e.target.value,
                }));
              }}
              type="text"
              onKeyDown={handleKeyTextType}
              className={clsx("form-control mb-3 mb-lg-0", {
                "is-invalid":
                  formik.touched.last_name && formik.errors.last_name,
                "is-valid":
                  formik.touched.last_name && !formik.errors.last_name,
              })}
              autoComplete="off"
              disabled={formik.isSubmitting || isUserLoading}
            />
            {formik?.touched?.last_name && formik?.errors?.last_name && (
              <div className="fv-plugins-message-container">
                <div className="fv-help-block">
                  {typeof formik.errors.last_name === "string" ? (
                    <span role="alert">{formik?.errors?.last_name}</span>
                  ) : (
                    <span role="alert">Invalid error format</span>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="fv-row mb-7">
            <label className="fw-bold fs-6 mb-2">Email</label>
            <input
              placeholder="Email"
              // {...formik.getFieldProps("email")}
              type="email"
              value={inputField.email}
              onChange={(e) => {
                setInputFields((prev: any) => ({
                  ...prev,
                  email: e.target?.value,
                }));
              }}
              className={clsx("form-control mb-3 mb-lg-0", {
                "is-invalid": formik.touched.email && formik.errors.email,
                "is-valid": formik.touched.email && !formik.errors.email,
              })}
              autoComplete="off"
            />
            {formik.touched.email && formik.errors.email && (
              <div className="fv-plugins-message-container">
                <div className="fv-help-block">
                  {typeof formik.errors.email === "string" ? (
                    <span role="alert">{formik.errors.email}</span>
                  ) : (
                    <span role="alert">Invalid error format</span>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="fv-row mb-7">
            <label className="required fw-bold fs-6 mb-2">Access Type</label>

            <Select
              className="mb-2 select2-hidden-accessible sel-box"
              placeholder="Select Access Type"
              onChange={(e) =>
                setInputFields((prev: any) => ({ ...prev, access_type: e }))
              }
              value={inputField.access_type}
              options={accessType}
            />
            <span className="text-danger">{error}</span>
          </div>
        </form>
        {(formik.isSubmitting || isUserLoading) && <UsersListLoading />}
      </Modal.Body>
      <Modal.Footer>
        <button
          type="reset"
          onClick={onClose}
          className="btn btn-light me-3"
          data-kt-users-modal-action="cancel"
          disabled={formik.isSubmitting || isUserLoading}
        >
          Discard
        </button>

        <button
          type="submit"
          className="btn  btn-light-primary d-flex align-items-center gap-2 btn btn-primary"
          data-kt-users-modal-action="submit"
          onClick={handleSaveChanges}
          disabled={
            isUserLoading ||
            formik.isSubmitting ||
            !formik.isValid ||
            !formik.touched
          }
        >
          <span className="indicator-label">
            {formik.isSubmitting || isUserLoading ? (
              <span>
                Please wait...{" "}
                <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
              </span>
            ) : (
              "Update"
            )}
          </span>
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export { EditUser };
