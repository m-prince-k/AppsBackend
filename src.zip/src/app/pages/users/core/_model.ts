

export type User = {
  id?: number,
  first_name?: string
  avatar?: string
  email?: string
  position?: string
  role?: string
  last_login?: string
  two_steps?: boolean
  joined_day?: string
  online?: boolean,
  login?:string,
  access_type?:number,
  inactive_ind?:boolean,
  must_change_password_ind?:boolean,
  ldap_ind?:boolean,
  surname?:string,
  last_name?:string,
  initials?: {
    label: string
    state: string
  }
}



export const initialUser: User = {
    avatar: 'avatars/300-6.jpg',
    position: 'Art Director',
    role: 'Administrator',
    first_name: '',
    email: '',
    login:'',
    access_type:0,
    inactive_ind:false,
    must_change_password_ind:false,
    ldap_ind:false,
    surname:'',
    last_name:''
  }