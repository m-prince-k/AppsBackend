
import * as Yup from "yup";

export const editUserSchema = Yup.object().shape({
    first_name: Yup.string()
      .max(50, "Maximum 50 symbols")
      .matches(/^[A-Za-z ]*$/, 'Please enter valid first name')
      .required("Name is required")
      .trim("Leading and trailing spaces are not allowed")
      .test("no-leading-space", "Leading spaces are not allowed", (value) => {
        return value === undefined || value === "" || !value.startsWith(" ");
      }),
    last_name: Yup.string()
      .max(50, "Maximum 50 symbols")
      .matches(/^[A-Za-z ]*$/, 'Please enter last valid name')
      .required("Surname is required")
      .trim("Leading and trailing spaces are not allowed")
      .test("no-leading-space", "Leading spaces are not allowed", (value) => {
        return value === undefined || value === "" || !value.startsWith(" ");
      }),
    // login: Yup.string()
    //   .min(2, "Minimum 2 character")
    //   .max(50, "Maximum 50 symbols")
    //   .required("Login is required")
    //   .trim("Leading and trailing spaces are not allowed")
    //   .test("no-leading-space", "Leading spaces are not allowed", (value) => {
    //     return value === undefined || value === "" || !value.startsWith(" ");
    //   }),
    email: Yup.string()
      .email("Please enter a valid email address")
      .max(50, "Email must be 50 characters or less")
      .required("Email is required")
      .trim("Leading and trailing spaces are not allowed")
      .test("no-leading-space", "Leading spaces are not allowed", (value) => {
        return value === undefined || value === "" || !value.startsWith(" ");
      })
      .test("proper-format", "Email must be in a proper format", (value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return value === undefined || value === "" || emailRegex.test(value);
      }),
  });