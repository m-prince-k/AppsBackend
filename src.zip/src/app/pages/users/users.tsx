import { Button, Modal } from "react-bootstrap";
import { Tooltip } from "react-tooltip";
import usePageTitle from "../../modules/auth/components/PageTitle/usePageTitle";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { TITLE } from "../../../util/messages";
import Select from "react-select";
import { AddUser } from "./component/AddUser";
import { useDispatch, useSelector } from "react-redux";
import ReactPaginate from "react-paginate";
import { AppDispatch } from "../../../store/store";
import { getAllUsers, UserStatusChange } from "../../../store/User/userSlice";
import {
  capitalizeFirstLetter,
  encryptData,
  SwalResponse,
  useDebounce,
} from "../../../_metronic/helpers";
import { ITEM_PER_PAGE } from "../../../util/constant";
import { UsersListLoading } from "../../modules/apps/user-management/users-list/components/loading/UsersListLoading";
import moment from "moment";
import { EditUser } from "./component/EditUser";
import { Profile, useAuth } from "../../modules/auth";
import { handleKeyTextType } from "../../modules/apps/HP/components/Category/_model";

const Users = () => {
  usePageTitle("Manage Users");

  const { auth } = useAuth();

  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "Super Admin";

  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);

  const get_permissions = fetchAuthDetails?.data;
  console.log(
    get_permissions,
    "______________________________this is the auth permissions",
    auth_permission
  );

  const [searchChar, setSearchChar] = useState<string>("");
  const debouncedSearchTerm = useDebounce(searchChar, 150);
  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch<AppDispatch>();
  const [showInactive, setShowInactive] = useState<boolean>(false);
  const [show, setShow] = useState(false);
  const [pageCount, setPageCount] = useState(0);
  const [sortKey, setSortKey] = useState({ key: "", order: "ASC" });
  const [accessType, setAccessType] = useState<any[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [modalEditOpen, setModalEditOpen] = useState(false);

  const [totalRec, setTotalRec] = useState<number>(0);
  const [userData, setUsers] = useState([]);
  const [isActive, setIsActive] = useState(true);
  const [isActive1, setIsActive1] = useState(true);
  const [isActive2, setIsActive2] = useState(true);

  const [itemOffset, setItemOffset] = useState(0);

  const itemsPerPage = ITEM_PER_PAGE || 10;

  const [active, setActive] = useState({
    isActive1: true,
    isActive2: true,
    isActive3: true,
    isActive4: true,
  });

  const [inputField, setInputFields] = useState<any>({
    given_name: "",
    surname: "",
    login: "",
    email: "",
    inactive_ind: false,
    ldap_ind: false,
    access_type: {
      value: "Access Type",
      label: "Access Type",
    },
  });

  useEffect(() => {
    if (debouncedSearchTerm !== undefined && searchChar !== undefined) {
      setSearchChar(debouncedSearchTerm);
    }
  }, [debouncedSearchTerm]);

  useEffect(() => {
    getUsers();
  }, [
    searchChar,
    showInactive,
    sortKey?.key,
    sortKey?.order,
    currentPage,
    itemsPerPage,
  ]);

  const getUsers = async () => {
    try {
      setLoading(true);
      let queryParams = "";
      if (searchChar) {
        queryParams = `?active_inactive=${showInactive}&searchTerm=${searchChar}`;
      } else if (sortKey?.key && sortKey?.order) {
        queryParams = `?active_inactive=${showInactive}&sortKey=${sortKey.key}&sortBy=${sortKey.order}&page=${currentPage}&items_per_page=${itemsPerPage}`;
      } else if (showInactive || showInactive === false) {
        queryParams = `?active_inactive=${showInactive}&page=${currentPage}&items_per_page=${itemsPerPage}`;
      } else if (currentPage && itemsPerPage) {
        queryParams = `?page=${currentPage}&items_per_page=${itemsPerPage}`;
      } else {
        queryParams = "";
      }
      const { payload } = await dispatch(getAllUsers(queryParams));
      if (payload?.status == 403) {
        await SwalResponse("danger", "warning", payload?.error_details);
      } else if (payload?.status == 200) {
        setLoading(false);
        setTotalRec(payload?.count);
        setUsers(payload?.data);
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      }
    } catch (error) {
      throw error;
    }
  };

  const onSortChange = (key: string, order: string) => {
    if (order == "ASC" && key == "full_name") {
      setSortKey((prevState) => ({ ...prevState, key: key, order: "DESC" }));
      setIsActive(!isActive);
      // setIsActive1(!isActive1)
    } else if (order == "DESC" && key == "full_name") {
      setSortKey((prevState) => ({ ...prevState, key: key, order: "ASC" }));
      setIsActive(!isActive);
      // setIsActive1(!isActive1)
    } else if (order == "ASC" && key == "login") {
      setSortKey((prevState) => ({ ...prevState, key: key, order: "DESC" }));
      setIsActive1(!isActive1);
    } else if (order == "DESC" && key == "login") {
      setSortKey((prevState) => ({ ...prevState, key: key, order: "ASC" }));
      setIsActive1(!isActive1);
    } else if (order == "ASC" && key == "last_login_ts") {
      setSortKey((prevState) => ({ ...prevState, key: key, order: "DESC" }));
      setIsActive2(!isActive2);
    } else if (order == "DESC" && key == "last_login_ts") {
      setSortKey((prevState) => ({ ...prevState, key: key, order: "ASC" }));
      setIsActive2(!isActive2);
    }

    //last_login_ts
  };

  const handleCheckboxChange = async (
    type: string,
    userId: number,
    boolValue: boolean
  ) => {
    try {
      let data = {
        user_id: userId,
      };
      if (type === "ldap_ind")
        // @ts-ignore
        data["ldap_ind"] = boolValue;
      else if (type === "inactive_ind")
        // @ts-ignore
        data["inactive_ind"] = boolValue;

      // @ts-ignore
      const { payload } = await dispatch(UserStatusChange(data));
      if (payload?.status == 403) {
        await SwalResponse("danger", payload?.message, payload?.error_details);
      } else if (payload?.status == 200) {
        await getUsers();
        await SwalResponse("success", "Status Updated", payload?.message);
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      }
    } catch (error) {
      console.error("Error updating status", error);
      throw error;
    }
  };

  useEffect(() => {
    const endOffset = itemOffset + itemsPerPage;
    // setCurrentItems(userData?.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(totalRec / itemsPerPage));
  }, [itemOffset, itemsPerPage, userData]);

  const handleEditClick = (userId: any) => {
    setSelectedUserId(userId);
    setModalEditOpen(true);
  };

  return (
    <>
      <div className="justify-content-end mb-10 d-flex gap-3">
        <div className="d-flex align-items-center position-relative me-auto">
          <i className="ki-duotone ki-magnifier fs-1 position-absolute ms-6">
            <span className="path1"></span>
            <span className="path2"></span>
          </i>
          <input
            type="text"
            data-kt-user-table-filter="search"
            className="form-control w-350px ps-14"
            placeholder="Search User"
            value={searchChar?.trim()}
            onChange={(e) => setSearchChar(e?.target?.value)}
            onKeyDown={handleKeyTextType}
          />

          <div className="d-flex align-items-center inactive-main">
            <div className="form-check form-check-solid form-switch form-check-custom fv-row ms-4">
              <input
                className="form-check-input w-45px h-30px"
                type="checkbox"
                id="allowmarketing"
                checked={showInactive}
                onChange={() => {
                  const newValue = !showInactive;
                  setShowInactive(newValue);
                }}
              />
              <label
                className="form-check-label"
                htmlFor="allowmarketing"
              ></label>
            </div>
            <p className="fw-semibold fs-6 mb-0">Show Inactive users</p>
          </div>
        </div>

        {get_permissions?.users_create && (
          <>
            <AddUser
              isUserLoading={false}
              user={{
                id: 0,
                first_name: "",
                last_name: "",
                avatar: "",
                email: "",
                position: "",
                role: "",
                last_login: "",
                two_steps: false,
                joined_day: "",
                online: false,
                login: "",
                access_type: 0,
                inactive_ind: false,
                must_change_password_ind: false,
                ldap_ind: false,
                initials: {
                  label: "",
                  state: "",
                },
              }}
              handleRefresh={async () => {
                await getUsers();
              }}
              setUsers={setUsers}
              setTotalRec={setTotalRec}
            />
          </>
        )}
      </div>

      <div className="table-responsive">
        <table className="table align-middle gs-0 gy-4">
          <thead>
            <tr className="fw-bold text-muted bg-light">
              <th className="ps-4 w-50px rounded-start">
                <div className="d-flex align-items-center">
                  Name{" "}
                  {isActive ? (
                    <i
                      onClick={() => onSortChange("full_name", "ASC")}
                      className="bi bi-arrow-up-short cursor-pointer"
                    ></i>
                  ) : (
                    <i
                      onClick={() => onSortChange("full_name", "DESC")}
                      className="bi bi-arrow-down-short  cursor-pointer"
                    ></i>
                  )}
                </div>
              </th>

              {/* <th role="columnheader" className="min-w-125px">
                                Login{" "}
                                {isActive1 ? (
                                    <i
                                        onClick={() => onSortChange("login", "ASC")}
                                        className="ki-duotone ki-down bs-text-muted fs-1x cursor-pointer"
                                    ></i>
                                ) : (
                                    <i
                                        onClick={() => onSortChange("login", "DESC")}
                                        className="ki-duotone ki-up bs-text-muted fs-1x cursor-pointer"
                                    ></i>
                                )}
                            </th> */}

              {/* <th role="columnheader" className="min-w-125px">
                                LDAP
                            </th> */}
              <th className="w-150px">InActive</th>
              <th className="w-150px">Access</th>

              <th className="w-150px">
                <div className="d-flex align-items-center">
                  Last Login
                  {isActive2 ? (
                    <i
                      onClick={() => onSortChange("last_login_ts", "ASC")}
                      className="ki-duotone ki-down bs-text-muted fs-1x cursor-pointer"
                    ></i>
                  ) : (
                    <i
                      onClick={() => onSortChange("last_login_ts", "DESC")}
                      className="ki-duotone ki-up bs-text-muted fs-1x cursor-pointer"
                    ></i>
                  )}
                </div>
              </th>
              <th>Created At</th>
              {get_permissions?.users_read || get_permissions?.users_write ? (
                <th className="w-200px text-end rounded-end pe-4">Actions</th>
              ) : (
                <th className="w-200px text-end rounded-end pe-4"></th>
              )}
              {/* <th className="w-200px text-end rounded-end pe-4">Action</th> */}
              {/* {authType?.users_delete ||
                authType?.users_write ||
                authType?.users_read ||
                superAdmin ? (
                  <th>Action</th>
                )
                 : null
                } */}
            </tr>
          </thead>
          {loading ? (
            <UsersListLoading />
          ) : userData?.length > 0 ? (
            userData?.map(
              (
                val: {
                  user_id: number;
                  full_name: string;
                  surname: string;
                  create_ts: string;
                  login: string;
                  ldap_ind: boolean;
                  inactive_ind: boolean;
                  last_login_ts: any;
                  access_type: { access_type_name: string };
                },
                index
              ) => (
                <>
                  <tbody>
                    <tr role="row" key={index}>
                      <td className="ps-4 fw-semibold  fs-6">
                        {capitalizeFirstLetter(val?.full_name) || "N/A"}
                      </td>

                      {/* <td className="">
                                                <div className="d-flex align-items-center">
                                                    <div className="d-flex flex-column">
                                                        {val?.login || "N/A"}
                                                    </div>
                                                </div>
                                            </td> */}

                      {/* <td className="">
                                                <div className="form-check form-check-custom form-check-inline form-check-solid me-5">
                                                    <input
                                                        type="checkbox"
                                                        className="d-flex flex-column form-check-input"
                                                        checked={val?.ldap_ind}
                                                        onChange={(e) => handleCheckboxChange("ldap_ind", val?.user_id, e?.target?.checked)}
                                                    />
                                                </div>
                                            </td> */}

                      <td className="">
                        <div className="form-check form-check-custom form-check-inline form-check-solid me-5">
                          <input
                            type="checkbox"
                            className="d-flex flex-column form-check-input"
                            checked={val?.inactive_ind == true ? true : false}
                            value={+val?.inactive_ind}
                            onChange={(e) =>
                              handleCheckboxChange(
                                "inactive_ind",
                                val?.user_id,
                                e?.target?.checked
                              )
                            }
                          />
                        </div>
                      </td>

                      <td className="ps-4 fw-semibold  fs-7">
                        {val?.access_type?.access_type_name || "N/A"}
                      </td>
                      <td className="ps-4 fw-semibold  fs-7">
                        {val?.last_login_ts != null
                          ? moment(val?.last_login_ts).format("DD/MM/YYYY h:m")
                          : "00:00:00"}
                      </td>

                      <td>
                        {val?.last_login_ts
                          ? moment(val?.create_ts).format("DD/MM/YYYY h:m")
                          : "00:00:00"}
                      </td>

                      <td className="pe-4 text-end">
                        {get_permissions?.users_read && (
                          <>
                            <Link
                              to={{
                                pathname: "/apps/manage-users/viewUser",
                                search: `?u_id=${encryptData(val?.user_id)}`,
                              }}
                              onContextMenu={(e) => e.preventDefault()}
                              className="btn view btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                            >
                              <i className="ki-duotone ki-eye fs-3">
                                {" "}
                                <span className="path1"></span>
                                <span className="path2"></span>
                                <span className="path3"></span>
                              </i>
                            </Link>
                            <Tooltip anchorSelect=".view" content="View" />
                          </>
                        )}
                        {get_permissions?.users_write && (
                          <>
                            <Link
                              to="#"
                              onContextMenu={(e) => e.preventDefault()}
                              onClick={() => handleEditClick(val?.user_id)}
                              className="edit btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                            >
                              <i className="ki-duotone ki-pencil fs-3">
                                <span className="path1"></span>
                                <span className="path2"></span>
                              </i>
                            </Link>

                            <Tooltip anchorSelect=".edit" content="Edit" />
                          </>
                        )}
                      </td>
                    </tr>
                  </tbody>
                </>
              )
            )
          ) : (
            <>
              <tr></tr>
              <tr>
                <td colSpan={7}>
                  <div className="d-flex text-center w-100 align-content-center justify-content-center">
                    No matching records found
                  </div>
                </td>
              </tr>
            </>
          )}
        </table>
      </div>

      <div className="d-flex flex-stack flex-wrap pt-10">
        <div className="fs-6 text-gray-700">
          Showing {Number(currentPage) || 0} to {userData?.length || 0} of{" "}
          {totalRec || 0} entries
        </div>

        <ul className="pagination">
          {userData?.length > 0 && (
            <ReactPaginate
              nextLabel="Next>"
              onPageChange={(event) => {
                const nextPage = event?.selected + 1;
                const newOffset = (nextPage * itemsPerPage) % userData?.length;
                setItemOffset(newOffset);
                setCurrentPage(nextPage);
              }}
              pageRangeDisplayed={3}
              marginPagesDisplayed={2}
              pageCount={pageCount}
              previousLabel="< Previous"
              pageClassName="page-item"
              pageLinkClassName="page-link"
              previousClassName="page-item"
              previousLinkClassName="page-link"
              nextClassName="page-item"
              nextLinkClassName="page-link"
              breakLabel="..."
              breakClassName="page-item"
              breakLinkClassName="page-link"
              containerClassName="pagination"
              activeClassName="active"
              renderOnZeroPageCount={null}
            />
          )}
        </ul>
      </div>

      {modalEditOpen && selectedUserId && (
        <EditUser
          setUsers={setUsers}
          userId={selectedUserId}
          isOpen={modalEditOpen}
          onClose={() => {
            setModalEditOpen(false);
            setSelectedUserId(null);
          }}
          isUserLoading={false}
          user={{
            id: undefined,
            first_name: undefined,
            last_name: undefined,
            avatar: undefined,
            email: undefined,
            position: undefined,
            role: undefined,
            last_login: undefined,
            two_steps: undefined,
            joined_day: undefined,
            online: undefined,
            login: undefined,
            access_type: undefined,
            inactive_ind: undefined,
            must_change_password_ind: undefined,
            ldap_ind: undefined,
            surname: undefined,
            initials: undefined,
          }}
        />
      )}
    </>
  );
};
export default Users;
