import { useIntl } from "react-intl";
import { PageTitle } from "../../../_metronic/layout/core";
import {
  ListsWidget1,
  ListsWidget2,
  ListsWidget3,
  ListsWidget4,
  ListsWidget5,
  ListsWidget6,
  MixedWidget10,
  MixedWidget11,
  MixedWidget2,
  StatisticsWidget5,
  TablesWidget10,
  TablesWidget5,
} from "../../../_metronic/partials/widgets";
import usePageTitle from "../../modules/auth/components/PageTitle/usePageTitle";
import { useEffect, useState } from "react";
import { fetchDashboardCount } from "../../../store/Dashboard/dashboardSlice";
import { AppDispatch } from "../../../store/store";
import { useDispatch } from "react-redux";
import { useAuth } from "../../modules/auth";
import { jwtDecode } from "jwt-decode";
import moment from "moment";
import { useNavigate } from "react-router-dom";

const DashboardWrapper = () => {
  usePageTitle("Dashboard");
  const intl = useIntl();
  const dispatch = useDispatch<AppDispatch>();
  const [dashboard, setDashbaord] = useState<any>("");
  const navigate = useNavigate();
  const { auth, logout } = useAuth();

  // check jwt time
  useEffect(() => {
    let timerRef = null;
    const decoded = jwtDecode(auth?.token);
    const currentTime = new Date().getTime();
    const expiryTime = new Date(decoded.exp * 1000).getTime();
    const timeout = expiryTime - currentTime;
    var today = new Date();
    today.setHours(today.getHours() + 4);

    const onExpire = () => {
      navigate("/auth");
      dispatch(logout);
    };

    if (timeout > 0) {
      // token not expired, set future timeout to log out and redirect
      timerRef = setTimeout(onExpire, timeout);
    } else {
      // token expired, log out and redirect
      onExpire();
    }

    // Clear any running timers on component unmount or token state change
    return () => {
      clearTimeout(timerRef);
    };
  }, [dispatch, navigate, auth?.token]);

  //consume dashboard api's
  useEffect(() => {
    fetchDashboardCounts();
  }, []);

  async function fetchDashboardCounts() {
    try {
      const { payload } = await dispatch(fetchDashboardCount(""));
      setDashbaord(payload?.data);
    } catch (error) {
      throw error;
    }
  }
  return (
    <>
      <PageTitle breadcrumbs={[]}>
        {intl.formatMessage({ id: "MENU.DASHBOARD" })}
      </PageTitle>

      {/* begin::Row */}
      <div className="row g-5 mb-10">
        <div className="col-xl-4">
          <StatisticsWidget5
            className="card-xl-stretch"
            svgIcon="element-11"
            color="info"
            iconColor="white"
            title="Categories"
            count={Number(dashboard?.category_count) || 0}
            titleColor="white"
            descriptionColor="white"
          />
        </div>

        <div className="col-xl-4">
          <StatisticsWidget5
            className="card-xl-stretch"
            svgIcon="icon"
            color="primary"
            iconColor="white"
            title="Stickers"
            count={Number(dashboard?.sticker_count) || 0}
            titleColor="white"
            descriptionColor="white"
          />
        </div>

        <div className="col-xl-4">
          <StatisticsWidget5
            className="card-xl-stretch"
            svgIcon="frame"
            color="success"
            iconColor="gray-100"
            title="Frames"
            count={Number(dashboard?.frame_count) || 0}
            titleColor="white"
            descriptionColor="gray-100"
          />
        </div>

        <div className="col-xl-4">
          <StatisticsWidget5
            className="card-xl-stretch"
            svgIcon="code"
            color="dark"
            iconColor="gray-100"
            title="Firmwares"
            count={Number(dashboard?.firmware_count) || 0}
            titleColor="white"
            descriptionColor="gray-100"
          />
        </div>

        <div className="col-xl-4">
          <StatisticsWidget5
            className="card-xl-stretch"
            svgIcon="element-2"
            color="danger"
            iconColor="gray-100"
            title="Roles"
            count={dashboard?.roles_count || 0}
            titleColor="white"
            descriptionColor="gray-100"
          />
        </div>

        <div className="col-xl-4">
          <StatisticsWidget5
            className="card-xl-stretch"
            svgIcon="user"
            color="warning"
            iconColor="gray-100"
            title="Apps"
            count={dashboard?.app_count}
            titleColor="white"
            descriptionColor="gray-100"
          />
        </div>
      </div>

      <div className="row g-5 g-xl-8">
        {/* begin::Col */}
        <div className="col-xl-12">
          <TablesWidget5 className="card-xl-stretch mb-5 mb-xl-8" />
        </div>
        {/* end::Col */}
      </div>

      {/* <div className='row gy-5 g-xl-8'>
      <div className='col-xxl-4'>
        <MixedWidget2
          className='card-xl-stretch mb-xl-8'
          chartColor='danger'
          chartHeight='200px'
          strokeColor='#cb1e46'
        />
      </div>
      <div className='col-xxl-4'>
        <ListsWidget5 className='card-xxl-stretch' />
      </div>
      <div className='col-xxl-4'>
        <MixedWidget10
          className='card-xxl-stretch-50 mb-5 mb-xl-8'
          chartColor='primary'
          chartHeight='150px'
        />
        <MixedWidget11
          className='card-xxl-stretch-50 mb-5 mb-xl-8'
          chartColor='primary'
          chartHeight='175px'
        />
      </div>
    </div> */}

      {/* <div className='row gy-5 gx-xl-8'>
      <div className='col-xxl-4'>
        <ListsWidget3 className='card-xxl-stretch mb-xl-3' />
      </div>
      <div className='col-xl-8'>
        <TablesWidget10 className='card-xxl-stretch mb-5 mb-xl-8' />
      </div>
    </div> */}

      {/* <div className='row gy-5 g-xl-8'>
      <div className='col-xl-4'>
        <ListsWidget2 className='card-xl-stretch mb-xl-8' />
      </div>
      <div className='col-xl-4'>
        <ListsWidget6 className='card-xl-stretch mb-xl-8' />
      </div>
      <div className='col-xl-4'>
        <ListsWidget4 className='card-xl-stretch mb-5 mb-xl-8' items={5} />
      </div>
    </div> */}
    </>
  );
};

export { DashboardWrapper };
