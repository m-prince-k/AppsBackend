export const Users = [{
    can_view_users: "Can View Users",
    status: false
}, { can_add_user: "Can Add User", status: false }, { can_delete_users: "Can Delete Users", status: false },
{ can_active_deactive_users: "Can Activate / Deactivate User", status: false },
{ can_resend_invitaio: "Can Resend Invitation", status: false }];


export const rolesPermission = [{
    can_view_roles: "Can View Roles",
}, { can_add_role: "Can Add Role" },
{ can_edit_role: "Can Edit Role" },
{ can_delete_role: "Can Delete Role"}
];

export interface roleInterface {
    access_type_id:number,
    access_type_name:string,
    access_type_descr:string
} 






