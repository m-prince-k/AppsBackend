import { Link } from "react-router-dom";
import { KTSVG, SwalResponse, useDebounce } from "../../../_metronic/helpers";
import { useEffect, useState } from "react";
import { Roles } from "./component/Roles";
import usePageTitle from "../../modules/auth/components/PageTitle/usePageTitle";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "../../../store/store";
import { listingRbac, makeRole } from "../../../store/HP/RBAC/rbacSlice";
import { SUCCESS, TITLE } from "../../../util/messages";
import { Modal, Button } from "react-bootstrap";
import { useFormik } from "formik";
import * as Yup from "yup";
import clsx from "clsx";
import { Profile, useAuth } from "../../modules/auth";

const validationSchema = Yup.object({
  roleName: Yup.string()
    .required("Role name is required")
    .max(50, "Role name must be less than or equal to 50 characters"),
});

const CreateRole = () => {
  usePageTitle("Roles Permission");
  const { currentUser, auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { isLoading, isSuccess, fetchAuthDetails, message, statusCode } =
    useSelector((state: { auth: Profile }) => state?.auth);
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;
  const [searchTerm, setSearch] = useState<string>("");
  const [roleName, setRoleName] = useState<any>("");
  const [showModal, setShowModal] = useState(false);
  const [validation, setValidation] = useState<any>({ roleName: "" });
  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);
  const handleCloseModal = () => {
    setShowModal(false), formik.resetForm();
  };
  const handleShowModal = () => setShowModal(true);
  const debouncedSearchTerm = useDebounce(searchTerm, 150);

  useEffect(() => {
    if (debouncedSearchTerm !== undefined && searchTerm !== undefined) {
      setSearch(debouncedSearchTerm);
    }
  }, [debouncedSearchTerm]);

  const formik = useFormik({
    initialValues: {
      roleName: "",
    },
    validationSchema,
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      setLoading(true);
      try {
        const { payload } = await dispatch(
          makeRole({ access_type_name: values.roleName.trim() })
        );

        if (payload?.status === 403) {
          await SwalResponse("danger", TITLE.WARNING, payload.message);
        } else if (payload?.status === 200) {
          resetForm();
          handleCloseModal();
          await dispatch(listingRbac(""));
          await SwalResponse("success", TITLE.ROLE, SUCCESS.ROLE_CREATED);
        } else if (payload?.status === 503) {
          await SwalResponse("danger", TITLE.ROLE, payload.error_details);
        } else if (payload?.status === 401) {
          await SwalResponse(
            "success",
            payload?.message,
            payload?.error_details
          );
        }
        setLoading(false);
      } catch (error) {
        console.error(error);
        setSubmitting(false);
      }
    },
  });

  const handleKeyTextType = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const target = event?.target as HTMLInputElement;
    if (event.key === " " && target.selectionStart === 0) {
      event.preventDefault();
    }
  };

  return (
    <>
      <div className="card" id="kt_profile_details_view">
        <div className="card-header">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">Manage Roles</h3>
          </div>
        </div>
        <div className="card-body p-9">
          <div className="justify-content-end mb-10 d-flex gap-3">
            <div className="d-flex align-items-center position-relative me-auto">
              <i className="ki-duotone ki-magnifier fs-1 position-absolute ms-6">
                <span className="path1"></span>
                <span className="path2"></span>
              </i>

              <input
                type="text"
                data-kt-user-table-filter="search"
                value={searchTerm}
                onChange={(e) => setSearch(e.target.value)}
                className="form-control w-350px ps-14"
                placeholder="Search roles"
              />
            </div>
            {(auth_permission || get_permissions?.roles_create) && (
              <Link
                onContextMenu={(e) => e.preventDefault()}
                to="#"
                className="btn  btn-light-primary d-flex align-items-center gap-2"
                onClick={handleShowModal}
              >
                <span className="svg-icon svg-icon-1 bi bi-plus-lg"></span>Add
                Role
              </Link>
            )}
          </div>

          <Roles searchTerm={searchTerm} />
        </div>
      </div>

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Add Role</Modal.Title>
        </Modal.Header>
        <form onSubmit={formik.handleSubmit}>
          <Modal.Body>
            <label className="mb-2 required">Role Name</label>
            <input
              type="text"
              name="roleName"
              maxLength={50}
              onKeyDown={handleKeyTextType}
              className={clsx(
                "form-control bg-transparent",
                {
                  "is-invalid":
                    formik.touched.roleName && formik.errors.roleName,
                },
                {
                  "is-valid":
                    formik.touched.roleName && !formik.errors.roleName,
                }
              )}
              placeholder="Enter the role name"
              {...formik.getFieldProps("roleName")}
            />
            {formik.touched.roleName && formik.errors.roleName && (
              <span style={{ color: "red" }}>{formik.errors.roleName}</span>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button variant="light" onClick={handleCloseModal}>
              Close
            </Button>
            <Button
              variant="primary"
              type="submit"
              disabled={formik.isSubmitting}
            >
              {loading ? (
                <span
                  className="indicator-progress"
                  style={{ display: "block" }}
                >
                  Please wait...{" "}
                  <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                </span>
              ) : (
                "Add"
              )}
            </Button>
          </Modal.Footer>
        </form>
      </Modal>
    </>
  );
};

export { CreateRole };
