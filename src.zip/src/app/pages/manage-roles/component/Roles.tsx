import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { Tooltip } from "react-tooltip";
import { listingRbac } from "../../../../store/HP/RBAC/rbacSlice";
import { AppDispatch } from "../../../../store/store";
import { roleInterface } from "../core/_model";
import { Profile, useAuth } from "../../../modules/auth";
import { capitalizeFirstLetter, encryptData } from "../../../../_metronic/helpers";
import { UsersListLoading } from "../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";

interface roles {
  isLoading: string;
  isSuccess: boolean;
  fetchListing: any;
  message: string;
  statusCode: number;
}

const Roles = (props: { searchTerm: string }) => {
  const { currentUser, auth } = useAuth();
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";
  const { fetchAuthDetails } = useSelector(
    (state: { auth: Profile }) => state?.auth
  );
  // const get_permissions = JSON.parse(localStorage.getItem("permissions"));
  const get_permissions = fetchAuthDetails?.data;
  const { searchTerm } = props;
  const [roles, setRoles] = useState<any>([]);
  const [totalRoles, setTotalRoles] = useState(0);
  const dispatch = useDispatch<AppDispatch>();

  const { isLoading, isSuccess, fetchListing, message, statusCode } =
    useSelector((state: { rbac: roles }) => state?.rbac);

  useEffect(() => {
    if (fetchListing?.data) {
      setRoles(fetchListing?.data);
      setTotalRoles(fetchListing?.total);
    }
  }, [isLoading, fetchListing]);

  useEffect(() => {
    let query = "";
    if (searchTerm) {
      query = `?searchTerm=${searchTerm}`;
    }
    dispatch(listingRbac(query));
  }, [searchTerm]);

  return (
    <>
      {isLoading ? (
        <div className="d-flex justify-content-center align-items-center">
          <UsersListLoading />
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table align-middle gs-0 gy-4">
              <thead>
                <tr className="fw-bold text-muted bg-light">
                  <th className="ps-4  rounded-start">Name</th>
                  {(auth_permission || get_permissions?.roles_write) && (
                    <th className="w-200px text-end rounded-end pe-4 ">
                      Actions
                    </th>
                  )}
                </tr>
              </thead>
              <tbody>
                {roles?.length > 0 ? (
                  roles?.map((val: roleInterface, index: number) => (
                    <>
                      <tr key={index}>
                        <td className="ps-4 fw-semibold fs-7">
                          {val?.access_type_name || "N/A"}
                        </td>
                        <td className="pe-4 text-end">
                          {(auth_permission ||
                            get_permissions?.roles_write) && (
                            <>
                              <Link
                                onContextMenu={(e) => e.preventDefault()}
                                state={{
                                  role: val?.access_type_name,
                                  access_type_id: val.access_type_id,
                                }}
                                to={{pathname:"/apps/manage-permission/manage-permission",
                                  search:`?role=${encryptData(val?.access_type_name)}&access_type_id=${encryptData(val?.access_type_id)}`
                                }}
                                className="btn edit btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                              >
                                <i className="ki-duotone ki-pencil fs-3">
                                  <span className="path1"></span>
                                  <span className="path2"></span>
                                </i>
                              </Link>
                              <Tooltip anchorSelect=".edit" content="Edit" />
                            </>
                          )}
                        </td>
                      </tr>
                    </>
                  ))
                ) : (
                  <>
                    <tr></tr>
                    <tr>
                      <td colSpan={7}>
                        <div className="d-flex text-center w-100 align-content-center justify-content-center">
                          No matching records found
                        </div>
                      </td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>
          <div className="fs-6 text-gray-700">
            Showing Total {totalRoles} entries
          </div>
        </>
      )}
    </>
  );
};
export { Roles };
