import { FC } from "react";
import { Route, Routes, Outlet, Navigate } from 'react-router-dom'
import { PageLink, PageTitle } from '../../../../_metronic/layout/core'
import { Tooltip } from 'react-tooltip';
import { Link } from 'react-router-dom'
import { KTSVG } from '../../../../_metronic/helpers';
import { PermissionManage } from "./ManagePermission";

const usersBreadcrumbs: Array<PageLink> = [
    {
        title: 'Manage Permission',
        path: '/apps/manage-permission/manage-permission',
        isSeparator: false,
        isActive: false,
    },
    {
        title: '',
        path: '',
        isSeparator: true,
        isActive: false,
    },
]

const ManagePermission = () => {
    return (
        <Routes>
            <Route element={<Outlet />}>
                <Route
                    path='manage-permission'
                    element={
                        <>
                        <PageTitle breadcrumbs={usersBreadcrumbs}>Manage Permission</PageTitle>
                        <PermissionManage/>
                        </>
                    }
                />
            </Route>
            <Route index element={<Navigate to='/apps/manage-permission/manage-permission' />} />
        </Routes>
    )
}

export default ManagePermission
