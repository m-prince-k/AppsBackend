import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AppDispatch } from "../../../../store/store";
import {
  fetchRolesPermission,
  UpdateRbac,
} from "../../../../store/HP/RBAC/rbacSlice";
import { decryptData, SwalResponse } from "../../../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../../../util/messages";
import moment from "moment";
import { Button } from "react-bootstrap";
import { UsersListLoading } from "../../../modules/apps/user-management/users-list/components/loading/UsersListLoading";

const PermissionManage = () => {
  const location = useLocation();

  const { search } = useLocation();

  const searchParams = new URLSearchParams(search);

  let filterAccessId = decryptData(searchParams.get("access_type_id"));
  let access_type_id = filterAccessId;

  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [loading, setLoading] = useState(false);

  const [permissionCheckboxes, setPermissionCheckboxes] = useState<any>({
    access_type_id: 0,
    roles_permission_id: 0,
    category_read: false,
    category_write: false,
    category_create: false,
    category_delete: false,
    category_re_arrange: false,
    category_archived: false,
    category_active_deactive: false,
    category_re_order: false,
    apps_read: false,
    apps_write: false,
    apps_create: false,
    apps_delete: false,
    users_read: false,
    users_write: false,
    users_create: false,
    users_delete: false,
    users_active_deactive: false,
    users_resend_invitation: false,
    firmware_read: false,
    firmware_write: false,
    firmware_create: false,
    firmware_delete: false,
    frame_read: false,
    frame_write: false,
    frame_create: false,
    frame_delete: false,
    frame_active_deactive: false,
    frame_re_order: false,
    sticker_read: false,
    sticker_write: false,
    sticker_create: false,
    sticker_delete: false,
    sticker_active_deactive: false,
    sticker_re_order: false,
    roles_read: false,
    roles_write: false,
    roles_create: false,
    roles_delete: false,
  });

  const { fetchPermissions, isLoading, isSuccess, message, statusCode } =
    useSelector((state: any) => state?.rbac);

  const { data: permissions } = fetchPermissions;

  useEffect(() => {
    if (
      access_type_id &&
      searchParams.get("access_type_id") &&
      searchParams.get("role")
    ) {
      dispatch(fetchRolesPermission(Number(access_type_id)));
    } else {
      SwalResponse("warning", "Warning", "Access type id is not correct");
    }
  }, []);

  //fetch permission along with role name
  useEffect(() => {
    if (permissions && permissions?.roles_permission_id) {
      setPermissionCheckboxes({
        access_type_id: permissions.access_type.access_type_id,
        roles_permission_id: permissions.roles_permission_id,
        category_read: permissions.category_read,
        category_write: permissions.category_write,
        category_create: permissions.category_create,
        category_delete: permissions.category_delete,
        category_archived: permissions.category_archived,
        category_re_arrange: permissions.category_re_arrange,
        category_active_deactive: permissions.category_active_deactive,
        category_re_order: permissions.category_re_order,
        apps_read: permissions.apps_read,
        apps_write: permissions.apps_write,
        apps_create: permissions.apps_create,
        apps_delete: permissions.apps_delete,
        users_read: permissions.users_read,
        users_write: permissions.users_write,

        users_create: permissions.users_create,
        users_delete: permissions.users_delete,
        users_active_deactive: permissions.users_active_deactive,
        users_resend_invitation: permissions.users_resend_invitation,
        firmware_read: permissions.firmware_read,
        firmware_write: permissions.firmware_write,
        firmware_create: permissions.firmware_create,
        firmware_delete: permissions.firmware_delete,
        frame_read: permissions.frame_read,
        frame_write: permissions.frame_write,
        frame_create: permissions.frame_create,
        frame_delete: permissions.frame_delete,
        frame_active_deactive: permissions.frame_active_deactive,
        frame_re_order: permissions.frame_re_order,
        sticker_read: permissions.sticker_read,
        sticker_write: permissions.sticker_write,
        sticker_create: permissions.sticker_create,
        sticker_delete: permissions.sticker_delete,
        sticker_active_deactive: permissions.sticker_active_deactive,
        sticker_re_order: permissions.sticker_re_order,
        roles_read: permissions.roles_read,
        roles_write: permissions.roles_write,
        roles_create: permissions.roles_create,
        roles_delete: permissions.roles_delete,
      });
    }
  }, [permissions]);

  //THIS IS UPDATE CASE FOR ROLES AND PERMISSIONS
  const handleSubmitRolesPermission = async (event: any) => {
    event.preventDefault();
    try {
      setSubmitLoading(true);
      let updatePermissions = {
        access_type_id: permissionCheckboxes.access_type_id,
        roles_permission_id: permissionCheckboxes.roles_permission_id,
        category_read: permissionCheckboxes.category_read,
        category_write: permissionCheckboxes.category_write,
        category_create: permissionCheckboxes.category_create,
        category_delete: permissionCheckboxes.category_delete,
        category_archived: permissionCheckboxes.category_archived,
        category_re_arrange: permissionCheckboxes.category_re_arrange,
        category_active_deactive: permissionCheckboxes.category_active_deactive,
        category_re_order: permissionCheckboxes.category_re_order,
        apps_read: permissionCheckboxes.apps_read,
        apps_write: permissionCheckboxes.apps_write,
        apps_create: permissionCheckboxes.apps_create,
        apps_delete: permissionCheckboxes.apps_delete,
        users_read: permissionCheckboxes.users_read,
        users_write: permissionCheckboxes.users_write,

        users_create: permissionCheckboxes.users_create,
        users_delete: permissionCheckboxes.users_delete,
        users_active_deactive: permissionCheckboxes.users_active_deactive,
        users_resend_invitation: permissionCheckboxes.users_resend_invitation,
        firmware_read: permissionCheckboxes.firmware_read,
        firmware_write: permissionCheckboxes.firmware_write,
        firmware_create: permissionCheckboxes.firmware_create,
        firmware_delete: permissionCheckboxes.firmware_delete,
        frame_read: permissionCheckboxes.frame_read,
        frame_write: permissionCheckboxes.frame_write,
        frame_create: permissionCheckboxes.frame_create,
        frame_delete: permissionCheckboxes.frame_delete,
        frame_active_deactive: permissionCheckboxes.frame_active_deactive,
        frame_re_order: permissionCheckboxes.frame_re_order,
        sticker_read: permissionCheckboxes.sticker_read,
        sticker_write: permissionCheckboxes.sticker_write,
        sticker_create: permissionCheckboxes.sticker_create,
        sticker_delete: permissionCheckboxes.sticker_delete,
        sticker_active_deactive: permissionCheckboxes.sticker_active_deactive,
        sticker_re_order: permissionCheckboxes.sticker_re_order,
        roles_read: permissionCheckboxes.roles_read,
        roles_write: permissionCheckboxes.roles_write,
        roles_create: permissionCheckboxes.roles_create,
        roles_delete: permissionCheckboxes.roles_delete,
      };

      const { payload } = await dispatch(UpdateRbac(updatePermissions));
      setSubmitLoading(false);
      if (payload?.status === 403) {
        await SwalResponse("danger", TITLE?.WARNING, payload?.message);
      } else if (payload?.status === 200) {
        await SwalResponse(
          "success",
          TITLE?.ROLE_UPDATED,
          SUCCESS?.ROLE_UPDATED
        );
        navigate(-1);
      } else if (payload?.status === 401) {
        await SwalResponse("success", payload?.message, payload?.error_details);
      } else if (payload?.status == 503) {
        await SwalResponse(
          "danger",
          TITLE?.ROLE_UPDATED,
          payload.error_details
        );
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <>
      <div className="card" id="kt_profile_details_view">
        <div className="card-header">
          <div className="card-title m-0">
            <h3 className="fw-bolder m-0">Manage Permission</h3>
          </div>
        </div>
        {loading ? (
          <>
            <UsersListLoading />
          </>
        ) : (
          <div className="card-body p-9">
            <div className="row mb-10">
              <div className="col-md-6 col-lg-4">
                <label className="mb-2">Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={
                    permissions?.access_type?.access_type_name
                      ? permissions?.access_type?.access_type_name
                      : ""
                  }
                  disabled
                />
              </div>
            </div>
            <h4 className="pb-5 border-bottom border-bottom-dashed mb-10">
              Common Functions
            </h4>
            <div className="row mb-10">
              <div className="col-md-4 col-lg-3">
                <h5 className="mb-5">Users</h5>
                <div className="d-flex flex-column gap-4">
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.users_read}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          users_read: e.target.checked,
                        }))
                      }
                    />
                    Can View Users
                  </div>

                  <div className="form-check form-check-custom form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.users_create}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          users_create: e.target.checked,
                        }))
                      }
                    />
                    Can Add User
                  </div>

                  <div className="form-check form-check-custom form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes?.users_write}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          users_write: e.target.checked,
                        }))
                      }
                    />
                    Can Write User
                  </div>

                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.users_delete}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          users_delete: e.target.checked,
                        }))
                      }
                    />
                    Can Delete Users
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.users_active_deactive}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          users_active_deactive: e.target.checked,
                        }))
                      }
                    />
                    Can Activate / Deactivate User
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.users_resend_invitation}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          users_resend_invitation: e.target.checked,
                        }))
                      }
                    />
                    Can Resend Invitation
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-lg-3">
                <h5 className="mb-5">Roles & Permissions</h5>
                <div className="d-flex flex-column gap-4">
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.roles_read}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          roles_read: e.target.checked,
                        }))
                      }
                    />
                    Can View Roles
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.roles_create}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          roles_create: e.target.checked,
                        }))
                      }
                    />
                    Can Add Role
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.roles_write}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          roles_write: e.target.checked,
                        }))
                      }
                    />
                    Can Edit Role
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.roles_delete}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          roles_delete: e.target.checked,
                        }))
                      }
                    />
                    Can Delete Role
                  </div>
                </div>
              </div>
            </div>
            <h4 className="pb-5 border-bottom border-bottom-dashed mb-10">
              Apps
            </h4>
            <div className="row mb-10">
              <div className="col-md-4 col-lg-3">
                <h5 className="mb-5">Categories</h5>
                <div className="d-flex flex-column gap-4">
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_create}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_create: e.target.checked,
                        }))
                      }
                    />
                    Add
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_write}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_write: e.target.checked,
                        }))
                      }
                    />
                    Edit
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_delete}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_delete: e.target.checked,
                        }))
                      }
                    />
                    Delete
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_re_order}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_re_order: e.target.checked,
                        }))
                      }
                    />
                    Re-order
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_re_arrange}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_re_arrange: e.target.checked,
                        }))
                      }
                    />
                    Re-arrange
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_archived}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_archived: e.target.checked,
                        }))
                      }
                    />
                    Archived
                  </div>

                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.category_active_deactive}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          category_active_deactive: e.target.checked,
                        }))
                      }
                    />
                    Activate / Deactivate{" "}
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-lg-3">
                <h5 className="mb-5">Stickers </h5>
                <div className="d-flex flex-column gap-4">
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.sticker_create}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          sticker_create: e.target.checked,
                        }))
                      }
                    />
                    Add
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.sticker_write}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          sticker_write: e.target.checked,
                        }))
                      }
                    />
                    Edit
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.sticker_delete}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          sticker_delete: e.target.checked,
                        }))
                      }
                    />
                    Delete
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.sticker_re_order}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          sticker_re_order: e.target.checked,
                        }))
                      }
                    />
                    Re-order
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.sticker_active_deactive}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          sticker_active_deactive: e.target.checked,
                        }))
                      }
                    />
                    Activate / Deactivate{" "}
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-lg-3">
                <h5 className="mb-5">Frames </h5>
                <div className="d-flex flex-column gap-4">
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.frame_create}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          frame_create: e.target.checked,
                        }))
                      }
                    />
                    Add
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.frame_write}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          frame_write: e.target.checked,
                        }))
                      }
                    />
                    Edit
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.frame_delete}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          frame_delete: e.target.checked,
                        }))
                      }
                    />
                    Delete
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.frame_re_order}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          frame_re_order: e.target.checked,
                        }))
                      }
                    />
                    Re-order
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.frame_active_deactive}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          frame_active_deactive: e.target.checked,
                        }))
                      }
                    />
                    Activate / Deactivate{" "}
                  </div>
                </div>
              </div>

              <div className="col-md-4 col-lg-3">
                <h5 className="mb-5">Firmwares</h5>
                <div className="d-flex flex-column gap-4">
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.firmware_create}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          firmware_create: e.target.checked,
                        }))
                      }
                    />
                    Can Add
                  </div>
                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes.firmware_write}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          firmware_write: e.target.checked,
                        }))
                      }
                    />
                    Can Change Status
                  </div>

                  <div className="form-check form-check-custom  form-check-sm gap-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="flexCheckboxLg"
                      value=""
                      checked={permissionCheckboxes?.firmware_read}
                      onChange={(e) =>
                        setPermissionCheckboxes((prev: any) => ({
                          ...prev,
                          firmware_read: e.target.checked,
                        }))
                      }
                    />
                    Can View
                  </div>

                  {/* <div className="form-check form-check-custom  form-check-sm gap-3">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="flexCheckboxLg"
                    value=""
                  />
                  Re-order
                </div> */}

                  {/* <div className="form-check form-check-custom  form-check-sm gap-3">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="flexCheckboxLg"
                    value=""
                  />
                  Activate / Deactivate{" "}
                </div> */}
                </div>
              </div>
            </div>

            <h4 className="pb-5 border-bottom border-bottom-dashed mb-10">
              Reports
            </h4>
            <div className="justify-content-end  d-flex gap-3">
              <Link
                to="/apps/manage-roles/manage-roles"
                className="btn  btn-light-secondary d-flex align-items-center gap-2"
              >
                Discard
              </Link>
              <Button
                className="btn  btn-light-primary d-flex align-items-center"
                onClick={handleSubmitRolesPermission}
                disabled={submitLoading}
              >
                {submitLoading ? (
                  <span
                    className="indicator-progress"
                    style={{ display: "block" }}
                  >
                    Please wait...{" "}
                    <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
                  </span>
                ) : (
                  "Update"
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export { PermissionManage };
