import { FC } from "react";
import { Route, Routes, Outlet, Navigate } from "react-router-dom";
import { PageLink, PageTitle } from "../../../_metronic/layout/core";

import { Link } from "react-router-dom";
import { CreateRole } from "./CreateRole";
import { useAuth } from "../../modules/auth";

const roleBreadcrumbs: Array<PageLink> = [
  {
    title: "Manage Roles",
    path: "/apps/manage-roles/manage-roles",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

const ManageRoles = () => {
  const { currentUser, auth } = useAuth();

  // Check if the user has admin or app manager permissions
  const auth_permission =
    auth?.access_type?.access_type_name === "Admin" ||
    auth?.access_type?.access_type_name === "App Manager";

  // If the user doesn't have the necessary permissions, redirect them to a 404 page
  if (!auth_permission) {
    return <Navigate to="/error/404" />;
  }
  return (
    <Routes>
      <Route element={<Outlet />}>
        <Route
          path="manage-roles"
          element={
            <>
              <PageTitle breadcrumbs={roleBreadcrumbs}>Manage Roles</PageTitle>
              <CreateRole />
            </>
          }
        />
        
      </Route>
      {auth_permission && (
        <Route
          index
          element={<Navigate to="/apps/manage-roles/manage-roles" />}
        />
      )}
    </Routes>
  );
};

export default ManageRoles;
