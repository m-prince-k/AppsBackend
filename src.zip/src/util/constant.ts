// const BASE_URL_URL = "http://23.22.32.84:5001/api/"; //this is for production url
// const BASE_URL_URL = import.meta.env?.VITE_APP_API_URL;
const BASE_URL_URL = import.meta.env?.VITE_APP_THEME_LOCAL_API_URL;
///const BASE_URL_URL="http://192.168.0.203:4000/api/v1/crypto/" //this is for local url

const REACT_APP_S3_CLOUD_IMAGE_URL = import.meta.env
  ?.REACT_APP_S3_CLOUD_IMAGE_URL;
const token = "FQjABCwkGrea8r53bRIdEBcpJ9oJSJfQ";

const ITEM_PER_PAGE = 10;

const MAX_FILES = 10;

//Apps
const createApp = "/apps/create";
const AppsListing = "/apps/list";
const fetchApps="/apps/category/fetchApp";


//Auth Section
const register = "/register";
const apiLogin = "/auth/login";

const forgotPassword = "/auth/forgot-password";
const resetPassword = "/auth/reset-password";
const changePassword = "/auth/change-password";
const updateProfile = "/auth/update-profile";
const updateProfilePic = "/auth/update-user-image";
const getProfile = "/users/view-profile";
const getAuthDetais = "/auth/get-user-permissions";
const verifyToken = "/verifyToken";

//User Section
const getUserByIds="/users/get-by-id";
const fetchUserListing = "/users/get-users";

const AddUser = "/users/add-new-user";

const UpdateUser = "update-user";
const ViewUser = "view-user";
const DeletedUser = "/delete-user";
const changeUserStatus="/users/change-status";

//Sticker Section
const StickerListing = "/apps/sticker/fetch";
const ReorderSticker = "/apps/sticker/reorder";
const DeletedSticker = "/delete-sticker";
const ActiveDeactiveSticker = "/apps/sticker/updateStatus";
const AddSticker = "/apps/sticker/create";
const UpdateSticker = "/apps/sticker/update";
const ViewSticker = "/apps/sticker/view";
const ViewStickerByID = "/apps/sticker/details";

//Frame Section
const fetchFrameById="/apps/frame/details";
const specificFrameStatusUpdate="/apps/frame/updateStatus";
const createFrame = "/apps/frame/create";
const ListingFrame = "/apps/frame/fetch";
const UpdateFrame = "/apps/frame/update";
const ViewFrame = "/apps/frame/view";
const ReorderFrame = "/apps/frame/reorder";
const DeletedFrame = "/delete-frame";
const ActiveDeactiveFrame = "/activeDeactiveframe";


//RBAC Section
const createRbac = "/auth/update-permission";
const fetchRolesPermission = "/auth/role-permission";
const UpdateRbac = "/auth/update-permission";
const rbacListing = "/users/access-types";

//FirmWare Section
const createFirmWare = "/apps/firmware/create";
const ListingFirmWare = "/apps/firmware/fetch";
const ViewFirmWare = "/apps/firmware/view";
const UpdateFirmWare = "/update-firmWare";
const DeleteFirmWare = "/delete-firmWare";
const StatusFirmWare = "/apps/firmware/updateStatus";

//Category Section
const CategoryListing = "/apps/category";
const ReArrangeCategory = "/apps/category/reorder";
const AssetsReOrder = "/apps/category/asset-reorder";
const ArchivedCategory = "/apps/category/fetchArchive";
const ListingCategories = "/apps/category/fetchCategory";
const ViewAllCategoriesByID = "/apps/category-view";
const ReOrderCategory = "/apps/category/asset";
const ArchiveCategories = "/archiveCategories";
const ActiveDeactiveCategory = "/apps/category/updateStatus";
const CreateCategory = "/apps/category/addCategory";
const FetchCategoryElement = "/apps/category/fetchCategoryElement";
const UpdateCategory = "/apps/category/update";
const CategoryViewById = "/apps/category/view";
const AssetsCategory = "/apps/category/asset";
const ListingAssetsCategory = "/apps/category/asset-fetch";
const AssetsCategoryViewById = "/apps/category/asset-view";
const ActiveDeactiveAssetCategory = "/apps/category/asset-updateStatus";
const ActiveDeleteAssetCategory = "/apps/category/asset-delete";
const SignInWithMicrosoft="/auth/login2";

//Firmware section
const createPrinter="/apps/printer/create";
const fetchAllPrinters="/apps/printer/list";

//Dashboard section
const getDashboardCount="/dashboard/data"
const getDashboardActivity="/dashboard/activity"

//Report Section
const getReport="/app/reports/generateReport"

export {
  SignInWithMicrosoft,
  MAX_FILES,
  changeUserStatus,
  getUserByIds,
  getReport,
  fetchApps,
  getDashboardCount,
  getDashboardActivity,
  createPrinter,
  fetchAllPrinters,
  fetchFrameById,
  specificFrameStatusUpdate,
  createApp,
  CategoryListing,
  ReArrangeCategory,
  AssetsReOrder,
  BASE_URL_URL,
  AppsListing,
  fetchRolesPermission,
  register,
  apiLogin,
  ArchivedCategory,
  forgotPassword,
  resetPassword,
  changePassword,
  updateProfile,
  getProfile,
  updateProfilePic,
  verifyToken,
  createFirmWare,
  ListingFirmWare,
  ViewFirmWare,
  UpdateFirmWare,
  DeleteFirmWare,
  ListingCategories,
  ArchiveCategories,
  ReOrderCategory,
  CreateCategory,
  UpdateCategory,
  FetchCategoryElement,
  CategoryViewById,
  ActiveDeactiveCategory,
  createFrame,
  ListingFrame,
  UpdateFrame,
  ViewFrame,
  ReorderFrame,
  DeletedFrame,
  ActiveDeactiveFrame,
  StickerListing,
  ReorderSticker,
  DeletedSticker,
  ActiveDeactiveSticker,
  AddSticker,
  UpdateSticker,
  ViewStickerByID,
  ViewSticker,
  fetchUserListing,
  AddUser,
  ViewUser,
  DeletedUser,
  UpdateUser,
  createRbac,
  UpdateRbac,
  rbacListing,
  getAuthDetais,
  ITEM_PER_PAGE,
  AssetsCategory,
  ListingAssetsCategory,
  AssetsCategoryViewById,
  ActiveDeactiveAssetCategory,
  ActiveDeleteAssetCategory, StatusFirmWare,ViewAllCategoriesByID
};
