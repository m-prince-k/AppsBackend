import axios from "axios";
import {
  BASE_URL_URL,
  createFrame,
  ListingFrame,
  UpdateFrame,
  ViewFrame,
  ReorderFrame,
  DeletedFrame,
  ActiveDeactiveFrame,
  specificFrameStatusUpdate,
} from "../../util/constant";
import { SwalResponse } from "../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../util/messages";
 
const CreateAnFrame = async (frameData: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFrame, frameData);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};
 
const frameListing = async (frameID: any) => {
  try {
    const response = await axios.get(BASE_URL_URL + ListingFrame);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};
 
const ViewAnFrame = async (frameID: any) => {
  try {
    const response = await axios.get(BASE_URL_URL + ViewFrame, frameID);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};
 
const ActiveDeActiveFrame = async (frameId: any) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + ActiveDeactiveFrame + "/" + frameId
    );
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};
 
const EditFrame = async (type: string, payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + UpdateFrame, payload);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};
 
const ReOrderFrame = async (frameId: any) => {
  try {
    const response = await axios.get(BASE_URL_URL + ReorderFrame, frameId);
    return response?.data;
  } catch (error) {
    throw error;
  }
};
 
const DeleteFrame = async (frameId: any) => {
  try {
    const response = await axios.delete(BASE_URL_URL + DeletedFrame, frameId);
    return response?.data;
  } catch (error) {
    throw error;
  }
};


 
const Frame = {
  CreateAnFrame,
  frameListing,
  ViewAnFrame,
  ActiveDeActiveFrame,
  EditFrame,
  ReOrderFrame,
  DeleteFrame,
};
 
export default Frame;