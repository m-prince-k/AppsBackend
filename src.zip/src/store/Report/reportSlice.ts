import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import Report from "./reportService";
import { SUCCESS } from "../../util/messages";

const initialState = {
    isLoading:false,
    isError:false,
    message:"",
    getReports:"",
}


//create printers...
export const getAllReports= createAsyncThunk ('get/reports',async (queryParams:string,thunkApi:any) => {
    try {
        return await Report.GenerateReport(queryParams);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


export const ReportReducer=createSlice({
    name:'report-info',
    initialState,
    reducers:{
        logout:(state) => {
            state.isLoading=false
            state.isError=false
            state.message=""
            state.getReports=""
     
        }
    },
    extraReducers:(builder) => {
        builder.addCase(getAllReports.pending,(state,action) => {
            state.isLoading=true
            state.isError=action.payload
            state.message=""
        }).addCase(getAllReports.fulfilled,(state,action) => {
            state.isLoading=false
            state.getReports=action.payload
            state.message=SUCCESS.REPORT_FETCHED
        }).addCase(getAllReports.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        });
    }
});

export const {logout}=ReportReducer.actions;

export default ReportReducer.reducer;