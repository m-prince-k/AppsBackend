import axios from "axios";
import { BASE_URL_URL, getReport } from "../../util/constant";
import { SwalResponse } from "../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../util/messages";



//Developed by prince
const GenerateReport = async (queryParams: string) => {
    try {
        const response = await axios.get(BASE_URL_URL + getReport + queryParams);
        return response?.data;
    } catch (error) {
        throw error;
    }
};

const Report = {
    GenerateReport
}
export default Report;


