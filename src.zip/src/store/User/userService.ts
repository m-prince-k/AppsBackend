import axios, { AxiosResponse } from "axios";
import {
  BASE_URL_URL,
  AddUser,
  fetchUserListing,
  ViewUser,
  DeletedUser,
  UpdateUser,
  getUserByIds,
  changeUserStatus
} from "../../util/constant";
import { SwalResponse } from "../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../util/messages";

const CreateUser = async (userData: object) => {
  try {
    const response = await axios.post(BASE_URL_URL + AddUser, userData);
   
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
};

const userListing = async (queryParams: string) => {
  try {
    let response: AxiosResponse<any, any>;
    if (queryParams) {
      response = await axios.get(BASE_URL_URL + fetchUserListing + queryParams);
    } else {
      response = await axios.get(BASE_URL_URL + fetchUserListing);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

//


const getUserById = async (queryParams: string) => {
  try {
    let response: AxiosResponse<any, any>;
    response = await axios.get(BASE_URL_URL + getUserByIds + queryParams);
    return response?.data;
  } catch (error) {
    throw error;
  }
};



const EditUser = async (type: string, payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + UpdateUser, payload);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const userChangeStatus = async (payload: object) => {
  try {
    const response = await axios.patch(BASE_URL_URL + changeUserStatus, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const DeleteUser = async (userID: any) => {
  try {
    const response = await axios.delete(BASE_URL_URL + DeletedUser, userID);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const User = {
  getUserById,
  CreateUser,
  userChangeStatus,
  userListing,
  EditUser,
  DeleteUser,
};

export default User;
