import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { SUCCESS } from "../../util/messages";
import User from "./userService";

const initialState = {
  isLoading: false,
  isError: false,
  message: "",
  users: "",
  createUserDetail: "",
  viewUserDetail: "",
  activeDeActiveDetail: "",
  getStatusForUser:""
};

//get all users
export const getAllUsers = createAsyncThunk("get/user", async (queryParams: string, thunkApi: any) => {
  try {
    return await User.userListing(queryParams);
  } catch (error) {
    const message =
      error.data?.data ||
      error.data ||
      error?.data?.message ||
      error.string();
    return thunkApi.rejectWithValue(message);
  }
}
);

//By id

export const getUserById = createAsyncThunk("get/userById", async (queryParams: string, thunkApi: any) => {
  try {
    return await User.getUserById(queryParams);
  } catch (error) {
    const message =
      error.data?.data ||
      error.data ||
      error?.data?.message ||
      error.string();
    return thunkApi.rejectWithValue(message);
  }
}
);


export const UserCreate = createAsyncThunk(
  "post/user",
  async (data: object, thunkApi: any) => {
    try {
      return await User.CreateUser(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const UserStatusChange = createAsyncThunk("get/statusChange",async (payload: object, thunkApi: any) => {
    try {
      return await User.userChangeStatus(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const UserReducer = createSlice({
  name: "user-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isError = false;
      state.message = "";
      state.createUserDetail = "";
      state.viewUserDetail = "";
      state.activeDeActiveDetail = "";
      state.getStatusForUser="";
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getAllUsers.pending, (state, action) => {
      state.isLoading = true;
      state.isError = action.payload;
      state.message = "";
    })
      .addCase(getAllUsers.fulfilled, (state, action) => {
        state.isLoading = false;
        state.users = action.payload;
        state.message = SUCCESS.USERS_FETCHED;
      })
      .addCase(getAllUsers.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      }).addCase(UserCreate.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(UserCreate.fulfilled, (state, action) => {
        state.isLoading = false;
        state.createUserDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(UserCreate.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(getUserById.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(getUserById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.viewUserDetail = action.payload;
        state.message = SUCCESS.USER_FETCH_BY_ID;
      })
      .addCase(getUserById.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(UserStatusChange.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(UserStatusChange.fulfilled, (state, action) => {
        state.isLoading = false;
        state.getStatusForUser = action.payload;
        state.message = SUCCESS?.USER_STATUS_CHANGED;
      })
      .addCase(UserStatusChange.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      });
  },
});

//userStatusChange
//getStatusForUser

export const { logout } = UserReducer.actions;

export default UserReducer.reducer;
