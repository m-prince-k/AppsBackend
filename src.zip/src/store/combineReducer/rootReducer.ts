import { combineReducers } from "@reduxjs/toolkit";
import authSlice from "../Auth/authSlice";
import frameSlice from "../HP/Frame/frameSlice";
import categorySlice from "../HP/Category/categorySlice";
import stickerSlice from "../HP/Sticker/stickerSlice";
import rbacSlice from "../HP/RBAC/rbacSlice";
import reportingSlice from "../HP/Reporting/reportingSlice";
import userSlice from "../User/userSlice";
import AppsReducer from "../Apps/appSlice";
import ReportReducer from "../Report/reportSlice";
import PrintReducer  from "../Printer/printerSlice";


const rootReducer = combineReducers({
  auth: authSlice,
  frames: frameSlice,
  categories: categorySlice,
  stickers: stickerSlice,
  rbac: rbacSlice,
  reports: reportingSlice,
  users: userSlice,
  apps: AppsReducer,
  report: ReportReducer,
  printer:PrintReducer
});

export type IRootState = ReturnType<typeof rootReducer>

export default rootReducer;
