import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import Printer from "./printerService";
import { SUCCESS } from "../../util/messages";

const initialState = {
    isLoading:false,
    isLogin:false,
    isError:false,
    message:"",
    fetchPrinters:"",
    getFirmware:""
}


//create printers...
export const getPrinters= createAsyncThunk ('post/makePrinter',async (payload:object,thunkApi:any) => {
    try {
        return await Printer.CreatePrinter(payload);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});

//create printers...
export const fetchAllPrinters= createAsyncThunk ('get/fetchPrinters',async (query:string,thunkApi:any) => {
    try {
        return await Printer.FetchPrinters(query);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


export const PrintReducer=createSlice({
    name:'printer-info',
    initialState,
    reducers:{
        logout:(state) => {
            state.isLoading=false
            state.isError=false
            state.message=""
            state.fetchPrinters=""
            state.getFirmware=""
        }
    },
    extraReducers:(builder) => {
        builder.addCase(fetchAllPrinters.pending,(state,action) => {
            state.isLoading=true
            state.isError=action.payload
            state.message=""
        }).addCase(fetchAllPrinters.fulfilled,(state,action) => {
            state.isLoading=false
            state.fetchPrinters=action.payload
            state.message=SUCCESS.PRINTER_FETCHED
        }).addCase(fetchAllPrinters.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        });
    }
});

export const {logout}=PrintReducer.actions;

export default PrintReducer.reducer;



