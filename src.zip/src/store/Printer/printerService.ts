import axios from "axios";
import { BASE_URL_URL, fetchAllPrinters, createPrinter } from "../../util/constant";
import { SwalResponse } from "../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../util/messages";


//Developed by prince
const CreatePrinter = async (payload: object) => {
    try {
        const response = await axios.post(BASE_URL_URL + createPrinter, payload);
        return response?.data;
    } catch (error) {
        throw error;
    }
};

//Developed by prince
const FetchPrinters = async (queryParams:string) => {
    try {
      const response = await axios.get(BASE_URL_URL + fetchAllPrinters+queryParams);
      return response?.data;
    } catch (error) {
      throw error;
    }
  };

const Printer = {
    CreatePrinter,
    FetchPrinters
}

export default Printer;


