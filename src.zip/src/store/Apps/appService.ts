import axios from "axios";
import { AppsListing, BASE_URL_URL, createApp,fetchApps } from "../../util/constant";


const getAllApps = async () => {
    try {
      const response = await axios.get(BASE_URL_URL + AppsListing);
      return response?.data;
    } catch (error) {
      throw error;
    }
};

//fetchApps


const fetchAppsByCategory = async (queryParams:string) => {
  try {
    const response = await axios.get(BASE_URL_URL + fetchApps+queryParams);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

//Create App as global
const createAnApp = async (payload:object) => {
  try {
    const response = await axios.post(BASE_URL_URL + createApp,payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};


const Apps = {getAllApps, createAnApp, fetchAppsByCategory}
export default Apps;
