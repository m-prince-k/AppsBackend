import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import Apps from "./appService";
import { STATUSCODE, SUCCESS } from "../../util/messages";

const initialState = {
    isLoading: false,
    statusCode: 0,
    isError: "",
    isSuccess: false,
    fetchAppsByCatID: "",
    appsListing: "",
    createAppDetails: ""
}


export const getAllBrandApps = createAsyncThunk(
    "apps/getApps",
    async (_: any, thunkApi?: any) => {
        try {
            return await Apps.getAllApps();
        } catch (error) {
            const message =
                error.data?.data ||
                error.data ||
                error?.data?.message ||
                error.string();
            return thunkApi.rejectWithValue(message);
        }
    });



//fetchAppsByCategory
export const fetchAppsById = createAsyncThunk("get/fetchApps",async (queryParams: string, thunkApi?: any) => {
        try {
            return await Apps.fetchAppsByCategory(queryParams);
        } catch (error) {
            const message =
                error.data?.data ||
                error.data ||
                error?.data?.message ||
                error.string();
            return thunkApi.rejectWithValue(message);
        }
    });


//create an custom app 
export const makeApp = createAsyncThunk(
    "post/createApp",
    async (payload: object, thunkApi?: any) => {
        try {
            return await Apps.createAnApp(payload);
        } catch (error) {
            const message =
                error.data?.data ||
                error.data ||
                error?.data?.message ||
                error.string();
            return thunkApi.rejectWithValue(message);
        }
    });


export const AppsReducer = createSlice({
    name: "apps-info",
    initialState,
    reducers: {
        logout: (state: any) => {
            state.isLoading = false;
            state.isSuccess = false;
            state.appsListing = "";
            state.isError = false;
            state.createAppDetails = "";
        },
    },
    extraReducers: (builder: any) => {
        builder
            .addCase(getAllBrandApps.pending, (state: any, action: any) => {
                state.isLoading = true;
                state.isSuccess = false;
                state.isError = action.payload;
                state.message = "";
                state.statusCode = STATUSCODE.Forbidden;
            })
            .addCase(getAllBrandApps.fulfilled, (state: any, action: any) => {
                state.isSuccess = true;
                state.isLoading = false;
                state.appsListing = action.payload;
                state.message = SUCCESS.APPS_FETCHED;
                state.statusCode = STATUSCODE.OK;
            })
            .addCase(getAllBrandApps.rejected, (state: any, action: any) => {
                state.isLoading = true;
                state.isSuccess = false;
                state.isError = action.payload;
                state.appsListing = "";
                state.statusCode = STATUSCODE.Forbidden;
            })
            .addCase(makeApp.pending, (state: any, action: any) => {
                state.isLoading = true;
                state.isSuccess = false;
                state.isError = action.payload;
                state.message = "";
                state.statusCode = STATUSCODE.Forbidden;
            })
            .addCase(makeApp.fulfilled, (state: any, action: any) => {
                state.isSuccess = true;
                state.isLoading = false;
                state.createAppDetails = action.payload;
                state.message = SUCCESS.APP_CREATED;
                state.statusCode = STATUSCODE.OK;
            })
            .addCase(makeApp.rejected, (state: any, action: any) => {
                state.isLoading = true;
                state.isSuccess = false;
                state.isError = action.payload;
                state.appsListing = "";
                state.statusCode = STATUSCODE.Forbidden;
            })

            .addCase(fetchAppsById.pending, (state: any, action: any) => {
                state.isLoading = true;
                state.isSuccess = false;
                state.isError = action.payload;
                state.message = "";
                state.statusCode = STATUSCODE.Forbidden;
            })
            .addCase(fetchAppsById.fulfilled, (state: any, action: any) => {
                state.isSuccess = true;
                state.isLoading = false;
                state.fetchAppsByCatID = action.payload;
                state.message = SUCCESS.FETCH_APPS;
                state.statusCode = STATUSCODE.OK;
            })
            .addCase(fetchAppsById.rejected, (state: any, action: any) => {
                state.isLoading = true;
                state.isSuccess = false;
                state.isError = action.payload;
                state.fetchAppsByCatID = "";
                state.statusCode = STATUSCODE.Forbidden;
            })
    },
});


//

export const { logout } = AppsReducer.actions;

export default AppsReducer.reducer;