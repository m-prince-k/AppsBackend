import axios from "axios";
import {
  BASE_URL_URL,
  register,
  apiLogin,
  changePassword,
  resetPassword,
  forgotPassword,
  getProfile,
  updateProfile,
  updateProfilePic,
  getAuthDetais,
  SignInWithMicrosoft,
} from "../../util/constant";
import { SwalResponse } from "../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../util/messages";

//register
const login = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + apiLogin, data);
    console.log(response);

    const { status } = response;
    if (status === 200) {
      await SwalResponse("success", "message", SUCCESS.REGISTER);
    } else if (status === 403 || status === 500) {
      await SwalResponse("danger", "message", "error_details");
    }
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
  // try {
  //   const response = await axios.post(BASE_URL_URL + apiLogin, userData);
  //   if (response) {
  //     await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
  //   }
  //   return response?.data;
  // } catch (error) {
  //   console.log(error, "___________________________________Error");
  //   throw error;
  // }
};

const ChangePassword = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + changePassword, data);

    const { status, message, error_details } = response?.data;

    if (status === 403) {
      await SwalResponse("danger", message, error_details);
    } else if (status === 500) {
      await SwalResponse("danger", message, error_details);
    } else if (status === 200) {
      await SwalResponse("success", message, SUCCESS.CHANGEPASSWORD);
    }
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
};

const ResetPassword = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + resetPassword, data);

    const { status, message, error_details } = response?.data;

    if (status === 403) {
      await SwalResponse("danger", message, error_details);
    } else if (status === 500) {
      await SwalResponse("danger", message, error_details);
    } else if (status === 200) {
      await SwalResponse("success", message, SUCCESS.RESETPASSWORD);
    }
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
};

const ForgotPassword = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + forgotPassword, data);
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
};

const getDemoResult = async () => {
  try {
    const response = await axios.get(
      "https://jsonplaceholder.typicode.com/todos"
    );
    return response?.data;
  } catch (error) {
    console.log(error, "___________________________________Error");
    throw error;
  }
};

const getProfileDetails = async () => {
  try {
    const response = await axios.get(BASE_URL_URL + getProfile);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const UpdateProfile = async (data: any) => {
  try {
    const response = await axios.patch(BASE_URL_URL + updateProfile, data);
    const { status, message, error_details } = response?.data;

    if (status === 403) {
      await SwalResponse("danger", message, error_details);
    } else if (status === 500) {
      await SwalResponse("danger", message, error_details);
    } else if (status === 200) {
      await SwalResponse("success", message, SUCCESS.UPDATEPROFILE);
    }
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
};

const UpdateProfilePic = async (data: any) => {
  try {
    const response = await axios.patch(BASE_URL_URL + updateProfilePic, data);
    return response?.data;
  } catch (error) {
    await SwalResponse("danger", "error", error);
    throw error;
  }
};

const getAuthPermission = async () => {
  try {
    const response = await axios.get(BASE_URL_URL + getAuthDetais);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const signInWithMicrosoft = async (payload: object) => {
  try {
    const response = await axios.post(BASE_URL_URL + SignInWithMicrosoft,payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};


const Auth = {
  signInWithMicrosoft,
  login,
  ChangePassword,
  ResetPassword,
  ForgotPassword,
  getDemoResult,
  getProfileDetails,
  UpdateProfile,
  UpdateProfilePic,
  getAuthPermission,
};

export default Auth;
