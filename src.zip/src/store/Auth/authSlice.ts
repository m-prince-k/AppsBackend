import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Auth from "./authService";
import { STATUSCODE, SUCCESS } from "../../util/messages";

const initialState = {
  isLoading: false,
  isLogin: false,
  isError: false,
  isSuccess: false,
  message: "",
  loginDetail: "",
  fetchDetails: null,
  fetchAuthDetails: null,
  statusCode: 80,
  loginResponseWithMicrosoft:""
};

interface payload {
  email: string;
  password: string;
}

export const makeLogin = createAsyncThunk(
  "post/login",
  async (userData: payload, thunkApi: any) => {
    try {
      return await Auth.login(userData);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const changePassWord = createAsyncThunk(
  "post/change-password",
  async (data: any, thunkApi: any) => {
    try {
      // const state = thunkApi.getState();
      // const token = state.auth.currentUser?.token;
      // const headers = {
      //   Authorization: `Bearer ${token}`,
      // };
      return await Auth.ChangePassword(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const resetPassWord = createAsyncThunk(
  "post/reset-password",
  async (data: any, thunkApi: any) => {
    try {
      return await Auth.ResetPassword(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const forgotPassWord = createAsyncThunk(
  "post/forgot-password",
  async (data: any, thunkApi: any) => {
    try {
      return await Auth.ForgotPassword(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const demoGettingResponse = createAsyncThunk(
  "get/getting",
  async (_, thunkApi: any) => {
    try {
      //getDemoResult
      return await Auth.getDemoResult();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const getProfileDetail = createAsyncThunk(
  "get/view-profile",
  async (_, thunkApi: any) => {
    try {
      return await Auth.getProfileDetails();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const updateProfile = createAsyncThunk(
  "post/update-profile",
  async (data: any, thunkApi: any) => {
    try {
      return await Auth.UpdateProfile(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const updateProfilePic = createAsyncThunk(
  "post/update-profile-pic",
  async (data: any, thunkApi: any) => {
    try {
      return await Auth.UpdateProfilePic(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const getAuthPermissionDetail = createAsyncThunk(
  "get/get-user-permissions",
  async (_, thunkApi: any) => {
    try {
      return await Auth.getAuthPermission();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);



//login with microsoft along with email account
export const loginWithMicrosoft = createAsyncThunk("post/login-post-microsoft",async (payload:object, thunkApi: any) => {
    try {
      return await Auth.signInWithMicrosoft(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);




export const AuthReducer = createSlice({
  name: "auth-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isLogin = false;
      state.isError = false;
      state.isSuccess = false;
      state.message = "";
      state.loginDetail = "";
      state.fetchDetails = "";
      state.fetchAuthDetails = "";
      state.statusCode = STATUSCODE.Accepted;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(makeLogin.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(makeLogin.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.loginDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(makeLogin.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })

      .addCase(demoGettingResponse.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(demoGettingResponse.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.fetchDetails = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(demoGettingResponse.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //GET PROFILE VIEW
      .addCase(getProfileDetail.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.isSuccess = false;
        state.message = "";
        state.statusCode = 202;
      })
      .addCase(getProfileDetail.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.fetchDetails = action.payload;
        state.message = SUCCESS.GETPROFILE;
        state.statusCode = 200;
      })
      .addCase(getProfileDetail.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.isError = action.payload;
        state.statusCode = 403;
      })
      //Auth Permission Details
      .addCase(getAuthPermissionDetail.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.isSuccess = false;
        state.message = "";
        state.statusCode = 202;
      })
      .addCase(getAuthPermissionDetail.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.fetchAuthDetails = action.payload;
        state.message = SUCCESS.GETPROFILE;
        state.statusCode = 200;
      })
      .addCase(getAuthPermissionDetail.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.isError = action.payload;
        state.statusCode = 403;
      }).addCase(loginWithMicrosoft.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.isSuccess = false;
        state.message = "";
        state.statusCode = 202;
      })
      .addCase(loginWithMicrosoft.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.loginResponseWithMicrosoft = action.payload;
        state.message = SUCCESS.GETPROFILE;
        state.statusCode = 200;
      })
      .addCase(loginWithMicrosoft.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.isError = action.payload;
        state.statusCode = 403;
      });



  },
});

// post request loginWithMicrosoft

//loginResponseWithMicrosoft

export const { logout } = AuthReducer.actions;

export default AuthReducer.reducer;
