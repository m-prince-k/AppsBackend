import axios from "axios";
import { BASE_URL_URL, getDashboardCount } from "../../util/constant";


const getAllDashboardCount = async () => {
    try {
      let response: any = "";
      response = await axios.get(BASE_URL_URL + getDashboardCount);
      return response?.data;
    } catch (error) {
      throw error;
    }
  };

  const Dashboard = {
    getAllDashboardCount
  }

  export default Dashboard;


