import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { SUCCESS } from "../../util/messages";
import Dashboard from "./dashboardService";


const initialState = {
    isLoading: false,
    isLogin: false,
    isError: false,
    message: "",
    getDashboardCount: ""
}


export const fetchDashboardCount = createAsyncThunk("get/fetchCount", async (thunkApi: any) => {
    try {
        return await Dashboard.getAllDashboardCount();
    } catch (error) {
        const message =
            error.data?.data ||
            error.data ||
            error?.data?.message ||
            error.string();
        return thunkApi.rejectWithValue(message);
    }
}
);




export const DashboardReducer = createSlice({
    name: "dashboard-info",
    initialState,
    reducers: {
        logout: (state) => {
            state.isLoading = false;
            state.isLogin = false;
            state.isError = false;
            state.message = "";
            state.getDashboardCount = "";
        },
    },
    extraReducers: (builder) => {
        builder.addCase(fetchDashboardCount.pending, (state, action) => {
            state.isLoading = true;
            state.isLogin = false;
            state.isError = action.payload;
            state.message = "";
        }).addCase(fetchDashboardCount.fulfilled, (state, action) => {
            state.isLogin = true;
            state.isLoading = false;
            state.getDashboardCount = action.payload;
            state.message = SUCCESS.DASHBOARD_COUNT;
        }).addCase(fetchDashboardCount.rejected, (state: any, action: any) => {
            state.isLoading = true;
            state.isError = action.payload;
        })
    },
});

export const { logout } = DashboardReducer.actions;

export default DashboardReducer.reducer;

