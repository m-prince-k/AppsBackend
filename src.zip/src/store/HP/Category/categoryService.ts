import axios from "axios";
import {
  BASE_URL_URL,
  ListingCategories,
  ReOrderCategory,
  ArchiveCategories,
  ArchivedCategory,
  CreateCategory,
  FetchCategoryElement,
  UpdateCategory,
  CategoryViewById,
  ActiveDeactiveCategory,
  AssetsCategory,
  ListingAssetsCategory,
  AssetsCategoryViewById,
  AssetsReOrder,
  ActiveDeactiveAssetCategory,
  ActiveDeleteAssetCategory,
  ReArrangeCategory,
  CategoryListing,
  ViewAllCategoriesByID,
} from "../../../util/constant";

const getAllCategory = async (query: any) => {
  try {
    const response = await axios.get(BASE_URL_URL + ListingCategories + query);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ListingAllCategory = async (queryparams?: string) => {
  try {
    let response: any;
    if (queryparams) {
      response = await axios.get(BASE_URL_URL + CategoryListing + queryparams);
    } else {
      response = await axios.get(BASE_URL_URL + CategoryListing);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ListingAnCategory = async (queryparams?: string) => {
  try {
    let response: any;
    if (queryparams) {
      response = await axios.get(
        BASE_URL_URL + ListingCategories + queryparams
      );
    } else {
      response = await axios.get(BASE_URL_URL + ListingCategories);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const fetchCategoryElements = async () => {
  try {
    const response = await axios.get(BASE_URL_URL + FetchCategoryElement);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const AddCategory = async (payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + CreateCategory, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const EditCategory = async (payload: any) => {
  try {
    const response = await axios.patch(BASE_URL_URL + UpdateCategory, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ReOrderCategories = async (query: string) => {
  try {
    const response = await axios.get(BASE_URL_URL + ReOrderCategory + query);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

//Re-Arragnge categories are here
const ReArrangeCategories = async (payload: object) => {
  try {
    const response = await axios.post(
      BASE_URL_URL + ReArrangeCategory,
      payload
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ArchivedCategories = async (categoryId: any) => {
  try {
    const response = await axios.delete(
      BASE_URL_URL + ArchiveCategories,
      categoryId
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewCategoriesByID = async (queryParams: string) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + CategoryViewById + queryParams
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewMasterCategoriesByID = async (queryParams: string) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + ViewAllCategoriesByID + queryParams
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};
const ActiveDeactiveAssetCategories = async (payload: any) => {
  try {
    const response = await axios.post(
      BASE_URL_URL + ActiveDeactiveAssetCategory,
      payload
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ActiveDeleteAssetCategories = async (payload: any) => {
  try {
    const response = await axios.delete(
      BASE_URL_URL + ActiveDeleteAssetCategory,
      {
        data: payload, // Send payload inside the `data` field
      }
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ActiveDeactiveCategories = async (payload: any) => {
  try {
    const response = await axios.post(
      BASE_URL_URL + ActiveDeactiveCategory,
      payload
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

//GET ARCHIVED CATEGORY LISTING
const getAllArchivedCategory = async (query?: any) => {
  try {
    let response: any = "";
    if (query) {
      response = await axios.get(BASE_URL_URL + ArchivedCategory + query);
    } else {
      response = await axios.get(BASE_URL_URL + ArchivedCategory);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

//CHANGE POSITION OF CATEGORIES WHILE DRAG AND DROP
const changePositionOfCategory = async (payload?: any) => {
  try {
    let response: any = "";

    response = await axios.post(BASE_URL_URL + AssetsReOrder, payload);

    return response?.data;
  } catch (error) {
    throw error;
  }
};

const CreateAssetsCategory = async (payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + AssetsCategory, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const FetchAssetsCategory = async (queryparams?: string) => {
  try {
    let response: any;
    if (queryparams) {
      response = await axios.get(
        BASE_URL_URL + ListingAssetsCategory + queryparams
      );
    } else {
      response = await axios.get(BASE_URL_URL + ListingAssetsCategory);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewAssetsCategoriesByID = async (queryParams: string) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + AssetsCategoryViewById + queryParams
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const CategoryService = {
  getAllCategory,
  ReArrangeCategories,
  changePositionOfCategory,
  getAllArchivedCategory,
  ListingAnCategory,
  fetchCategoryElements,
  AddCategory,
  ReOrderCategories,
  ArchivedCategories,
  EditCategory,
  ViewCategoriesByID,
  ViewMasterCategoriesByID,
  ActiveDeactiveCategories,
  CreateAssetsCategory,
  FetchAssetsCategory,
  ViewAssetsCategoriesByID,
  ActiveDeactiveAssetCategories,
  ActiveDeleteAssetCategories,
  ListingAllCategory,
};

export default CategoryService;
