import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { STATUSCODE, SUCCESS } from "../../../util/messages";
import Category from "./categoryService";

const initialState = {
  isLoading: false,
  isCategory: false,
  isCategoryElement: false,
  getAppListing: "",
  isError: false,
  statusCode: 0,
  message: "",
  createCategoryDetail: "",
  categories: "",
  viewCategoryByIDDetail: "",
  updateCategoryDetail: "",
  activeDeActiveDetail: "",
  fetchCategoryElements: "",
  reOrderCategories: "",
  changePositionReOrderCategories: "",
  reArrangeCategories: "",
};

interface payload {
  email: string;
  password: string;
}

export const CategoriesReOrder = createAsyncThunk(
  "get/reorder-category",
  async (query: string, thunkApi: any) => {
    try {
      return await Category.ReOrderCategories(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const listingAllCategory = createAsyncThunk(
  "get/listing-category",
  async (query?: string, thunkApi?: any) => {
    try {
      if (query) {
        return await Category.ListingAllCategory(query);
      }
      return await Category.ListingAllCategory();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      if (thunkApi) {
        return thunkApi.rejectWithValue(message);
      }
    }
  }
);

export const categoryCreate = createAsyncThunk(
  "post/add-category",
  async (data: payload, thunkApi: any) => {
    try {
      return await Category.AddCategory(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const getAllCategory = createAsyncThunk(
  "apps/category",
  async (query: any, thunkApi?: any) => {
    try {
      return await Category.getAllCategory(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const listingCategory = createAsyncThunk(
  "get/listing-category",
  async (query?: string, thunkApi?: any) => {
    try {
      if (query) {
        return await Category.ListingAnCategory(query);
      }
      return await Category.ListingAnCategory();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      if (thunkApi) {
        return thunkApi.rejectWithValue(message);
      }
    }
  }
);

export const viewMasterCategoryByID = createAsyncThunk(
  "get/view-category-id",
  async (query: any, thunkApi: any) => {
    try {
      return await Category.ViewMasterCategoriesByID(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const viewCategoryByID = createAsyncThunk(
  "get/view-category-id",
  async (query: any, thunkApi: any) => {
    try {
      return await Category.ViewCategoriesByID(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const fetchElementsByCategory = createAsyncThunk(
  "get/fetchCategoryElement",
  async (_, thunkApi?: any) => {
    try {
      return await Category.fetchCategoryElements();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const categoryUpdate = createAsyncThunk(
  "patch/update-category",
  async (payload: payload, thunkApi: any) => {
    try {
      return await Category.EditCategory(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const categoryAssetsCreate = createAsyncThunk(
  "post/assest",
  async (formData: FormData, thunkApi: any) => {
    try {
      return await Category.CreateAssetsCategory(formData);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const listingAssetsCategory = createAsyncThunk(
  "get/fetch-asset",
  async (query?: string, thunkApi?: any) => {
    try {
      if (query) {
        return await Category.FetchAssetsCategory(query);
      }
      return await Category.FetchAssetsCategory();
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      if (thunkApi) {
        return thunkApi.rejectWithValue(message);
      }
    }
  }
);

export const viewAssetsCategoryByID = createAsyncThunk(
  "get/asset-view",
  async (query: any, thunkApi: any) => {
    try {
      return await Category.ViewAssetsCategoriesByID(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const activeAssetCategoryDeActive = createAsyncThunk(
  "get/asset-updateStatus",
  async (payload: object, thunkApi: any) => {
    try {
      return await Category.ActiveDeactiveAssetCategories(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const activeAssetCategoryDelete = createAsyncThunk(
  "delete/asset-delete",
  async (payload: any, thunkApi: any) => {
    try {
      console.log(payload);

      return await Category.ActiveDeleteAssetCategories(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const activeFrameDeActiveCategory = createAsyncThunk(
  "get/deactivecategory",
  async (payload: object, thunkApi: any) => {
    try {
      return await Category.ActiveDeactiveCategories(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

//fetch archived listing of category
export const allArchivedCategories = createAsyncThunk(
  "get/archivedCategory",
  async (query?: string, thunkApi?: any) => {
    try {
      return await Category.getAllArchivedCategory(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

//fetch updated change position category listing
export const changeReOrderCategories = createAsyncThunk(
  "get/reOrderCategory",
  async (payload?: object, thunkApi?: any) => {
    try {
      return await Category.changePositionOfCategory(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

//re-arrange categories set here
export const changeReArrangeCategories = createAsyncThunk(
  "post/reArrangeCategory",
  async (payload?: object, thunkApi?: any) => {
    try {
      return await Category.ReArrangeCategories(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const CategoryReducer = createSlice({
  name: "category-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isCategory = false;
      state.isCategoryElement = false;
      state.isError = false;
      state.statusCode = 0;
      state.message = "";
      state.createCategoryDetail = "";
      state.categories = "";
      state.viewCategoryByIDDetail = "";
      state.fetchCategoryElements = "";
      state.updateCategoryDetail = "";
      state.activeDeActiveDetail = "";
      state.statusCode = 0;
      state.getAppListing = "";
      state.reOrderCategories = "";
      state.changePositionReOrderCategories = "";
      state.reArrangeCategories = "";
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(categoryCreate.pending, (state, action) => {
        state.isLoading = true;
        state.isCategoryElement = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(categoryCreate.fulfilled, (state, action) => {
        state.isCategoryElement = true;
        state.isLoading = false;
        state.createCategoryDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(categoryCreate.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(listingCategory.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
        state.statusCode = STATUSCODE.Accepted;
      })
      .addCase(listingCategory.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.categories = action.payload;
        state.message = SUCCESS.CATEGORIES_FETCHED;
        state.statusCode = STATUSCODE.OK;
      })
      .addCase(listingCategory.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden;
      })
      //THIS IS FOR VIEW BY ID THE CATEGORY
      .addCase(viewCategoryByID.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(viewCategoryByID.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.viewCategoryByIDDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(viewCategoryByID.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR DYNAMIC VIEW UNDER CREATE CATEGORY
      .addCase(fetchElementsByCategory.pending, (state, action) => {
        state.isLoading = true;
        state.statusCode = STATUSCODE.Accepted;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(fetchElementsByCategory.fulfilled, (state, action) => {
        state.isCategoryElement = true;
        state.isLoading = false;
        state.fetchCategoryElements = action.payload;
        state.message = SUCCESS.FETCH_CATEGORY_ELEMENTS;
        state.statusCode = STATUSCODE.OK;
      })
      .addCase(fetchElementsByCategory.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden;
      })

      //THIS IS FOR UPDATE BY ID THE CATEGORY
      .addCase(categoryUpdate.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(categoryUpdate.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.updateCategoryDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(categoryUpdate.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(activeFrameDeActiveCategory.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
        state.statusCode = STATUSCODE.Accepted;
      })
      .addCase(activeFrameDeActiveCategory.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.activeDeActiveDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
        state.statusCode = STATUSCODE.OK;
      })
      .addCase(activeFrameDeActiveCategory.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden;
      })
      .addCase(CategoriesReOrder.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
        state.statusCode = STATUSCODE.Accepted;
      })
      .addCase(CategoriesReOrder.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.reOrderCategories = action.payload;
        state.message = SUCCESS.REORDER_CATEGORY;
        state.statusCode = STATUSCODE.OK;
      })
      .addCase(CategoriesReOrder.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden;
      })
      .addCase(changeReOrderCategories.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
        state.statusCode = STATUSCODE.Accepted;
      })
      .addCase(changeReOrderCategories.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.changePositionReOrderCategories = action.payload;
        state.message = SUCCESS.POSITION_CHANGE_REORDER_CATEGORY;
        state.statusCode = STATUSCODE.OK;
      })
      .addCase(changeReOrderCategories.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden;
      })
      .addCase(changeReArrangeCategories.pending, (state, action) => {
        state.isLoading = true;
        state.isCategory = false;
        state.isError = action.payload;
        state.message = "";
        state.statusCode = STATUSCODE.Accepted;
      })
      .addCase(changeReArrangeCategories.fulfilled, (state, action) => {
        state.isCategory = true;
        state.isLoading = false;
        state.reArrangeCategories = action.payload;
        state.message = SUCCESS.REARRANGE_CATEGORIES;
        state.statusCode = STATUSCODE.OK;
      })
      .addCase(changeReArrangeCategories.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden;
      });
  },
});

export const { logout } = CategoryReducer.actions;

export default CategoryReducer.reducer;
