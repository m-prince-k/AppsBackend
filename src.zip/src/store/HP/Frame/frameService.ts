import axios from "axios";
import {
  BASE_URL_URL,
  createFrame,
  ListingFrame,
  UpdateFrame,
  ViewFrame,
  ReorderFrame,
  DeletedFrame,
  ActiveDeactiveFrame,
  specificFrameStatusUpdate,
  fetchFrameById,
} from "../../../util/constant";
import { SwalResponse } from "../../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../../util/messages";

const CreateAnFrame = async (frameData: FormData) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFrame, frameData);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const frameListing = async (queryParams: string) => {
  try {
    const response = await axios.get(BASE_URL_URL + ListingFrame + queryParams);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewAnFrameByID = async (queryParams: any) => {
  try {
    const response = await axios.get(BASE_URL_URL + ViewFrame+queryParams);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ActiveDeActiveFrame = async (frameId: any) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + ActiveDeactiveFrame + "/" + frameId
    );
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const EditFrame = async (formData: FormData) => {
  try {
    const response = await axios.patch(BASE_URL_URL + UpdateFrame, formData);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ReOrderFrame = async (payload: object) => {
  try {
    const response = await axios.post(BASE_URL_URL + ReorderFrame, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const DeleteFrame = async (frameId: any) => {
  try {
    const response = await axios.delete(BASE_URL_URL + DeletedFrame, frameId);
    return response?.data;
  } catch (error) {
    throw error;
  }
};


const updateSpecificFrame = async (payload:object) => {
  try {
    const response = await axios.post(BASE_URL_URL + specificFrameStatusUpdate,payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
}

const viewFrameByID = async (queryParams:string) => {
  try {
    const response = await axios.get(BASE_URL_URL + fetchFrameById + queryParams);
    return response?.data;
  } catch (error) {
    throw error;
  }
}



//viewFrameByID


const Frame = {
  viewFrameByID,
  updateSpecificFrame,
  CreateAnFrame,
  frameListing,
  ViewAnFrameByID,
  ActiveDeActiveFrame,
  EditFrame,
  ReOrderFrame,
  DeleteFrame,
};

export default Frame;
