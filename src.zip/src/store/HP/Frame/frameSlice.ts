import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";

import { SUCCESS } from "../../../util/messages";
import Frame from "./frameService";

const initialState = {
    isLoading:false,
    isLogin:false,
    isError:false,
    message:"",
    createFrameDetail:"",
    viewFrameDetail:"",
    activeDeActiveDetail:"",
    frameListing:"",
    reArrangeFrameListing:"",
    specificFrameUpdate:"",
    fetchSingleFrameById:"",
    updateFrameDetail:""
}

export const frameCreate = createAsyncThunk ('post/frame',async (formData:FormData,thunkApi:any) => {
    try {
        return await Frame.CreateAnFrame(formData);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


export const listingFrame = createAsyncThunk("get/listing-frame",async (query?: string, thunkApi?: any) => {
    try {
      return await Frame.frameListing(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      if (thunkApi) {
        return thunkApi.rejectWithValue(message);
      }
    }
  }
);

export const viewFrame= createAsyncThunk ('get/viewFrame',async (queryParams:string,thunkApi:any) => {
    try {
        return await Frame.ViewAnFrameByID(queryParams);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


//specific update frame status here...
export const specificFrameStatusUpdate= createAsyncThunk ('post/specificFrameUpdate',async (payload:object,thunkApi:any) => {
    try {
        return await Frame.updateSpecificFrame(payload);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


//fetch single frame by id
export const fetchFrameById= createAsyncThunk ('get/fetchFrameByIds',async (queryParams:string,thunkApi:any) => {
    try {
        return await Frame.viewFrameByID(queryParams);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


export const activeFrameDeActiveFrame = createAsyncThunk ('get/viewFrame',async (frameId:number,thunkApi:any) => {
    try {
        return await Frame.ActiveDeActiveFrame(frameId);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


//ReArrange entire row for frames
export const ReArrageFrames = createAsyncThunk ('post/rearrange',async (payload:object,thunkApi:any) => {
    try {
        return await Frame.ReOrderFrame(payload);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});


//edit frame is start here...
export const editFrame = createAsyncThunk ('patch/editFrame',async (formData:FormData,thunkApi:any) => {
    try {
        return await Frame.EditFrame(formData);
    } catch (error) {
        const message=error.data?.data || error.data || error?.data?.message || error.string();
        return thunkApi.rejectWithValue(message);
    }
});

export const FrameReducer=createSlice({
    name:'frame-info',
    initialState,
    reducers:{
        logout:(state) => {
            state.isLoading=false
            state.isLogin=false
            state.isError=false
            state.message=""
            state.createFrameDetail=""
            state.viewFrameDetail=""
            state.activeDeActiveDetail=""
            state.frameListing=""
            state.reArrangeFrameListing=""
            state.specificFrameUpdate=""
            state.fetchSingleFrameById=""
            state.updateFrameDetail=""
            
        }
    },
    extraReducers:(builder) => {
        builder.addCase(frameCreate.pending,(state,action) => {
            state.isLoading=true
            state.isLogin=false
            state.isError=action.payload
            state.message=""
        }).addCase(frameCreate.fulfilled,(state,action) => {
            state.isLogin=true
            state.isLoading=false
            state.createFrameDetail=action.payload
            state.message=SUCCESS.MESSAGE
        }).addCase(frameCreate.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        }).addCase(viewFrame.pending,(state,action) => {
            state.isLoading=true
            state.isLogin=false
            state.isError=action.payload
            state.message=""
        }).addCase(viewFrame.fulfilled,(state,action) => {
            state.isLogin=true
            state.isLoading=false
            state.viewFrameDetail=action.payload
            state.message=SUCCESS.MESSAGE
        }).addCase(viewFrame.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        }).addCase(listingFrame.pending,(state,action) => {
            state.isLoading=true
            state.isLogin=false
            state.isError=action.payload
            state.message=""
        }).addCase(listingFrame.fulfilled,(state,action) => {
            state.isLogin=true
            state.isLoading=false
            state.frameListing=action.payload
            state.message=SUCCESS.MESSAGE
        }).addCase(listingFrame.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        })

        .addCase(ReArrageFrames.pending,(state,action) => {
            state.isLoading=true
            state.isLogin=false
            state.isError=action.payload
            state.message=""
        }).addCase(ReArrageFrames.fulfilled,(state,action) => {
            state.isLogin=true
            state.isLoading=false
            state.reArrangeFrameListing=action.payload
            state.message=SUCCESS.MESSAGE
        }).addCase(ReArrageFrames.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        })


        .addCase(specificFrameStatusUpdate.pending,(state,action) => {
            state.isLoading=true
            state.isLogin=false
            state.isError=action.payload
            state.message=""
        }).addCase(specificFrameStatusUpdate.fulfilled,(state,action) => {
            state.isLogin=true
            state.isLoading=false
            state.specificFrameUpdate=action.payload
            state.message=SUCCESS.MESSAGE
        }).addCase(specificFrameStatusUpdate.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        })


        .addCase(fetchFrameById.pending,(state,action) => {
            state.isLoading=true
            state.isLogin=false
            state.isError=action.payload
            state.message=""
        }).addCase(fetchFrameById.fulfilled,(state,action) => {
            state.isLogin=true
            state.isLoading=false
            state.fetchSingleFrameById=action.payload
            state.message=SUCCESS.MESSAGE
        }).addCase(fetchFrameById.rejected,(state,action:any) => {
            state.isLoading=true
            state.isError=action.payload
        })
    }
});

//fetchFrameById
//specificFrameStatusUpdate

export const {logout}=FrameReducer.actions;

export default FrameReducer.reducer;



