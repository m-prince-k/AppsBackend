import axios from "axios";
import { BASE_URL_URL, createFrame } from "../../../util/constant";
import { SwalResponse } from "../../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../../util/messages";

const GenerateAssetReport = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFrame, data);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const GenerateFirmwareReport = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFrame, data);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const GenerateUserAccessReport = async (data: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFrame, data);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewAnFrame = async (frameID: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFrame, frameID);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ActiveDeActiveFrame = async (frameId: any) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + createFrame + "/" + frameId
    );
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const Report = {
  GenerateAssetReport,
  GenerateFirmwareReport,
  GenerateUserAccessReport,
  ViewAnFrame,
  ActiveDeActiveFrame,
};

export default Report;
