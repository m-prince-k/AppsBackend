import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { SUCCESS } from "../../../util/messages";
import Report from "./reportingService";

const initialState = {
  isLoading: false,
  isLogin: false,
  isError: false,
  message: "",
  generateAssetReportDetail: "",
  generateFirmwareReportDetail: "",
  generateUserAccessReportDetail: "",
  viewFrameDetail: "",
  activeDeActiveDetail: "",
};

interface payload {
  email: string;
  password: string;
}

export const assetReport = createAsyncThunk(
  "post/asset-report",
  async (payload: payload, thunkApi: any) => {
    try {
      return await Report.GenerateAssetReport(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const firmwareReport = createAsyncThunk(
  "post/firmware-report",
  async (payload: payload, thunkApi: any) => {
    try {
      return await Report.GenerateFirmwareReport(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const userAccessReport = createAsyncThunk(
  "post/access-report",
  async (payload: payload, thunkApi: any) => {
    try {
      return await Report.GenerateUserAccessReport(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const viewFrame = createAsyncThunk(
  "get/viewFrame",
  async (frameId: number, thunkApi: any) => {
    try {
      return await Report.ViewAnFrame(frameId);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const activeFrameDeActiveFrame = createAsyncThunk("get/activeDeactive", async (frameId: number, thunkApi: any) => {
  try {
    return await Report.ActiveDeActiveFrame(frameId);
  } catch (error) {
    const message =
      error.data?.data ||
      error.data ||
      error?.data?.message ||
      error.string();
    return thunkApi.rejectWithValue(message);
  }
}
);

export const ReportReducer = createSlice({
  name: "frame-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isLogin = false;
      state.isError = false;
      state.message = "";
      state.generateAssetReportDetail = "";
      state.viewFrameDetail = "";
      state.activeDeActiveDetail = "";
    },
  },
  extraReducers: (builder) => {
    builder

      //generate report for asset
      .addCase(assetReport.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(assetReport.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.generateAssetReportDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(assetReport.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })

      //generate report for firmware
      .addCase(firmwareReport.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(firmwareReport.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.generateFirmwareReportDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(firmwareReport.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(userAccessReport.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(userAccessReport.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.generateUserAccessReportDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(userAccessReport.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(viewFrame.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(viewFrame.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.viewFrameDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(viewFrame.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(activeFrameDeActiveFrame.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(activeFrameDeActiveFrame.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.activeDeActiveDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(activeFrameDeActiveFrame.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      });
  },
});

export const { logout } = ReportReducer.actions;

export default ReportReducer.reducer;
