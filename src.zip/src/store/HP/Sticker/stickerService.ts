import axios from "axios";
import {
  BASE_URL_URL,
  AddSticker,
  StickerListing,
  ActiveDeactiveSticker,
  UpdateSticker,
  ReorderSticker,
  DeletedSticker,
  ViewSticker,
  ViewStickerByID,
} from "../../../util/constant";
import { SwalResponse } from "../../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../../util/messages";

const CreateSticker = async (stickerData: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + AddSticker, stickerData);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const stickerListing = async (queryParams?: string) => {
  try {
    let response: any;
    if (queryParams) {
      response = await axios.get(BASE_URL_URL + StickerListing + queryParams);
    } else {
      response = await axios.get(BASE_URL_URL + StickerListing);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewStickerList = async (queryParams: string) => {
  try {
    const response = await axios.get(BASE_URL_URL + ViewSticker + queryParams);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewStickerListByID = async (queryParams: any) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + ViewStickerByID + queryParams
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const StickerActiveDeActive = async (payload: any) => {
  try {
    const response = await axios.post(
      BASE_URL_URL + ActiveDeactiveSticker,
      payload
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const EditSticker = async (data: any) => {
  try {
    const response = await axios.patch(BASE_URL_URL + UpdateSticker, data);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const StickerReOrdering = async (payload: object) => {
  try {
    const response = await axios.post(BASE_URL_URL + ReorderSticker, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const DeleteSticker = async (stickerID: any) => {
  try {
    const response = await axios.delete(
      BASE_URL_URL + DeletedSticker,
      stickerID
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const changePositionOfSticker = async (payload?: any) => {
  try {
    let response: any = "";

    response = await axios.post(BASE_URL_URL + ReorderSticker, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const Sticker = {
  CreateSticker,
  stickerListing,
  StickerActiveDeActive,
  EditSticker,
  StickerReOrdering,
  DeleteSticker,
  ViewStickerList,
  ViewStickerListByID,changePositionOfSticker,
};

export default Sticker;
