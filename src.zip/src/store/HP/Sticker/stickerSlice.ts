import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { SUCCESS } from "../../../util/messages";
import Sticker from "./stickerService";

const initialState = {
  isLoading: false,
  isLogin: false,
  isError: false,
  message: "",
  createStickerDetail: "",
  viewStickerDetail: "",
  activeDeActiveDetail: "",
  fetchStickerListing: "",
  stickerReOrderDetails: "",
};

interface payload {
  email: string;
  password: string;
}

export const stickerReOrders = createAsyncThunk(
  "post/re-sticker",
  async (payload: object, thunkApi: any) => {
    try {
      return await Sticker.StickerReOrdering(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const stickerCreate = createAsyncThunk("post/sticker",async (formData: FormData, thunkApi: any) => {
    try {
      return await Sticker.CreateSticker(formData);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const listingSticker = createAsyncThunk(
  "get/listing-sticker",
  async (query?: string, thunkApi?: any) => {
    try {
      return await Sticker.stickerListing(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      if (thunkApi) {
        return thunkApi.rejectWithValue(message);
      }
    }
  }
);

export const viewSticker = createAsyncThunk("_get/sticker",async (query?:any, thunkApi?: any) => {
    try {
      return await Sticker.ViewStickerList(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const viewStickerByID = createAsyncThunk(
  "get/sticker/details",
  async (query?: string, thunkApi?: any) => {
    try {
      return await Sticker.ViewStickerListByID(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const activeStickerDeActiveFrame = createAsyncThunk(
  "post/status-sticker-update",
  async (payload: object, thunkApi: any) => {
    try {
      return await Sticker.StickerActiveDeActive(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const updateCreate = createAsyncThunk(
  "patch/sticker",
  async (formData: FormData, thunkApi: any) => {
    try {
      return await Sticker.EditSticker(formData);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const changeReOrderStickers = createAsyncThunk(
  "get/reOrderCategory",
  async (payload?: object, thunkApi?: any) => {
    try {
      return await Sticker.changePositionOfSticker(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const StickerReducer = createSlice({
  name: "frame-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isLogin = false;
      state.isError = false;
      state.message = "";
      state.createStickerDetail = "";
      state.viewStickerDetail = "";
      state.activeDeActiveDetail = "";
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(stickerCreate.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(stickerCreate.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.createStickerDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(stickerCreate.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR VIEW THE FRAME
      .addCase(viewSticker.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(viewSticker.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.viewStickerDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(viewSticker.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR RUNNING THE ACTIVE DEACTIVE FRAME
      .addCase(activeStickerDeActiveFrame.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(activeStickerDeActiveFrame.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.activeDeActiveDetail = action.payload;
        state.message = SUCCESS.STICKER_STATUS_UPDATE;
      })
      .addCase(activeStickerDeActiveFrame.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(listingSticker.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(listingSticker.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.fetchStickerListing = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(listingSticker.rejected, (state: any, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(stickerReOrders.pending, (state: any, action: any) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(stickerReOrders.fulfilled, (state: any, action: any) => {
        state.isLogin = true;
        state.isLoading = false;
        state.stickerReOrderDetails = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(stickerReOrders.rejected, (state: any, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      });
  },
});

export const { logout } = StickerReducer.actions;

export default StickerReducer.reducer;
