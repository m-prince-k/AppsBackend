import axios from "axios";
import {
  BASE_URL_URL,
  createRbac,
  UpdateRbac,
  rbacListing,
  fetchRolesPermission
} from "../../../util/constant";

const CreateRole = async (payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + createRbac, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

//fetch permission
const permissionFetch = async (access_type_id:number) => {
  try {
    const response = await axios.get(BASE_URL_URL + fetchRolesPermission+`?access_type_id=${access_type_id}`);
    console.log(response,"__________________-07678")
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const RbacListing = async (query?:string) => {
  try {
    let response:any;
    if(query) {
      response = await axios.get(BASE_URL_URL + rbacListing+query);
    } else {
      response = await axios.get(BASE_URL_URL + rbacListing);
    }
    return await response?.data;
  } catch (error) {
    throw error;
  }
};

const EditRbac = async (payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + UpdateRbac, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};


const Sticker = {
  CreateRole,
  permissionFetch,
  RbacListing,
  EditRbac,
};

export default Sticker;
