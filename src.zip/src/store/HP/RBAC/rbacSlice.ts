import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { STATUSCODE, SUCCESS } from "../../../util/messages";
import RBAC from "./rbacService";

const initialState = {
  isLoading: false,
  isError: false,
  message: "",
  statusCode: 0,
  isSuccess: false,
  fetchListing: "",
  createRbacDetail: "",
  viewRbacDetail: "",
  activeDeActiveDetail: "",
  fetchPermissions: "",
  updateRolesPermission: ""
};



//fetch permission along with roles
export const fetchRolesPermission = createAsyncThunk("get/permission", async (access_type_id: number, thunkApi: any) => {
  try {
    return await RBAC.permissionFetch(access_type_id);
  } catch (error) {
    const message =
      error.data?.data ||
      error.data ||
      error?.data?.message ||
      error.string();
    return thunkApi.rejectWithValue(message);
  }
}
);

export const makeRole = createAsyncThunk("post/rbac", async (payload: any, thunkApi: any) => {
  try {
    return await RBAC.CreateRole(payload);
  } catch (error) {
    const message =
      error.data?.data ||
      error.data ||
      error?.data?.message ||
      error.string();
    return thunkApi.rejectWithValue(message);
  }
}
);

export const listingRbac = createAsyncThunk("get/listing-rbac", async (query?: any, thunkApi?: any) => {
  try {

    if (query) {
      return await RBAC.RbacListing(query);
    }
    return await RBAC.RbacListing();
  } catch (error) {
    const message =
      error.data?.data ||
      error.data ||
      error?.data?.message ||
      error.string();
    return thunkApi.rejectWithValue(message);
  }
}
);

export const UpdateRbac = createAsyncThunk(
  "update/update-rbac",
  async (data: any, thunkApi: any) => {
    try {
      return await RBAC.EditRbac(data);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const RbacReducer = createSlice({
  name: "rbac-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isError = false;
      state.message = "";
      state.fetchListing = "";
      state.createRbacDetail = "";
      state.viewRbacDetail = "";
      state.activeDeActiveDetail = "";
      state.statusCode = 0;
      state.fetchPermissions = "";
      state.updateRolesPermission = ""
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(makeRole.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(makeRole.fulfilled, (state, action) => {
        state.isLoading = false;
        state.createRbacDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(makeRole.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(listingRbac.pending, (state, action) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.isError = action.payload;
        state.message = "";
        state.statusCode = STATUSCODE.Accepted
      })
      .addCase(listingRbac.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.fetchListing = action.payload;
        state.message = SUCCESS.FETCH_ROLES;
        state.statusCode = STATUSCODE.OK
      })
      .addCase(listingRbac.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.isError = action.payload;
        state.statusCode = STATUSCODE.Forbidden
      })
      .addCase(UpdateRbac.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(UpdateRbac.fulfilled, (state, action) => {
        state.isLoading = false;
        state.updateRolesPermission = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(UpdateRbac.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      .addCase(fetchRolesPermission.pending, (state, action) => {
        state.isLoading = true;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(fetchRolesPermission.fulfilled, (state, action) => {
        state.isLoading = false;
        state.fetchPermissions = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(fetchRolesPermission.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      });
  },
});

export const { logout } = RbacReducer.actions;

export default RbacReducer.reducer;
