import axios from "axios";
import {
  BASE_URL_URL,
  createFirmWare,
  ViewFirmWare,
  ListingFirmWare,
  UpdateFirmWare,
  DeleteFirmWare,
  StatusFirmWare,
} from "../../../util/constant";
import { SwalResponse } from "../../../_metronic/helpers";
import { SUCCESS, TITLE } from "../../../util/messages";

const CreateAnFrimWare = async (formData: FormData) => {
  try {
    const response = await axios.post(BASE_URL_URL + createFirmWare,formData);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ViewAnFrimWareByID = async (queryParams:string) => {
  try {
    const response = await axios.get(BASE_URL_URL+ViewFirmWare+queryParams)
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const FrimWareListing = async (queryParams: string) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + ListingFirmWare + queryParams
    );
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const EditFrimWare = async (payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + UpdateFirmWare, payload);
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const DeletedCategories = async (frimWareID: any) => {
  try {
    const response = await axios.get(BASE_URL_URL + DeleteFirmWare, frimWareID);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const ActiveDeActiveFrimWare = async (frimWareID: any) => {
  try {
    const response = await axios.get(
      BASE_URL_URL + createFirmWare + "/" + frimWareID
    );
    if (response) {
      await SwalResponse("success", TITLE.MESSAGE, SUCCESS.MESSAGE);
    }
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const UpdateStatusFrimWare = async (payload: any) => {
  try {
    const response = await axios.post(BASE_URL_URL + StatusFirmWare, payload);
    return response?.data;
  } catch (error) {
    throw error;
  }
};

const FrimWare = {
  CreateAnFrimWare,
  ViewAnFrimWareByID,
  ActiveDeActiveFrimWare,
  FrimWareListing,
  EditFrimWare,
  DeletedCategories,
  UpdateStatusFrimWare,
};

export default FrimWare;
