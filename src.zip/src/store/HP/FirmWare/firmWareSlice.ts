import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

import { SUCCESS } from "../../../util/messages";
import FirmWare from "./firmWareService";

const initialState = {
  isLoading: false,
  isLogin: false,
  isError: false,
  message: "",
  createFirmwareDetail: "",
  listingFirmwareDetail: "",
  viewFirmwareByIDDetail: "",
  updateFirmwareDetail: "",
  activeDeActiveDetail: "",
};

interface payload {
  email: string;
  password: string;
}

export const firmwareCreate = createAsyncThunk(
  "post/firmware",
  async (formData: FormData, thunkApi: any) => {
    try {
      return await FirmWare.CreateAnFrimWare(formData);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const listingFirmware = createAsyncThunk(
  "get/listingFirmware",
  async (queryParams: string, thunkApi: any) => {
    try {
      return await FirmWare.FrimWareListing(queryParams);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const viewFirmwareByID = createAsyncThunk(
  "get/view-firmware-id",
  async (query: any, thunkApi: any) => {
    try {
      // const urlParams = new URLSearchParams(query);
      // const app_id = urlParams.get("app_id");
      // const firmware_id = urlParams.get("firmware_id");
      return await FirmWare.ViewAnFrimWareByID(query);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const firmwareUpdate = createAsyncThunk(
  "post/firmware",
  async (payloadData: payload, thunkApi: any) => {
    try {
      return await FirmWare.EditFrimWare(payloadData);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const firmwareUpdateStatus = createAsyncThunk(
  "post/firmware",
  async (payload: any, thunkApi: any) => {
    try {
      return await FirmWare.UpdateStatusFrimWare(payload);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const activeFrameDeActiveFrame = createAsyncThunk(
  "get/viewFrame",
  async (frameId: number, thunkApi: any) => {
    try {
      return await FirmWare.ActiveDeActiveFrimWare(frameId);
    } catch (error) {
      const message =
        error.data?.data ||
        error.data ||
        error?.data?.message ||
        error.string();
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const FrimWareReducer = createSlice({
  name: "frame-info",
  initialState,
  reducers: {
    logout: (state) => {
      state.isLoading = false;
      state.isLogin = false;
      state.isError = false;
      state.message = "";
      state.createFirmwareDetail = "";
      state.listingFirmwareDetail = "";
      state.viewFirmwareByIDDetail = "";
      state.activeDeActiveDetail = "";
    },
  },
  extraReducers: (builder) => {
    builder
      //THIS IS FOR CREATE OF FIRMWARE
      .addCase(firmwareCreate.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(firmwareCreate.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.createFirmwareDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(firmwareCreate.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR VIEW of FIRMWARE
      .addCase(listingFirmware.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(listingFirmware.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.listingFirmwareDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(listingFirmware.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR VIEW BY ID of FIRMWARE
      .addCase(viewFirmwareByID.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(viewFirmwareByID.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.viewFirmwareByIDDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(viewFirmwareByID.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR UPDATE OF FIRMWARE
      .addCase(firmwareUpdate.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(firmwareUpdate.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.updateFirmwareDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(firmwareUpdate.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      })
      //THIS IS FOR RUNNING THE ACTIVE DEACTIVE FIRMWARE
      .addCase(activeFrameDeActiveFrame.pending, (state, action) => {
        state.isLoading = true;
        state.isLogin = false;
        state.isError = action.payload;
        state.message = "";
      })
      .addCase(activeFrameDeActiveFrame.fulfilled, (state, action) => {
        state.isLogin = true;
        state.isLoading = false;
        state.activeDeActiveDetail = action.payload;
        state.message = SUCCESS.MESSAGE;
      })
      .addCase(activeFrameDeActiveFrame.rejected, (state, action: any) => {
        state.isLoading = true;
        state.isError = action.payload;
      });
  },
});

export const { logout } = FrimWareReducer.actions;

export default FrimWareReducer.reducer;
